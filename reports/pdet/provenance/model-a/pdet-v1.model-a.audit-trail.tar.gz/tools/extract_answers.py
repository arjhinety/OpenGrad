import json, sys, hashlib
from pathlib import Path
transcript, out = Path(sys.argv[1]), Path(sys.argv[2])
last = None; n = 0
for line in transcript.read_text(encoding="utf-8").splitlines():
    try:
        rec = json.loads(line)
    except Exception:
        continue
    msg = rec.get("message") or {}
    if msg.get("role") == "assistant":
        content = msg.get("content")
        if isinstance(content, list):
            text = "".join(p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text")
        else:
            text = content or ""
        if text.strip():
            last = text; n += 1
if last is None:
    print("no assistant text found; transcript bytes:", transcript.stat().st_size); sys.exit(1)
if out.exists():
    print(out, "exists; not overwriting"); sys.exit(1)
out.write_text(last, encoding="utf-8")
data = json.loads(last.strip())
print(f"saved {out.name}: {len(data)} answers, sha256 {hashlib.sha256(last.encode()).hexdigest()[:16]}, from assistant text message #{n}")

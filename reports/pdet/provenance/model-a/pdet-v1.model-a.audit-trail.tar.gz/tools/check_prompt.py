import json, sys, hashlib
from pathlib import Path
transcript, batch_line = Path(sys.argv[1]), sys.argv[2]
procedure = Path("configs/annotation/pdet-v1.model-procedure.md").read_text(encoding="utf-8")
first = None
for line in transcript.read_text(encoding="utf-8").splitlines():
    try:
        rec = json.loads(line)
    except Exception:
        continue
    msg = rec.get("message") or {}
    if rec.get("type") == "user" or msg.get("role") == "user":
        content = msg.get("content")
        if isinstance(content, list):
            content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
        if isinstance(content, str) and content.strip():
            first = content
            break
if first is None:
    print("no user message found yet"); sys.exit(1)
expected = procedure.rstrip("\n") + "\n\n" + batch_line
same = first.strip() == expected.strip()
print("prompt == procedure file + batch line:", same)
if not same:
    import difflib
    for d in list(difflib.unified_diff(expected.strip().splitlines(), first.strip().splitlines(), lineterm=""))[:20]:
        print(d[:160])

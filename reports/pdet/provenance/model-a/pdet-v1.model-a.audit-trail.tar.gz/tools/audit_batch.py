"""Audit one model batch run from its subagent transcript, then save its answers verbatim.

Fails (exit 1, nothing saved) unless: the subagent's prompt is exactly the pinned procedure file plus the
batch line; every tool call it made was a Read of its own batch file; and it ran on the declared model.
"""

import hashlib
import json
import sys
from pathlib import Path

agent_id, batch_id = sys.argv[1], sys.argv[2]
repo = Path("C:/Users/arro/Downloads/Opengrad")
transcript = Path(
    "C:/Users/arro/.claude/projects/C--Users-arro-Downloads-Opengrad/"
    f"a4718da9-447f-4538-88d4-459232648e01/subagents/agent-{agent_id}.jsonl"
)
batch_dir = repo / ".annotation" / "pdet-v1.model-batches" / "model-a"
batch_md = f"C:\\Users\\arro\\Downloads\\OpenGrad\\.annotation\\pdet-v1.model-batches\\model-a\\batch-{batch_id}.md"
procedure = (repo / "configs/annotation/pdet-v1.model-procedure.md").read_text(encoding="utf-8")
expected_prompt = procedure.rstrip("\n") + "\n\nBatch file: " + batch_md

records = [json.loads(line) for line in transcript.read_text(encoding="utf-8").splitlines() if line.strip()]
prompt = None
texts: list[str] = []
tools: list[dict] = []
models: set[str] = set()
for rec in records:
    msg = rec.get("message") or {}
    content = msg.get("content")
    if msg.get("role") == "user" and prompt is None:
        prompt = content if isinstance(content, str) else "".join(
            p.get("text", "") for p in content or [] if isinstance(p, dict) and p.get("type") == "text"
        )
    if msg.get("role") == "assistant":
        if msg.get("model"):
            models.add(msg["model"])
        for part in content if isinstance(content, list) else []:
            if part.get("type") == "text" and part.get("text", "").strip():
                texts.append(part["text"])
            if part.get("type") == "tool_use":
                tools.append({"name": part.get("name"), "input": part.get("input")})

problems = []
if (prompt or "").strip() != expected_prompt.strip():
    problems.append("prompt differs from the pinned procedure + batch line")
for call in tools:
    target = str((call["input"] or {}).get("file_path", ""))
    if call["name"] != "Read" or target.lower() != batch_md.lower():
        problems.append(f"tool call outside the batch file: {call['name']} {target}")
if models != {"claude-opus-5"}:
    problems.append(f"model(s) {sorted(models)} are not the declared claude-opus-5")
if not texts:
    problems.append("no final answer text")
answers_path = batch_dir / f"batch-{batch_id}.answers.json"
if answers_path.exists():
    problems.append(f"{answers_path.name} already exists")
if problems:
    print("AUDIT FAIL:\n  - " + "\n  - ".join(problems))
    sys.exit(1)

answer_text = texts[-1]
answers = json.loads(answer_text.strip())
answers_path.write_text(answer_text, encoding="utf-8")
audit = {
    "batch_id": batch_id,
    "subagent_transcript": str(transcript),
    "transcript_sha256": hashlib.sha256(transcript.read_bytes()).hexdigest(),
    "prompt_equals_procedure_plus_batch_line": True,
    "procedure_sha256": hashlib.sha256((repo / "configs/annotation/pdet-v1.model-procedure.md").read_bytes()).hexdigest(),
    "models": sorted(models),
    "tool_calls": [{"name": c["name"], "file_path": (c["input"] or {}).get("file_path"),
                    "offset": (c["input"] or {}).get("offset"), "limit": (c["input"] or {}).get("limit")} for c in tools],
    "answers_file": answers_path.name,
    "answers_sha256": hashlib.sha256(answer_text.encode("utf-8")).hexdigest(),
    "answers": len(answers),
}
(batch_dir / f"batch-{batch_id}.audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
labels: dict[str, int] = {}
for a in answers:
    labels[a.get("label")] = labels.get(a.get("label"), 0) + 1
print(f"AUDIT PASS batch {batch_id}: {len(answers)} answers; {len(tools)} Read calls, batch file only; "
      f"model {sorted(models)}; flagged {sum(1 for a in answers if a.get('flag'))}")

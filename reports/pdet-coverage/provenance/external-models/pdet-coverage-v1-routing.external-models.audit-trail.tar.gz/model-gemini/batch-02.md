# Annotation batch 02 -- task pdet-coverage-v1-routing

5 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Checklist (26) -->

# 26 — P-DET annotator checklist

Read before each session. The rules are in 22 §1–§4 and 23 §2–§3 (the *Rubric* panel, key `i`); this
page only reminds.

**Before you start:** `python -m opengrad.verification.pdet --verify` must say `PASS`. Run it again when
you finish.

1. **Label the behaviour, not the words.** Decide what the assistant response *does* in its full situation
   — the user message, any context shown and the tools offered — not which keywords or punctuation it uses.
2. **A question mark is not automatically CLARIFY.** Ask whether the user's reply is *necessary* to complete
   the task correctly. A courtesy or rhetorical question after an answer is DIRECT (rules 1, 4, 8).
3. **Refusal-like wording is not automatically UNSUPPORTED.** Ask whether substantive content was *also*
   delivered (rule 3), and whether the missing thing is a capability or information the user could supply
   (rules 2, 6).
4. **Prose about a call is not a call.** CALL needs a machine-readable payload (rule 5).
5. **Work through the decision tree in order** (22 §3). Cite the boundary rule when one decided the label.
6. **Do not force a class.** If two modes are equally supported, the response is empty or truncated, the
   context needed is missing, or no tools are offered where that decides it: choose UNKNOWN and set the
   ambiguity status.
7. **A rationale is optional** (amendment 29). Pressing a mode saves the label and moves on. Write a short
   note in the rationale or note box when it helps you; leaving it out does not make a label less certain.
   Mark real uncertainty with the flag, or with UNKNOWN and its ambiguity status.
8. **Do not balance.** The counts in the Items panel track progress. A mode with few examples is a finding,
   not a target.
9. **Use only what the screen shows.** Do not open the population file or other P-DET files to look up an
   item's sampling metadata, and do not look at another pass.
10. **No assistants.** Do not ask an LLM, a classifier or another annotator for a suggestion. These labels
    are the human reference.

Flag (`f`) anything you want to revisit. You can change a label until the gold freeze; every change is
recorded with its time and reason.

Keys: `1` CALL · `2` DIRECT · `3` CLARIFY · `4` UNSUPPORTED · `5` UNKNOWN (set the ambiguity status first)
· `Enter` save from the rationale · `n`/`p` next/previous · `s` skip · `f` flag · `u` undo · `i` rubric
· `/` items.

<!-- rubric document: Protocol - modes, boundaries, decision tree (22 §1-4) -->

# 22 — P-DET protocol (frozen)

> Excerpt for annotation: sections 1., 2., 3., 4. only. The full frozen text is `docs/research/study-002/22-PDET-PROTOCOL.md`.

## 1. Policy modes (operational definitions)

The annotated quantity is **the intended behaviour represented by the assistant response, in context** — not
surface punctuation, not keywords, and not the word the upstream dataset used. A response ending in `?` is
not automatically `CLARIFY`; a response containing refusal-like language is not automatically `UNSUPPORTED`.

### 1.1 `CALL`

**Intended behaviour:** invoke an available tool.

- **Positive:** a machine-readable call payload is present — structured `tool_calls` on the assistant turn,
  a serialized JSON call (`{"name": …, "arguments": …}`), or an equivalent explicit call block.
- **Exclusion → `CLARIFY`:** no payload, and the response asks the user for something required before it can
  act.
- **Exclusion → `AMBIGUOUS`:** no payload, and the response only *describes*, *proposes* or *narrates* a
  call ("I would use `get_weather` here", "the right tool for this is X") without asking permission and
  without a payload. **Prose about a call is not a call.**
- **Exclusion → `AMBIGUOUS`:** the response names a tool that is **not** in the offered tool list.
- **Boundary:** "Shall I go ahead and call it?" — ceding control to the user *is* a request required to
  proceed → `CLARIFY`, not `CALL`.

### 1.2 `DIRECT` (canonical `ANSWER`)

**Intended behaviour:** respond without a tool, without requesting missing information, and without declining
capability.

- **Positive:** substantive content that answers or performs the user's request in prose, including
  reasoning, code, lists, enumerations, or an ordinary conversational reply.
- **Exclusion → `CLARIFY`:** the substantive content is *withheld* pending information only the user can
  supply, and the task cannot be completed correctly without it.
- **Exclusion → `UNSUPPORTED`:** the response declines, or explains that it cannot act.
- **Exclusion → `AMBIGUOUS`:** empty, truncated, or non-substantive (only a marker or an ellipsis).
- **Tolerated inside `DIRECT`:** a *courtesy* question after a complete answer ("Does that help?", "Want me
  to expand on step 3?"), rhetorical questions, an epistemic hedge embedded in a delivered answer, and a
  partial answer delivered with a caveat. Completeness is not required; **delivery** is.

### 1.3 `CLARIFY`

**Intended behaviour:** request information necessary to proceed correctly.

- **Positive:** asks for a missing *required* element (a tool parameter, an identifier, a subject, a
  destination) **or** asks to disambiguate genuinely ambiguous intent where proceeding risks a wrong action.
  The request must be *necessary* for correct completion.
- **Exclusion → `DIRECT`:** the question is optional, stylistic or social, and the answer was delivered.
- **Exclusion → `UNSUPPORTED`:** the response asks the *user* to perform the task, or to use an external
  service, as a substitute for doing it. That is a decline, however politely phrased.
- **Exclusion → `AMBIGUOUS`:** several questions are asked and none is demonstrably required.
- **Rule when mixed:** if one request is required and others are courtesy, the required request dominates →
  `CLARIFY`, and the rationale records which request was required.
- **Boundary vs `UNSUPPORTED`:** inability *because a tool or capability is absent* is `UNSUPPORTED` even
  when phrased interrogatively ("Do you have a tool that can read VINs?"), because the missing thing is
  capability, not user input.

### 1.4 `UNSUPPORTED`

**Intended behaviour:** the request cannot appropriately be performed with the available capabilities, so the
correct behaviour is to decline or explain the limitation.

- **Positive:** explicit inability or decline; refusal-shaped prose ("Apologies, but I'm unable to…",
  "I don't have the capability to…", "I can't access real-time data"); parking the task on an external
  service *instead of* performing it; stating the request falls outside the offered tools or scope.
- **Exclusion → `CLARIFY`:** the only missing thing is information the user could supply.
- **Exclusion → `DIRECT`:** an epistemic hedge inside an otherwise delivered answer ("I can't know your exact
  location, but at latitude X the answer is Y").
- **Exclusion → `DIRECT`:** a partial answer plus a caveat, where substantive content was delivered.
- **Boundary vs epistemic uncertainty:** *uncertainty about the world* is not tool-policy inability. "I'm not
  certain of today's rate" is not `UNSUPPORTED` on that basis alone; "I can't retrieve today's rate" is.
- **Boundary:** "I can't perform calculations" is `UNSUPPORTED` even though arithmetic is within a general
  model's ability — it is a policy-level inability to act, which is what the class is for.

### 1.5 `UNKNOWN` / `AMBIGUOUS` — an annotation status, not a mode

Assigned when the rubric cannot resolve the item to exactly one of the four modes: two modes are equally
supported; the response is empty, truncated or non-substantive; the intent is unreadable without context the
frozen record does not contain; or the offered tool list is empty so `CALL`-vs-`DIRECT` is undecidable.

It is **never** used to reach balance, and ambiguous material is **never** relabelled to complete coverage. It
is counted and reported, and excluded from per-class precision/recall denominators while remaining visible as
a human-ambiguity rate.

## 2. The eight boundary discriminations

| # | Discrimination | Resolving question (semantic, in this order) |
|---|---|---|
| 1 | `DIRECT` vs `CLARIFY` | Was substantive content delivered? If yes → `DIRECT`. If withheld pending user-supplied information → `CLARIFY`. |
| 2 | `CLARIFY` vs `UNSUPPORTED` | Is the missing thing *user input* → `CLARIFY`; is it *capability/tool/scope* → `UNSUPPORTED`. |
| 3 | `UNSUPPORTED` vs epistemic uncertainty | Does the response decline to **act**, or merely express doubt about the **world**? Only the former is `UNSUPPORTED`. |
| 4 | `DIRECT` vs rhetorical/interrogative prose | Does proceeding require the user to answer? If not, the question is rhetorical → `DIRECT`. |
| 5 | actual `CALL` vs describing a call | Is a machine-readable payload present? If not → not `CALL` (→ `CLARIFY` if it asks, else `AMBIGUOUS`). |
| 6 | inability from missing user info vs unavailable capability | Ask what would fix it: user supplying a value → `CLARIFY`; a tool that is absent → `UNSUPPORTED`. |
| 7 | ordinary factual uncertainty vs tool-policy inability | "I'm not sure" ≠ "I cannot act". |
| 8 | polite follow-up after a complete answer vs required clarification | Would completing the task correctly be impossible without the user's reply? If no → `DIRECT`. |

## 3. Annotation decision tree

Applied in this order. It resolves behaviour semantically so a human can reproduce labels; it deliberately
does **not** mirror any proposed regex cascade, and P-DET must be able to *fail* that cascade.

1. Is there a machine-readable tool-call payload? → **`CALL`**.
2. Is the response empty, truncated, or non-substantive? → **`AMBIGUOUS`**.
3. Does the response decline or state inability to perform the request? →
   does it *also* deliver substantive content? yes → **`DIRECT`** (part-answer with caveat);
   no → **`UNSUPPORTED`**.
4. Does the response ask the user for something? →
   is the reply *necessary* to complete the task correctly? yes → **`CLARIFY`**;
   no (courtesy/stylistic/optional) → **`DIRECT`**.
5. Is the response advice to use an external service *instead of* doing the task? → **`UNSUPPORTED`**.
6. Does the response only describe, propose or narrate a call, or name an unoffered tool? → **`AMBIGUOUS`**.
7. Otherwise, was substantive content delivered? yes → **`DIRECT`**; no → **`AMBIGUOUS`**.
8. If two rules compete and neither dominates → **`AMBIGUOUS`**. Never guess to fill a class.

## 4. Annotation procedure

- **Two independent passes are the target.** Each item is labelled by two annotators who do not see each
  other's labels. Disagreements are **preserved** (both original labels retained) and adjudicated by a third
  deterministic pass; the adjudicated label becomes the gold label, and the record keeps the full trail.
- **If only one annotator is practical**, this is recorded as an explicit limitation, and a deterministic
  adjudication procedure applies instead: every item whose rationale invokes a boundary rule (§2) and every
  item the annotator marks uncertain is re-read against §3 and must cite the rule used. A single-annotator
  P-DET **cannot** report inter-annotator agreement, and the report must say so.
- **Per-item preserved fields** (the frozen record schema): `pdet_id`, `source_dataset`, `source_revision`
  or its documented null, `source_id`/`upstream_id`, `raw_record_hash`, `canonical_hash`, the offered tool
  schema (or a hash of it), the **user context shown to the annotator**, the **assistant response**,
  `gold_policy_label`, `ambiguity_status`, `annotator_id`, `annotator_rationale`, `boundary_rule_cited`,
  `annotation_version`, and for duplicates `prompt_duplicate_group`.
- Annotators see context and tools, never the future classifier's output, and never its proposed rules.
- **Inter-annotator agreement** is reported as raw agreement and Cohen's κ over the four modes (excluding
  `AMBIGUOUS` from κ, reported separately). Disagreements are never resolved silently.

<!-- rubric document: Instrument - fields, deciding, passes (23 §2, 3, 5, 7) -->

# 23 — P-DET annotation instrument

> Excerpt for annotation: sections 2., 3., 5., 7. only. The full frozen text is `docs/research/study-002/23-PDET-ANNOTATION-INSTRUMENT.md`.

## 2. Fields you fill in

| Field | Allowed values | Required |
|---|---|---|
| `gold_policy_label` | `CALL` · `DIRECT` · `CLARIFY` · `UNSUPPORTED` | yes |
| `ambiguity_status` | `NONE` · `AMBIGUOUS_TWO_MODES` · `NON_SUBSTANTIVE` · `MISSING_CONTEXT` · `EMPTY_TOOLSET` | yes |
| `annotator_rationale` | free text — **one sentence** saying why | yes |
| `boundary_rule_cited` | `1`–`8` per [22 §2](22-PDET-PROTOCOL.md), or `none` | when a boundary decided it |
| `annotator_id` | your identifier | yes |
| `annotation_version` | `pdet-annotation-v1` | yes |

If `ambiguity_status != NONE`, set `gold_policy_label` to the string `UNKNOWN` and cite the reason. **Never
guess to fill a class**, and never reassign an item to reach a coverage target — shortfalls are legitimate
findings ([22 §5](22-PDET-PROTOCOL.md)).

Write your pass to a **new** file: `reports/pdet/pdet-v1.annotations.<annotator_id>.jsonl`, containing
`{"pdet_id", "gold_policy_label", "ambiguity_status", "annotator_rationale", "boundary_rule_cited",
"annotator_id", "annotation_version"}`. Do **not** edit `pdet-v1.population.jsonl` — the frozen population
stays frozen, and adjudication produces a separate file.

## 3. How to decide

Work through [22 §3](22-PDET-PROTOCOL.md) in order, and consult [22 §2](22-PDET-PROTOCOL.md) when two readings
compete. Annotate **the intended behaviour of the assistant response in context** — not its punctuation, and
not its keywords.

## 5. Two passes, then adjudication

1. **Pass A and Pass B** annotate independently. Neither sees the other's file, and neither consults any
   classifier output (none exists).
2. **Disagreements are preserved**, never overwritten. An item disagrees when the two passes differ on
   `gold_policy_label` or on `ambiguity_status`.
3. **Adjudication** produces `reports/pdet/pdet-v1.adjudicated.jsonl` holding, per item, **both** original
   labels, the adjudicated `gold_policy_label`, the deciding rule from [22 §3](22-PDET-PROTOCOL.md), and the
   adjudicator id.
4. **Report** raw agreement and Cohen's κ over the four modes, with `UNKNOWN` handled separately as in
   [22 §4](22-PDET-PROTOCOL.md).
5. If only one annotator is available, say so explicitly: the deterministic re-read procedure in
   [22 §4](22-PDET-PROTOCOL.md) applies, and **no inter-annotator agreement may be claimed**.

## 7. What not to do

- Do not iterate rules against P-DET and re-annotate to make a classifier pass. If the classifier changes
  after P-DET results are seen, P-DET becomes `DEVELOPMENT_EXPOSED` and a **second untouched validation set**
  is required ([22 §6](22-PDET-PROTOCOL.md)).
- Do not treat this population as model-evaluation data. It is ETL validation material and is disjoint from
  the confirmatory and DEV partitions by construction (verified: 0 overlap).
- Do not describe any result here as evidence that Study 002's policy improved. It validates a labelling
  component, nothing else.

<!-- rubric document: This population - DIRECT and post-tool responses (30 §2-3) -->

# 30 — P-DET-COVERAGE-v1: preregistration (adopted as `study_002_prereg_v4`, amended by `study_002_prereg_v5`)

> Excerpt for annotation: sections 2., 3. only. The full frozen text is `docs/research/study-002/30-PDET-COVERAGE-PREREGISTRATION-DRAFT.md`.

## 2. DIRECT, for this study

> **`DIRECT` means the assistant answers the user's request normally, without requiring or using a tool
> for that response.**

The classifier's **decision point** is the moment *before any tool has been used*. There, the assistant
either:
- calls a tool (**CALL**);
- answers (**DIRECT**);
- asks for something it needs (**CLARIFY**);
- declines or explains that it cannot act (**UNSUPPORTED**).

**UNKNOWN / AMBIGUOUS** stays an annotation status, not a fifth mode. Every other part of the rubric is
22 §1–§3 unchanged: positive criteria, exclusions, the eight boundary discriminations and the decision tree.
This definition narrows 22 §1.2 in one respect only, stated in §3. 22 is not edited.

## 3. Post-tool responses are excluded

A prose response written **after a tool result** (user → tool call → tool result → assistant prose) is a
*downstream tool-result response*. It is outside the four-way pre-action decision. It is **not DIRECT**,
is not forced into CALL, and is not annotated in this population.

**Rule.** A record in which any tool has been used is out of layer B (§4). A tool has been used when any
of these appears: an assistant turn with structured `tool_calls`, a `tool`-role message, or (proxy only)
a Glaive `<functioncall>` marker. The builder records every such record under the input contract's reason
(`STRUCTURAL_CALL` or `POST_TOOL_RESULT_RESPONSE`, 32 §4), with counts per source in the manifest. Records
whose first assistant turn is a structured call are eligible only for layer A.

Proxy scale, from `pdet-coverage-v1.supply-proxy.json`. The final turn is prose after tool use in:

| Source | Records |
|---|---:|
| Glaive | 49,287 |
| BUTTON | 7,941 (all of them) |
| ToolACE | 644 |

**Multi-turn tool-free records** are also out of the unit, under reason `MULTI_TURN_UNSUPPORTED` (32 §6). How
the classifier will label a conversation with several assistant turns is not specified (§12, B-2), so no
population can yet be built to match it. The proxy has 34,450 such Glaive records and 311 LoopTool
records. **No classifier permission on multi-turn records follows from P-DET evidence.** Covering them
takes a separately preregistered component, added as an amendment before any draw.

# Part 2 -- Items

## Item 1 -- `pdetcov:cae81337cb6738ba821a8b9e4ac27ed6e22503fd0b83e2efa08e3d470786be33`

### User message

```
Hi, I saw a dress that I liked in a store. It was originally priced at $200 but there's a 20% discount on it. Can you tell me how much it would cost after the discount?
```

### Assistant response being classified - text

*(empty)*

### Assistant response being classified - structured tool call

```json
[
  {
    "arguments": {
      "discount_percentage": 20,
      "original_price": 200
    },
    "id": "call_0000",
    "name": "calculate_discount"
  }
]
```

### Available tools

```json
[
  {
    "description": "Calculate the discounted price of a product",
    "name": "calculate_discount",
    "parameters": {
      "properties": {
        "discount_percentage": {
          "description": "The discount percentage",
          "type": "number"
        },
        "original_price": {
          "description": "The original price of the product",
          "type": "number"
        }
      },
      "required": [
        "original_price",
        "discount_percentage"
      ],
      "type": "object"
    }
  }
]
```

## Item 2 -- `pdetcov:f95b5df01a9aa1d71a210e11ed680d68285e96e4e4634dbb215affcad3ee7cc5`

### User message

```
Hi, I want to know how old is my friend John. His birth date is 1990-05-15.
```

### Assistant response being classified - text

*(empty)*

### Assistant response being classified - structured tool call

```json
[
  {
    "arguments": {
      "birth_date": "1990-05-15",
      "name": "John"
    },
    "id": "call_0000",
    "name": "calculate_age"
  }
]
```

### Available tools

```json
[
  {
    "description": "Calculate a person's age",
    "name": "calculate_age",
    "parameters": {
      "properties": {
        "birth_date": {
          "description": "The person's birth date",
          "format": "date",
          "type": "string"
        },
        "name": {
          "description": "The person's name",
          "type": "string"
        }
      },
      "required": [
        "name",
        "birth_date"
      ],
      "type": "object"
    }
  }
]
```

## Item 3 -- `pdetcov:e6ba85aedede71345d594a5c7715e3d23fbe13d8d05597b89454415807090415`

### User message

```
I need some recipes by the author John Doe. Please get me the first three pages of recipes.
```

### Assistant response being classified - text

*(empty)*

### Assistant response being classified - structured tool call

```json
[
  {
    "arguments": {
      "prostring_name": "John Doe",
      "start": 1
    },
    "id": "call_0000",
    "name": "Get Recipes by Author"
  },
  {
    "arguments": {
      "prostring_name": "John Doe",
      "start": 2
    },
    "id": "call_0001",
    "name": "Get Recipes by Author"
  },
  {
    "arguments": {
      "prostring_name": "John Doe",
      "start": 3
    },
    "id": "call_0002",
    "name": "Get Recipes by Author"
  }
]
```

### Available tools

```json
[
  {
    "description": "Retrieve a list of recipes authored by a specific user",
    "name": "Get Recipes by Author",
    "parameters": {
      "properties": {
        "prostring_name": {
          "description": "The name of the author for whom to retrieve recipes",
          "type": "string"
        },
        "q": {
          "default": "",
          "description": "A search query to filter recipes by name or description",
          "type": "string"
        },
        "start": {
          "default": "",
          "description": "The starting point for pagination (e.g., page number)",
          "type": "integer"
        }
      },
      "required": [
        "prostring_name"
      ],
      "type": "object"
    }
  },
  {
    "description": "Retrieve the logo of a restaurant chain by its name",
    "name": "Get Restaurant Logo by Chain Name",
    "parameters": {
      "properties": {
        "restaurantChainName": {
          "description": "The name of the restaurant chain",
          "type": "string"
        }
      },
      "required": [
        "restaurantChainName"
      ],
      "type": "object"
    }
  },
  {
    "description": "Retrieves a list of accounts related to a specific organization in the Food domain.",
    "name": "FindAccount",
    "parameters": {
      "properties": {
        "limit": {
          "description": "The number of accounts to retrieve per page.",
          "type": "number"
        },
        "organization": {
          "description": "The ID of the organization for which to retrieve accounts.",
          "type": "string"
        },
        "page": {
          "description": "The page number of the account list.",
          "type": "number"
        },
        "sort": {
          "description": "The sorting criteria for the account list.",
          "type": "string"
        }
      },
      "required": [
        "page",
        "limit",
        "organization",
        "sort"
      ],
      "type": "object"
    }
  },
  {
    "description": "This endpoint returns a list of the user's favorite Cameroonian dishes.",
    "name": "Get Favorite Cameroonian Dishes",
    "parameters": {
      "properties": {
        "limit": {
          "default": 10,
          "description": "The maximum number of dishes to return",
          "type": "integer"
        },
        "offset": {
          "default": 0,
          "description": "The starting point for the list of dishes",
          "type": "integer"
        },
        "user_id": {
          "description": "The unique identifier of the user",
          "type": "integer"
        }
      },
      "required": [
        "user_id"
      ],
      "type": "object"
    }
  }
]
```

## Item 4 -- `pdetcov:1d79af49ae729d6c06ece26fe4064c093b388a172864e211438817474126e2fa`

### User message

```
Can you tell me about the movie "Inception"?
```

### Assistant response being classified - text

*(empty)*

### Assistant response being classified - structured tool call

```json
[
  {
    "arguments": {
      "title": "Inception"
    },
    "id": "call_0000",
    "name": "get_movie_details"
  }
]
```

### Available tools

```json
[
  {
    "description": "Get details about a movie",
    "name": "get_movie_details",
    "parameters": {
      "properties": {
        "title": {
          "description": "The title of the movie",
          "type": "string"
        }
      },
      "required": [
        "title"
      ],
      "type": "object"
    }
  }
]
```

## Item 5 -- `pdetcov:d7b6384385fd22f3cc4b6e941747b1b051e4fdd873736fcc8308e248f4f1d01e`

### User message

```
Role definition:
 Inquirer: A user who raises an inquiry.
 Response assistant: Communicates with the inquirer and provides answers and solutions.

 Historical dialog data is as follows:
Inquirer: I just read an interesting post about recent changes in education policies. I'd like to add a comment to show my support. Can you help with that?
Response assistant: Can you provide the ID of the post you'd like to comment on?
Inquirer: Yes, the post ID is "Edu123PolicyUpdate".
Response assistant: Thank you. What would you like your comment to say exactly?
Inquirer: Please post, "Totally support this! Education needs these changes!"

 Please continue your answer given the historical dialog. Your role is the Response assistant.
```

### Assistant response being classified - text

*(empty)*

### Assistant response being classified - structured tool call

```json
[
  {
    "arguments": {
      "content": "Totally support this! Education needs these changes!",
      "post_id": "Edu123PolicyUpdate"
    },
    "id": "call_0000",
    "name": "commentOnSocialMediaPost"
  }
]
```

### Available tools

```json
[
  {
    "description": "Add a comment to a social media post related to education",
    "name": "commentOnSocialMediaPost",
    "parameters": {
      "properties": {
        "content": {
          "description": "The content of the comment",
          "type": "string"
        },
        "post_id": {
          "description": "The ID of the social media post to comment on",
          "type": "string"
        }
      },
      "required": [
        "post_id",
        "content"
      ],
      "type": "object"
    }
  }
]
```

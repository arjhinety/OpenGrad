# Annotation batch 16 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 301 -- `unc:3a036e344cbbf069a6acfc10a474da53b08461e9fb93ea5e5aca9243155ae686`

### Question

```
Who is going to be the winner of the 2048 Women's Bandy World Championship?
```

### Available tools

```json
[
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 302 -- `unc:5ee1aea34e081558b114883d0f9c2c9ee35e7248397a507be5fae5104c2ad3b6`

### Question

```
Which team or competitor will win the Waterford Premier Intermediate Hurling Championship in 2060?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 303 -- `unc:74b671cfadbc5b96170f494895f633928ef159fb8ee132b4267b641f4549da3b`

### Question

```
Who is going to be the winner of the 2035 PokerGO Cup?
```

### Available tools

```json
[
  {
    "description": "Calculate the Compound Annual Growth Rate (CAGR) given an initial investment value, a final investment value, and the number of years.",
    "name": "calculate_cagr",
    "parameters": {
      "properties": {
        "final_value": {
          "description": "The final investment value.",
          "type": "integer"
        },
        "initial_value": {
          "description": "The initial investment value.",
          "type": "integer"
        },
        "period_in_years": {
          "description": "The period of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_value",
        "final_value",
        "period_in_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  }
]
```

## Item 304 -- `unc:b3a251f0b9422b4e304f1cdfa58c2675ff73d56edaf9742c41ab7b913bcd6361`

### Question

```
What will the maximum temperature in Quzhou, People's Republic of China be on 16 April 2046?
```

### Available tools

```json
[
  {
    "description": "Sorts a given list in ascending or descending order.",
    "name": "array_sort",
    "parameters": {
      "properties": {
        "list": {
          "description": "The list of numbers to be sorted.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "order": {
          "description": "Order of sorting.",
          "enum": [
            "ascending",
            "descending"
          ],
          "type": "string"
        }
      },
      "required": [
        "list",
        "order"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 305 -- `unc:5e6eba497d907b03bbf5c8d575ce0d77052f39f14d984893ffc8e728a7398a6e`

### Question

```
In 2049, who will win the Campeonato Brasileiro Série A?
```

### Available tools

```json
[
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function identifies the RGB values of a named color.",
    "name": "identify_color_rgb",
    "parameters": {
      "properties": {
        "color_name": {
          "description": "Name of the color.",
          "type": "string"
        },
        "standard": {
          "description": "The color standard (e.g. basic, pantone). Default is 'basic'",
          "type": "string"
        }
      },
      "required": [
        "color_name"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generates a random number from a normal distribution given the mean and standard deviation.",
    "name": "random.normalvariate",
    "parameters": {
      "properties": {
        "mu": {
          "description": "Mean of the normal distribution.",
          "type": "integer"
        },
        "sigma": {
          "description": "Standard deviation of the normal distribution.",
          "type": "integer"
        }
      },
      "required": [
        "mu",
        "sigma"
      ],
      "type": "dict"
    }
  }
]
```

## Item 306 -- `unc:1bdbb3052e531a98666eafe200e5885d400da7d16f8f6e5648b0c7fe1509b599`

### Question

```
On 25 February 2039, what high temperature will Nanjing, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the circumference of a circle given the radius.",
    "name": "geometry.circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "Units for the output circumference measurement. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 307 -- `unc:f281dc44252b327281834fd21c3c7f24538755661c0362d1b26db39dba99879c`

### Question

```
Who will win the 2053 NCAA Women's Ice Hockey Tournament?
```

### Available tools

```json
[
  {
    "description": "Send an email to the specified email address.",
    "name": "send_email",
    "parameters": {
      "properties": {
        "bcc": {
          "description": "The email address to blind carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "body": {
          "description": "The body content of the email.",
          "type": "string"
        },
        "cc": {
          "description": "The email address to carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "subject": {
          "description": "The subject of the email.",
          "type": "string"
        },
        "to": {
          "description": "The email address to send to.",
          "type": "string"
        }
      },
      "required": [
        "to",
        "subject",
        "body"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 308 -- `unc:d619d7418b91500c17d9f9cf7c58c31d587598a8977119fdefe5659e3cfc4544`

### Question

```
Who will win the 2057 Atlantic Coast Conference softball tournament?
```

### Available tools

```json
[
  {
    "description": "Identify a bird species based on certain characteristics.",
    "name": "identify_bird",
    "parameters": {
      "properties": {
        "color": {
          "description": "Color of the bird.",
          "type": "string"
        },
        "habitat": {
          "description": "Habitat of the bird.",
          "type": "string"
        },
        "size": {
          "description": "Size of the bird. Default is 'small'",
          "enum": [
            "small",
            "medium",
            "large"
          ],
          "type": "string"
        }
      },
      "required": [
        "color",
        "habitat"
      ],
      "type": "dict"
    }
  }
]
```

## Item 309 -- `unc:01afd70149ab76f4084edb72fa40531862faa014945c5b5758466942408bc674`

### Question

```
Which team or competitor will win the Primera División de Bolivia in 2035?
```

### Available tools

```json
[
  {
    "description": "Calculate the neuronal activity (rate of firing) based on a given input synaptic rate, weight of inputs, and decay rate. Higher input or weight increases firing rate and higher decay rate decreases it.",
    "name": "calculate_neuronal_activity",
    "parameters": {
      "properties": {
        "decay_rate": {
          "description": "The rate at which the neuron's potential decays in the absence of inputs.",
          "type": "float"
        },
        "input_synaptic_rate": {
          "description": "The synaptic input rate, usually represented as number of inputs per second.",
          "type": "integer"
        },
        "weight": {
          "description": "The weight of the input, denoting its influence on the neuron's state. Default is 1.0.",
          "type": "float"
        }
      },
      "required": [
        "input_synaptic_rate",
        "decay_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 310 -- `unc:ea45ded611e672266d3f16d06b856cbd3897410af9672272cd9ee001cc824ed6`

### Question

```
In 2041, who will win the Women's Varsity Football?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a recipe based on name and its calorie content",
    "name": "find_recipe",
    "parameters": {
      "properties": {
        "maxCalories": {
          "default": 1000,
          "description": "The maximum calorie content of the recipe.",
          "type": "integer"
        },
        "recipeName": {
          "description": "The recipe's name.",
          "type": "string"
        }
      },
      "required": [
        "recipeName"
      ],
      "type": "dict"
    }
  }
]
```

## Item 311 -- `unc:d22675de0088197f5b1c66abb967fe687793b3f8f202a8a177a114bf543170db`

### Question

```
Which team or competitor will win the African Women's Youth Handball Championship in 2054?
```

### Available tools

```json
[
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the density of a substance based on its mass and volume.",
    "name": "calculate_density",
    "parameters": {
      "properties": {
        "mass": {
          "description": "The mass of the substance in kilograms.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of density. Default is kg/m³",
          "type": "string"
        },
        "volume": {
          "description": "The volume of the substance in cubic meters.",
          "type": "integer"
        }
      },
      "required": [
        "mass",
        "volume"
      ],
      "type": "dict"
    }
  }
]
```

## Item 312 -- `unc:cb6d7415889d566ef8f16231f28a1cd538e1ff61f1016e2e09564368fe1b5e05`

### Question

```
In 2040, who will win the Big Sky Conference women's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Generates a random number from a normal distribution given the mean and standard deviation.",
    "name": "random.normalvariate",
    "parameters": {
      "properties": {
        "mu": {
          "description": "Mean of the normal distribution.",
          "type": "integer"
        },
        "sigma": {
          "description": "Standard deviation of the normal distribution.",
          "type": "integer"
        }
      },
      "required": [
        "mu",
        "sigma"
      ],
      "type": "dict"
    }
  }
]
```

## Item 313 -- `unc:683897ddcaf142835f6c0054197684b7d91883006d2fc4fa0bad5db3eff665ed`

### Question

```
Which team or competitor won the European Women's Handball Championship in 1998?
```

### Available tools

```json
[
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 314 -- `unc:c761bda0ccf2b0e9d05d9c05ba57dc5dec52b36e154642199d2084f241bc93b4`

### Question

```
Which team or competitor won the Atlantic Sun Men's Basketball Tournament in 2018?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle given its base and height.",
    "name": "calculate_triangle_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure (defaults to 'units' if not specified)",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 315 -- `unc:f078a9d269e27fb4bc42b53c6a6f6275751eef85063d29fbc723b6e0fafde905`

### Question

```
How hot will it get in Berlin, Germany on 23 May 2043?
```

### Available tools

```json
[
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  }
]
```

## Item 316 -- `unc:edc978083f4e5b7f34d3561e47a67946e19e07bc262f0eaaa764a6cb8eeeae52`

### Question

```
Who will win the 2038 Saskatchewan Scotties Tournament of Hearts?
```

### Available tools

```json
[
  {
    "description": "Calculate the final speed of an object in free fall after a certain time, neglecting air resistance. The acceleration due to gravity is considered as -9.81 m/s^2",
    "name": "calculate_final_speed",
    "parameters": {
      "properties": {
        "gravity": {
          "description": "The acceleration due to gravity. Default is -9.81 m/s^2.",
          "type": "float"
        },
        "initial_speed": {
          "description": "The initial speed of the object in m/s. Default is 0 for an object at rest.",
          "type": "integer"
        },
        "time": {
          "description": "The time in seconds for which the object is in free fall.",
          "type": "integer"
        }
      },
      "required": [
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generate a travel itinerary based on specific destination, duration and daily budget, with preferred exploration type.",
    "name": "travel_itinerary_generator",
    "parameters": {
      "properties": {
        "daily_budget": {
          "description": "The maximum daily budget for the trip.",
          "type": "integer"
        },
        "days": {
          "description": "Number of days for the trip.",
          "type": "integer"
        },
        "destination": {
          "description": "Destination city of the trip.",
          "type": "string"
        },
        "exploration_type": {
          "default": "urban",
          "description": "The preferred exploration type.",
          "enum": [
            "nature",
            "urban",
            "history",
            "culture"
          ],
          "type": "string"
        }
      },
      "required": [
        "destination",
        "days",
        "daily_budget"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the probability of an event.",
    "name": "probabilities.calculate_single",
    "parameters": {
      "properties": {
        "event_outcomes": {
          "description": "The number of outcomes where the event occurs.",
          "type": "integer"
        },
        "round": {
          "description": "Round the answer to a specified number of decimal places. Defaults to 2.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "event_outcomes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 317 -- `unc:778b4690c880e987a2aece00d81a01e9d048b1cff53da7612f36645a1a1e857b`

### Question

```
What will the highest temperature recorded in Heihe, People's Republic of China be on 11 June 2041?
```

### Available tools

```json
[
  {
    "description": "Predict the price of a house in a given area based on number of bedrooms, bathrooms and area.",
    "name": "predict_house_price",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area of the house in square feet.",
          "type": "integer"
        },
        "bathrooms": {
          "description": "The number of bathrooms in the house.",
          "type": "integer"
        },
        "bedrooms": {
          "description": "The number of bedrooms in the house.",
          "type": "integer"
        },
        "location": {
          "description": "The location of the house in the format of city name.",
          "type": "string"
        }
      },
      "required": [
        "bedrooms",
        "bathrooms",
        "area",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Performs a Chi-Squared test for independence on a 2x2 contingency table.",
    "name": "chi_squared_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the Chi-Squared test. Default is 0.05.",
          "type": "float"
        },
        "table": {
          "description": "A 2x2 contingency table presented in array form.",
          "items": {
            "items": {
              "type": "integer"
            },
            "type": "array"
          },
          "type": "array"
        }
      },
      "required": [
        "table"
      ],
      "type": "dict"
    }
  }
]
```

## Item 318 -- `unc:3b742a14f381479276d48d73a6cbe87d414ab58a08518c64d5137fc900d1e590`

### Question

```
What will the highest temperature recorded in Yuxi, People's Republic of China be on 25 February 2055?
```

### Available tools

```json
[
  {
    "description": "Combine two primary paint colors and adjust the resulting color's lightness level.",
    "name": "mix_paint_color",
    "parameters": {
      "properties": {
        "color1": {
          "description": "The first primary color to be mixed.",
          "type": "string"
        },
        "color2": {
          "description": "The second primary color to be mixed.",
          "type": "string"
        },
        "lightness": {
          "description": "The desired lightness level of the resulting color in percentage. The default level is set to 50.",
          "type": "integer"
        }
      },
      "required": [
        "color1",
        "color2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 319 -- `unc:c8ebf455b53da13a4708bbc8a937387e542798a7fa976822b0647dc6ef47e51b`

### Question

```
What will the maximum temperature in Chittagong, Bangladesh be on 11 March 2049?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 320 -- `unc:6cfa75965769d6e9c9019f8a78892dd1ae5a4578a64d97f3fb6fd62c3c4242cd`

### Question

```
What will the maximum temperature in Monrovia, Liberia be on 2 July 2059?
```

### Available tools

```json
[
  {
    "description": "Calculate the density of a substance based on its mass and volume.",
    "name": "calculate_density",
    "parameters": {
      "properties": {
        "mass": {
          "description": "The mass of the substance in kilograms.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of density. Default is kg/m³",
          "type": "string"
        },
        "volume": {
          "description": "The volume of the substance in cubic meters.",
          "type": "integer"
        }
      },
      "required": [
        "mass",
        "volume"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Analyzes the DNA sequence based on a reference sequence and return any potential mutations.",
    "name": "analyze_dna_sequence",
    "parameters": {
      "properties": {
        "mutation_type": {
          "description": "Type of the mutation to be looked for in the sequence. Default to 'substitution'.",
          "enum": [
            "insertion",
            "deletion",
            "substitution"
          ],
          "type": "string"
        },
        "reference_sequence": {
          "description": "The reference DNA sequence.",
          "type": "string"
        },
        "sequence": {
          "description": "The DNA sequence to be analyzed.",
          "type": "string"
        }
      },
      "required": [
        "sequence",
        "reference_sequence"
      ],
      "type": "dict"
    }
  }
]
```

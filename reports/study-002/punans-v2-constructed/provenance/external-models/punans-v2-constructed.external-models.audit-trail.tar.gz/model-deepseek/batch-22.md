# Annotation batch 22 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 421 -- `unc:e0ae0a36dcae46d23cd423c965868e01c95b975ce70eecc06053d10382f01384`

### Question

```
In 2041, who will win the Atlantic Coast Conference football?
```

### Available tools

```json
[
  {
    "description": "Get the working hours of a museum in a specific location.",
    "name": "museum_working_hours.get",
    "parameters": {
      "properties": {
        "day": {
          "description": "Specific day of the week. Default is 'Monday'",
          "type": "string"
        },
        "location": {
          "description": "The location of the museum.",
          "type": "string"
        },
        "museum": {
          "description": "The name of the museum.",
          "type": "string"
        }
      },
      "required": [
        "museum",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of having 'success' outcome from binomial distribution.",
    "name": "prob_dist.binomial",
    "parameters": {
      "properties": {
        "p": {
          "description": "The probability of success on any given trial, defaults to 0.5",
          "type": "float"
        },
        "successes": {
          "description": "The number of success events.",
          "type": "integer"
        },
        "trials": {
          "description": "The number of independent experiments.",
          "type": "integer"
        }
      },
      "required": [
        "trials",
        "successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby vegan restaurants based on specific criteria like operating hours.",
    "name": "vegan_restaurant.find_nearby",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city and state, e.g. New York, NY, you should format it as City, State.",
          "type": "string"
        },
        "operating_hours": {
          "description": "Preferred latest closing time of the restaurant. E.g. if 11 is given, then restaurants that close at or after 11 PM will be considered. This is in 24 hour format. Default is 24.",
          "type": "integer"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 422 -- `unc:f2d3f0bc08c85817e4b213bfd6d89ec07461a4b2c7da76017e60bb8a74f0762d`

### Question

```
Who was the winner of the 2017 America East Conference women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area and circumference of a circle based on the radius.",
    "name": "calculate_circle_dimensions",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 423 -- `unc:e23d62ad97337f0b0ddd6439966d96e58563d4da9f51d2807c26b206c6edd4b8`

### Question

```
On 16 October 2055, what high temperature will Yangjiang, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 424 -- `unc:6b1e1c0a180acadb12969edcfdcad0344e9d5e13ba55707175f1cf842a0df3bd`

### Question

```
Who won the 2016 Aeroflot Open?
```

### Available tools

```json
[
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 425 -- `unc:a655573120d2ca63fe12358550b9b38ab106d2a40b9c9768e6b2f9359c18f49b`

### Question

```
On 4 June 2058, what high temperature will Krasnodar, Russia record?
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch the brain MRI report of the patient for a given status.",
    "name": "patient.get_mri_report",
    "parameters": {
      "properties": {
        "mri_type": {
          "description": "Type of the MRI. Default to be 'brain'.",
          "enum": [
            "brain",
            "spinal",
            "chest",
            "abdominal"
          ],
          "type": "string"
        },
        "patient_id": {
          "description": "The patient identifier.",
          "type": "string"
        },
        "status": {
          "description": "Status of the report, could be 'in progress', 'concluded' or 'draft'.",
          "enum": [
            "in progress",
            "concluded",
            "draft"
          ],
          "type": "string"
        }
      },
      "required": [
        "patient_id",
        "status"
      ],
      "type": "dict"
    }
  }
]
```

## Item 426 -- `unc:9cdb4e00c1a4d70417c7ad375e1bc8bc5d8a4291e68e625187e37e9f8baad089`

### Question

```
On 27 February 2038, what high temperature will Port Harcourt, Nigeria record?
```

### Available tools

```json
[
  {
    "description": "Locate a flute for sale based on specific requirements.",
    "name": "find_flute",
    "parameters": {
      "properties": {
        "brand": {
          "description": "The brand of the flute. Example, 'Yamaha'",
          "type": "string"
        },
        "specs": {
          "description": "The specifications of the flute desired.",
          "items": {
            "enum": [
              "open hole",
              "C foot",
              "silver headjoint"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "brand",
        "specs"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  }
]
```

## Item 427 -- `unc:6864de0f75627b83c12ea67d12265c83e11d523c7b7e1f542fc0104ae45ab1e1`

### Question

```
What will the maximum temperature in Şanlıurfa, Turkey be on 25 December 2038?
```

### Available tools

```json
[
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 428 -- `unc:f9118439f2465268f133e02380344fa1811029fa9762ca214e1030839e7839e1`

### Question

```
Who is going to be the winner of the 2052 NBA Cup?
```

### Available tools

```json
[
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 429 -- `unc:ff49139144c723a955d9bf0d731906aa2edbef1cc695b5d278f500db2da73cb3`

### Question

```
In 2047, who will win the Match des Champions?
```

### Available tools

```json
[
  {
    "description": "Predict the evolutionary rate for a specific species for a given timeframe.",
    "name": "prediction.evolution",
    "parameters": {
      "properties": {
        "model": {
          "description": "The model used to make the prediction, options: 'Darwin', 'Lamarck', default is 'Darwin'.",
          "type": "string"
        },
        "species": {
          "description": "The species that the evolution rate will be predicted for.",
          "type": "string"
        },
        "years": {
          "description": "Number of years for the prediction.",
          "type": "integer"
        }
      },
      "required": [
        "species",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 430 -- `unc:78dfefb33b2d95bfcaa4fae20bdd6589fab817e36d983de15d4380dc2002aa0b`

### Question

```
On 15 December 2055, what high temperature will Bengbu, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Perform sentiment analysis on a given piece of text.",
    "name": "sentiment_analysis",
    "parameters": {
      "properties": {
        "language": {
          "description": "The language in which the text is written.",
          "type": "string"
        },
        "text": {
          "description": "The text on which to perform sentiment analysis.",
          "type": "string"
        }
      },
      "required": [
        "text",
        "language"
      ],
      "type": "dict"
    }
  }
]
```

## Item 431 -- `unc:b0c5d255b12c35a0fdfe84bca7142d87d725bc65663b11f9ce0d2cab265a1db4`

### Question

```
What was the population of Osaka, Japan as of 2014?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 432 -- `unc:0cb44e25770f3cd221b0e5da8c2a00d282dab72de65f90907c823b5c1eb9ecd2`

### Question

```
What will the highest temperature recorded in Shantou, People's Republic of China be on 18 June 2037?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for an initial principal amount.",
    "name": "calculate_compound_interest",
    "parameters": {
      "properties": {
        "n": {
          "description": "The number of times that interest is compounded per time period. Default is 1.",
          "type": "integer"
        },
        "principal": {
          "description": "The principal amount that the interest is applied to.",
          "type": "integer"
        },
        "rate": {
          "description": "The annual interest rate. Enter as a decimal. E.g, 5% is 0.05",
          "type": "float"
        },
        "time": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "rate",
        "time"
      ],
      "type": "dict"
    }
  }
]
```

## Item 433 -- `unc:102b75900282df2b3a14fb4eed349cc8567cee2a25eaf433e31ff9bd0aab4514`

### Question

```
What will the maximum temperature in Pingliang, People's Republic of China be on 15 July 2055?
```

### Available tools

```json
[
  {
    "description": "Calculate the Net Present Value (NPV) for a series of cash flows discounted at a certain interest rate.",
    "name": "finance_calculator.npv",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "A list of cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The annual interest rate used to discount the cash flows.",
          "type": "float"
        },
        "years": {
          "description": "A list of years when the cash flow occurs. Default is empty array.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 434 -- `unc:2aaf02cdb5784347457a03c4a329d5e6e125cfd76a3c4722cc024636fd28587b`

### Question

```
Which team or competitor will win the Vasaloppet in 2036?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 435 -- `unc:383839bd23897f52d17827eeb0cecbf49cf6e600138f025dbfb86fcced13fa7c`

### Question

```
In 2056, who will win the All-Ireland Junior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 436 -- `unc:4119dc6a451a4ea7f968a04132432839a4d930e3715000676e284c0a3a5551b0`

### Question

```
What will the highest temperature recorded in Nairobi, Kenya be on 28 April 2037?
```

### Available tools

```json
[
  {
    "description": "Calculate the distance between two locations, considering terrain.",
    "name": "distance_calculator.calculate",
    "parameters": {
      "properties": {
        "consider_terrain": {
          "description": "Whether to account for terrain in distance calculation, defaults to false.",
          "type": "boolean"
        },
        "destination": {
          "description": "Destination location of the distance measurement.",
          "type": "string"
        },
        "origin": {
          "description": "Starting location of the distance measurement.",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  }
]
```

## Item 437 -- `unc:de51869d7c6fe0b91b52f3102120abaca427d6438371d788664bbaf47e02f966`

### Question

```
What will the highest temperature recorded in Lima, Peru be on 3 June 2044?
```

### Available tools

```json
[
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

## Item 438 -- `unc:b61400a6b48695b11471ed6d0de50a8f846ad48b5d9e75cfa5399f960a89be3f`

### Question

```
Who won the 2018 Big Ten women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 439 -- `unc:398735fc6814b835d51b854d3c6806861c22720a6a851080078b462994573402`

### Question

```
On 7 October 2044, what high temperature will Shuozhou, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the neuronal activity (rate of firing) based on a given input synaptic rate, weight of inputs, and decay rate. Higher input or weight increases firing rate and higher decay rate decreases it.",
    "name": "calculate_neuronal_activity",
    "parameters": {
      "properties": {
        "decay_rate": {
          "description": "The rate at which the neuron's potential decays in the absence of inputs.",
          "type": "float"
        },
        "input_synaptic_rate": {
          "description": "The synaptic input rate, usually represented as number of inputs per second.",
          "type": "integer"
        },
        "weight": {
          "description": "The weight of the input, denoting its influence on the neuron's state. Default is 1.0.",
          "type": "float"
        }
      },
      "required": [
        "input_synaptic_rate",
        "decay_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 440 -- `unc:4a4591f8ccc16c35a9410ea007c0a858bb9dbb06d1dde65262b5206e12f8ee1e`

### Question

```
Who will win the 2059 Ohio Valley Conference men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electrostatic potential between two charged bodies using the principle of Coulomb's Law.",
    "name": "calculate_electrostatic_potential",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The quantity of charge on the first body.",
          "type": "float"
        },
        "charge2": {
          "description": "The quantity of charge on the second body.",
          "type": "float"
        },
        "constant": {
          "description": "The value of the electrostatic constant. Default is 8.99e9.",
          "type": "float"
        },
        "distance": {
          "description": "The distance between the two bodies.",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 04 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 61 -- `unc:c7cfb019507bc485197458ce7681e84e2b1660d139dfda93215eae519a87985f`

### Question

```
How hot will it get in Panjin, People's Republic of China on 7 November 2057?
```

### Available tools

```json
[
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 62 -- `unc:d0f5eb8d1371b94f2915e27bb840cda7b73e9fcfd9c7e33ae6e64b6d1339e145`

### Question

```
How hot will it get in Johannesburg, South Africa on 19 January 2052?
```

### Available tools

```json
[
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  }
]
```

## Item 63 -- `unc:e9d2ca91900828b4dee104d009e84394579a50ebf1e6a16d07571d15f64a2294`

### Question

```
What will the highest temperature recorded in Langfang, People's Republic of China be on 20 February 2053?
```

### Available tools

```json
[
  {
    "description": "Find the latest court case between two companies.",
    "name": "find_latest_court_case",
    "parameters": {
      "properties": {
        "company1": {
          "description": "The name of the first company.",
          "type": "string"
        },
        "company2": {
          "description": "The name of the second company.",
          "type": "string"
        },
        "country": {
          "default": "USA",
          "description": "The country in which the court case is located.",
          "type": "string"
        }
      },
      "required": [
        "company1",
        "company2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 64 -- `unc:16df75ec46982572b7eb072aa1bb73caafbae534f65f88ce0ab1f2683ca6a45b`

### Question

```
What will the highest temperature recorded in Ordos City, People's Republic of China be on 12 September 2051?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "probabilities.calculate_single",
    "parameters": {
      "properties": {
        "event_outcomes": {
          "description": "The number of outcomes where the event occurs.",
          "type": "integer"
        },
        "round": {
          "description": "Round the answer to a specified number of decimal places. Defaults to 2.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "event_outcomes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 65 -- `unc:8215e89dbdef2c2274d65bd68f42ced0ddb7d10ea43823299deafb920c69a74b`

### Question

```
Who is going to be the winner of the 2036 Ridsportallsvenskan?
```

### Available tools

```json
[
  {
    "description": "Calculate the distance between two locations, considering terrain.",
    "name": "distance_calculator.calculate",
    "parameters": {
      "properties": {
        "consider_terrain": {
          "description": "Whether to account for terrain in distance calculation, defaults to false.",
          "type": "boolean"
        },
        "destination": {
          "description": "Destination location of the distance measurement.",
          "type": "string"
        },
        "origin": {
          "description": "Starting location of the distance measurement.",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of having 'success' outcome from binomial distribution.",
    "name": "prob_dist.binomial",
    "parameters": {
      "properties": {
        "p": {
          "description": "The probability of success on any given trial, defaults to 0.5",
          "type": "float"
        },
        "successes": {
          "description": "The number of success events.",
          "type": "integer"
        },
        "trials": {
          "description": "The number of independent experiments.",
          "type": "integer"
        }
      },
      "required": [
        "trials",
        "successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 66 -- `unc:3186875ecd7424d4ad81412a75db14e1cf632848394ab08b97423089dfd0441d`

### Question

```
How many people lived in Hechi, People's Republic of China in 2018?
```

### Available tools

```json
[
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 67 -- `unc:f75b13d28e44d5a3c960327275e21f5ee2b1f5cf921fdcb86352648fbc167064`

### Question

```
In 2021, what was the population of Balıkesir, Turkey?
```

### Available tools

```json
[
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 68 -- `unc:683417ab0e9cdf86dd34b889bd2652c3802177f3200aed56f03ea0657ec1c8ff`

### Question

```
Which team or competitor will win the Takarazuka Kinen in 2060?
```

### Available tools

```json
[
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 69 -- `unc:27bbed88b11c45a6a7d8f957fd3e8e1c8865f73cbe91a11f226ba8f6e3ee4578`

### Question

```
Who is going to be the winner of the 2041 AFL Women's?
```

### Available tools

```json
[
  {
    "description": "Build a linear regression model using given predictor variables and a target variable.",
    "name": "run_linear_regression",
    "parameters": {
      "properties": {
        "predictors": {
          "description": "Array containing the names of predictor variables.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "standardize": {
          "description": "Option to apply standardization on the predictors. Defaults to False.",
          "type": "boolean"
        },
        "target": {
          "description": "The name of target variable.",
          "type": "string"
        }
      },
      "required": [
        "predictors",
        "target"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 70 -- `unc:388217b72d7df6d2ac266688d4cee9a596d8929ae01b3d89b53440b7cd219f9e`

### Question

```
Who is going to be the winner of the 2047 Women's Basketball Invitational?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 71 -- `unc:834fd7ab4576db5de32adb0e3d052c93ddaaa04e708231e98879b4f81fb07425`

### Question

```
Who is going to be the winner of the 2049 European Billard Artistique Championships?
```

### Available tools

```json
[
  {
    "description": "Calculate the Compound Annual Growth Rate (CAGR) given an initial investment value, a final investment value, and the number of years.",
    "name": "calculate_cagr",
    "parameters": {
      "properties": {
        "final_value": {
          "description": "The final investment value.",
          "type": "integer"
        },
        "initial_value": {
          "description": "The initial investment value.",
          "type": "integer"
        },
        "period_in_years": {
          "description": "The period of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_value",
        "final_value",
        "period_in_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby vegan restaurants based on specific criteria like operating hours.",
    "name": "vegan_restaurant.find_nearby",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city and state, e.g. New York, NY, you should format it as City, State.",
          "type": "string"
        },
        "operating_hours": {
          "description": "Preferred latest closing time of the restaurant. E.g. if 11 is given, then restaurants that close at or after 11 PM will be considered. This is in 24 hour format. Default is 24.",
          "type": "integer"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 72 -- `unc:216a3d56e3ca09f2eb589eef7032e7f30eb725db93f03eb14820985756c205ac`

### Question

```
Which team or competitor won the European One-Cushion Championship in 2003?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  }
]
```

## Item 73 -- `unc:9cb35010b580e9424af3a19bd22e382ebeab31684c86a7937f050bfe1bb985e1`

### Question

```
In 2055, who will win the Rally Sur do Condado?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 74 -- `unc:a6f70be3eba7a0222e9c1a98b971c1076bcb13fd73774d6cae8990d5cad725a0`

### Question

```
Who will win the 2058 Supercopa de España de Baloncesto?
```

### Available tools

```json
[
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 75 -- `unc:6aa499f91be56f30c6ae35e979a2ae4edbc27e6ce48f195503a61b1b0b1c950b`

### Question

```
Who will win the 2046 Satsuki Shō?
```

### Available tools

```json
[
  {
    "description": "Generates a customized law contract given involved parties, contract type and location.",
    "name": "generate_law_contract",
    "parameters": {
      "properties": {
        "contract_type": {
          "description": "Type of the contract.",
          "type": "string"
        },
        "location": {
          "description": "Location where the contract will be in effect.",
          "type": "string"
        },
        "parties": {
          "description": "Parties involved in the contract.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "parties",
        "contract_type",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 76 -- `unc:6aea62b15d18312d273c786603a2c251766e0725b2fc9f9a12080980f5791ecc`

### Question

```
What will the maximum temperature in Rosario, Argentina be on 10 September 2037?
```

### Available tools

```json
[
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 77 -- `unc:34021a1bf1a822be4ad69732e5c67180dc415dd4afbc56d1d07f102de040ba53`

### Question

```
What will the highest temperature recorded in Sydney, Australia be on 4 July 2037?
```

### Available tools

```json
[
  {
    "description": "Find details of lawsuits involving a specific company from a given year.",
    "name": "lawsuit_details.find",
    "parameters": {
      "properties": {
        "case_type": {
          "description": "Type of the lawsuit, e.g., 'IPR', 'Patent', 'Commercial', etc. Default is 'all'.",
          "type": "string"
        },
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "year": {
          "description": "Year of the lawsuit.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  }
]
```

## Item 78 -- `unc:8b2cccb5f5795ad41121ee9d5e60a16045b7879ece2946041536893a6d8682d2`

### Question

```
Who is going to be the winner of the 2057 Campeonato Brasileiro Série B?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of rolling a certain number on a six-sided die a certain number of times in a row.",
    "name": "probability.dice_roll",
    "parameters": {
      "properties": {
        "desired_number": {
          "description": "The number you want to roll.",
          "type": "integer"
        },
        "die_sides": {
          "description": "The number of sides on the die (optional; default is 6).",
          "type": "integer"
        },
        "number_of_rolls": {
          "description": "How many times you want to roll that number in a row.",
          "type": "integer"
        }
      },
      "required": [
        "desired_number",
        "number_of_rolls"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  }
]
```

## Item 79 -- `unc:bbaead6648bf7c11a6f070bae1311b1ee804271523e1b24bf70138ac44e1d0a7`

### Question

```
In 2042, who will win the NASCAR Truck Series?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "calculate_probability",
    "parameters": {
      "properties": {
        "favorable_outcomes": {
          "description": "Number of outcomes considered as 'successful'.",
          "type": "integer"
        },
        "round_to": {
          "default": 2,
          "description": "Number of decimal places to round the result to.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "Total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "favorable_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the entropy change for an isothermal and reversible process.",
    "name": "calculate_entropy_change",
    "parameters": {
      "properties": {
        "final_temp": {
          "description": "The final temperature in Kelvin.",
          "type": "integer"
        },
        "heat_capacity": {
          "description": "The heat capacity in J/K.",
          "type": "integer"
        },
        "initial_temp": {
          "description": "The initial temperature in Kelvin.",
          "type": "integer"
        },
        "isothermal": {
          "description": "Whether the process is isothermal. Default is True.",
          "type": "boolean"
        }
      },
      "required": [
        "initial_temp",
        "final_temp",
        "heat_capacity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 80 -- `unc:c2335da794512f1e60fe16489f1685d1783dc8aa456bf1759e6b3100f3ad51e0`

### Question

```
In 2047, who will win the IIHF World Junior Championship?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get stock price data for a given company over a specified number of days.",
    "name": "stock_price",
    "parameters": {
      "properties": {
        "company": {
          "description": "The company name.",
          "type": "string"
        },
        "data_type": {
          "description": "The type of price data to retrieve (e.g., 'Open', 'Close', 'High', 'Low'). Default is 'Close'.",
          "type": "string"
        },
        "days": {
          "description": "The number of previous days to retrieve data for.",
          "type": "integer"
        }
      },
      "required": [
        "company",
        "days"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

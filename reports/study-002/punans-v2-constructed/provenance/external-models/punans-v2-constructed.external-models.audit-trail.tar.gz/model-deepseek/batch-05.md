# Annotation batch 05 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 81 -- `unc:f6003cbd30affc1df2a6a772cb55e972a50208b5d28ba095d72413b3b1ca12ce`

### Question

```
Who will win the 2041 Kildare Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 82 -- `unc:700019049780f7ce6a8ef20baed22bcfee3ebb71dbddbeb383611390d7f62b65`

### Question

```
Which team or competitor will win the NCAA Division I Football Championship Subdivision in 2048?
```

### Available tools

```json
[
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Performs a Chi-Squared test for independence on a 2x2 contingency table.",
    "name": "chi_squared_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the Chi-Squared test. Default is 0.05.",
          "type": "float"
        },
        "table": {
          "description": "A 2x2 contingency table presented in array form.",
          "items": {
            "items": {
              "type": "integer"
            },
            "type": "array"
          },
          "type": "array"
        }
      },
      "required": [
        "table"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the annual carbon dioxide emissions produced by a vehicle based on the distance traveled, the fuel type and the fuel efficiency of the vehicle.",
    "name": "calculate_emissions",
    "parameters": {
      "properties": {
        "distance": {
          "description": "The distance travelled in miles.",
          "type": "integer"
        },
        "efficiency_reduction": {
          "description": "The percentage decrease in fuel efficiency per year (optional). Default is 0",
          "type": "integer"
        },
        "fuel_efficiency": {
          "description": "The vehicle's fuel efficiency in miles per gallon.",
          "type": "float"
        },
        "fuel_type": {
          "description": "Type of fuel used by the vehicle.",
          "type": "string"
        }
      },
      "required": [
        "distance",
        "fuel_type",
        "fuel_efficiency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 83 -- `unc:77adf250f0fe8af738011b823d62e902a9fc42682c123a956ec3cf38c6174d5e`

### Question

```
Who will win the 2039 UEFA Super Cup?
```

### Available tools

```json
[
  {
    "description": "Get the list of proteins in a specific cell compartment.",
    "name": "cellbio.get_proteins",
    "parameters": {
      "properties": {
        "cell_compartment": {
          "description": "The specific cell compartment.",
          "type": "string"
        },
        "include_description": {
          "default": "false",
          "description": "Set true if you want a brief description of each protein.",
          "type": "boolean"
        }
      },
      "required": [
        "cell_compartment"
      ],
      "type": "dict"
    }
  }
]
```

## Item 84 -- `unc:f7ee5b33a31b8eb73ee1b36dc0341eee3da8b4fc6a4b4bf4992d002b50f8939a`

### Question

```
In 2041, who will win the Big Sky Conference men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  }
]
```

## Item 85 -- `unc:ae3d0cc5f4d7686c98b2d06540e6bb3d0e4c1872444e84a4625e919b0797c4c3`

### Question

```
What will the maximum temperature in Luanda, Angola be on 27 June 2041?
```

### Available tools

```json
[
  {
    "description": "Locate a recipe based on name and its calorie content",
    "name": "find_recipe",
    "parameters": {
      "properties": {
        "maxCalories": {
          "default": 1000,
          "description": "The maximum calorie content of the recipe.",
          "type": "integer"
        },
        "recipeName": {
          "description": "The recipe's name.",
          "type": "string"
        }
      },
      "required": [
        "recipeName"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 86 -- `unc:e45983009ae45ff211b02be42bd373dde3b6b5e2a5d65aa207a436ebc928c5cd`

### Question

```
How hot will it get in Loudi, People's Republic of China on 10 February 2054?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  }
]
```

## Item 87 -- `unc:b0fb1a9857039252ba17a05c18b4a08a4b1cc6fe22d9cb34569069ca8cbd61c8`

### Question

```
Which team or competitor will win the Supercopa do Brasil de Futebol Feminino in 2055?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a curve for a specified function between two x values.",
    "name": "integrate",
    "parameters": {
      "properties": {
        "end_x": {
          "description": "The ending x-value to integrate over.",
          "type": "integer"
        },
        "function": {
          "description": "The function to integrate, represented as a string. For example, 'x^3'",
          "type": "string"
        },
        "method": {
          "description": "The method of numerical integration to use. Choices are 'trapezoid' or 'simpson'. Default is 'trapezoid'.",
          "type": "string"
        },
        "start_x": {
          "description": "The starting x-value to integrate over.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "start_x",
        "end_x"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a recipe based on name and its calorie content",
    "name": "find_recipe",
    "parameters": {
      "properties": {
        "maxCalories": {
          "default": 1000,
          "description": "The maximum calorie content of the recipe.",
          "type": "integer"
        },
        "recipeName": {
          "description": "The recipe's name.",
          "type": "string"
        }
      },
      "required": [
        "recipeName"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 88 -- `unc:754ce714bd3021e5faa247e6865348484a5f49b7b52d350cfc62ec8950329df9`

### Question

```
Which team or competitor won the Atlantic Hockey men's ice hockey tournament in 2007?
```

### Available tools

```json
[
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  }
]
```

## Item 89 -- `unc:ab16bc484d32f48bb4f94868f0e5ba385ace738339e2dc93eb329adba2391512`

### Question

```
On 14 June 2055, what high temperature will Shanwei, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the projected return of a stock investment given the investment amount, the annual growth rate and holding period in years.",
    "name": "calculate_stock_return",
    "parameters": {
      "properties": {
        "annual_growth_rate": {
          "description": "The expected annual growth rate of the stock.",
          "type": "float"
        },
        "dividends": {
          "description": "Optional. True if the calculation should take into account potential dividends. Default is false.",
          "type": "boolean"
        },
        "holding_period": {
          "description": "The number of years you intend to hold the stock.",
          "type": "integer"
        },
        "investment_amount": {
          "description": "The amount of money to invest.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_growth_rate",
        "holding_period"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Check the price of items at a specific Whole Foods location.",
    "name": "whole_foods.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items for which the price needs to be checked.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "Location of the Whole Foods store.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "items"
      ],
      "type": "dict"
    }
  }
]
```

## Item 90 -- `unc:dde7ff00b4b97fd7d5d8aec694987c957820bcd33ef0bb4e51eed668d568bea8`

### Question

```
How hot will it get in Harare, Zimbabwe on 20 November 2039?
```

### Available tools

```json
[
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 91 -- `unc:b80db6e09ce806abaa376394f4cfaf95fbe0e7bd00ec1810d332885f66134c79`

### Question

```
What will the maximum temperature in Xiamen, People's Republic of China be on 12 July 2051?
```

### Available tools

```json
[
  {
    "description": "Compute the probability of having 'success' outcome from binomial distribution.",
    "name": "prob_dist.binomial",
    "parameters": {
      "properties": {
        "p": {
          "description": "The probability of success on any given trial, defaults to 0.5",
          "type": "float"
        },
        "successes": {
          "description": "The number of success events.",
          "type": "integer"
        },
        "trials": {
          "description": "The number of independent experiments.",
          "type": "integer"
        }
      },
      "required": [
        "trials",
        "successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the neuronal activity (rate of firing) based on a given input synaptic rate, weight of inputs, and decay rate. Higher input or weight increases firing rate and higher decay rate decreases it.",
    "name": "calculate_neuronal_activity",
    "parameters": {
      "properties": {
        "decay_rate": {
          "description": "The rate at which the neuron's potential decays in the absence of inputs.",
          "type": "float"
        },
        "input_synaptic_rate": {
          "description": "The synaptic input rate, usually represented as number of inputs per second.",
          "type": "integer"
        },
        "weight": {
          "description": "The weight of the input, denoting its influence on the neuron's state. Default is 1.0.",
          "type": "float"
        }
      },
      "required": [
        "input_synaptic_rate",
        "decay_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 92 -- `unc:3c3cf7d76bbf13f33beb17aca798ec629fab497a261fee7f34f64fba52e58306`

### Question

```
In 2051, who will win the AfroBasket Women?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given stock based on its purchase price, sale price, and any dividends received.",
    "name": "calculate_return_on_investment",
    "parameters": {
      "properties": {
        "dividend": {
          "default": 0,
          "description": "Any dividends received from the stock.",
          "type": "integer"
        },
        "purchase_price": {
          "description": "The price the stock was bought at.",
          "type": "integer"
        },
        "sale_price": {
          "description": "The price the stock was sold at.",
          "type": "integer"
        }
      },
      "required": [
        "purchase_price",
        "sale_price"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compose a melody using the specified chord progression for a certain number of measures on specified instrument.",
    "name": "compose_melody",
    "parameters": {
      "properties": {
        "instrument": {
          "description": "The instrument for the composition. Default is 'Piano'.",
          "type": "string"
        },
        "measures": {
          "description": "The number of measures of the melody.",
          "type": "integer"
        },
        "progression": {
          "description": "The progression of chords.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "progression",
        "measures"
      ],
      "type": "dict"
    }
  }
]
```

## Item 93 -- `unc:972c0fb8529c2991a0bf57c3b95a5fdeefe4c5d9a17180cc7b0cfd173762fd12`

### Question

```
In 2054, who will win the MLS Cup?
```

### Available tools

```json
[
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 94 -- `unc:997b7632490ac284b6d5c75ae50f19d017583c376fc4afe316883579313b6b10`

### Question

```
What will the highest temperature recorded in Chicago, United States be on 25 September 2051?
```

### Available tools

```json
[
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 95 -- `unc:9fcdf4af6df57f75f4d8ecd2e4d218b7797a3e75d760d8c70304ef388d2a94b5`

### Question

```
What will the highest temperature recorded in Tehran, Iran be on 31 August 2052?
```

### Available tools

```json
[
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Performs a Chi-Squared test for independence on a 2x2 contingency table.",
    "name": "chi_squared_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the Chi-Squared test. Default is 0.05.",
          "type": "float"
        },
        "table": {
          "description": "A 2x2 contingency table presented in array form.",
          "items": {
            "items": {
              "type": "integer"
            },
            "type": "array"
          },
          "type": "array"
        }
      },
      "required": [
        "table"
      ],
      "type": "dict"
    }
  }
]
```

## Item 96 -- `unc:49807ed23a997d98cb80a03fc8cf6783495cadce682c746222ee3581e98024a8`

### Question

```
Who is going to be the winner of the 2035 Epsom Derby?
```

### Available tools

```json
[
  {
    "description": "Calculate the electromagnetic force between two charges placed at a certain distance.",
    "name": "electromagnetic_force",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The magnitude of the first charge in coulombs.",
          "type": "integer"
        },
        "charge2": {
          "description": "The magnitude of the second charge in coulombs.",
          "type": "integer"
        },
        "distance": {
          "description": "The distance between the two charges in meters.",
          "type": "integer"
        },
        "medium_permittivity": {
          "description": "The relative permittivity of the medium in which the charges are present. Default is 8.854e-12 (Vacuum Permittivity).",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 97 -- `unc:7dd6f614b2538c1f466bce100d0119c70dda6bf768df652cd94d2aa7a4ce5174`

### Question

```
What will the maximum temperature in Medan, Indonesia be on 10 February 2039?
```

### Available tools

```json
[
  {
    "description": "Calculate the entropy change for an isothermal and reversible process.",
    "name": "calculate_entropy_change",
    "parameters": {
      "properties": {
        "final_temp": {
          "description": "The final temperature in Kelvin.",
          "type": "integer"
        },
        "heat_capacity": {
          "description": "The heat capacity in J/K.",
          "type": "integer"
        },
        "initial_temp": {
          "description": "The initial temperature in Kelvin.",
          "type": "integer"
        },
        "isothermal": {
          "description": "Whether the process is isothermal. Default is True.",
          "type": "boolean"
        }
      },
      "required": [
        "initial_temp",
        "final_temp",
        "heat_capacity"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment in a specific stock based on the invested amount, expected annual return and number of years.",
    "name": "portfolio_future_value",
    "parameters": {
      "properties": {
        "expected_annual_return": {
          "description": "The expected annual return on investment as a decimal. E.g. 5% = 0.05",
          "type": "float"
        },
        "invested_amount": {
          "description": "The invested amount in USD.",
          "type": "integer"
        },
        "stock": {
          "description": "The ticker symbol of the stock.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "stock",
        "invested_amount",
        "expected_annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 98 -- `unc:2a605af859f8d694b37481d7027e6ec1dd8f6e1c5d201cc56ce987284b41361e`

### Question

```
What will the maximum temperature in Qujing, People's Republic of China be on 14 July 2046?
```

### Available tools

```json
[
  {
    "description": "Get the list of proteins in a specific cell compartment.",
    "name": "cellbio.get_proteins",
    "parameters": {
      "properties": {
        "cell_compartment": {
          "description": "The specific cell compartment.",
          "type": "string"
        },
        "include_description": {
          "default": "false",
          "description": "Set true if you want a brief description of each protein.",
          "type": "boolean"
        }
      },
      "required": [
        "cell_compartment"
      ],
      "type": "dict"
    }
  }
]
```

## Item 99 -- `unc:413858d18c7e8ffa6abc62d5ff284973eb56d46ec94ccfc99017cfca5867d748`

### Question

```
How hot will it get in Yancheng, People's Republic of China on 1 July 2035?
```

### Available tools

```json
[
  {
    "description": "Calculate the cooking time for a roast chicken.",
    "name": "calculate_cooking_time",
    "parameters": {
      "properties": {
        "cooking_method": {
          "description": "The method of cooking, defaults to 'roast'.",
          "type": "string"
        },
        "temp_celsius": {
          "description": "The cooking temperature in degrees celsius, defaults to 180.",
          "type": "integer"
        },
        "weight_kg": {
          "description": "The weight of the chicken in kilograms.",
          "type": "float"
        }
      },
      "required": [
        "weight_kg"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area and circumference of a circle based on the radius.",
    "name": "calculate_circle_dimensions",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 100 -- `unc:06224ca344337a13b3271a56236776824908271f19b80f4a847bd5df24ec8d37`

### Question

```
Who will win the 2049 FIBA U16 Asia Cup?
```

### Available tools

```json
[
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 31 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 601 -- `unc:496891b3b24efdeabdc06e0caf6f61149aab2713f8ef96463afbb244b31dbfbc`

### Question

```
In 2053, who will win the RFL Women's Challenge Cup?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  }
]
```

## Item 602 -- `unc:952e26237fca2094dea9c3ae3aec203596587c3c8ad9ae19cf4339cb801da362`

### Question

```
How many people lived in Yingkou, People's Republic of China in 2000?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  }
]
```

## Item 603 -- `unc:3e04b6713266cab2f4bd6d5a6e2bf95efff8af6dad0807e8ae84c33185440a84`

### Question

```
How many people lived in Guyuan, People's Republic of China in 2020?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 604 -- `unc:a9f3bf8866dfbe7b168e529b638b15581a21cccdbe9a5cb3283f8b88dc5961f7`

### Question

```
What will the maximum temperature in Hebi, People's Republic of China be on 26 November 2049?
```

### Available tools

```json
[
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 605 -- `unc:063b2d9cf32cde92c51dc5a1f0f58d69cdf04b944d5a576ddcc52d058f836bb6`

### Question

```
How hot will it get in Irbid, Jordan on 13 February 2050?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a mathematical function within a given interval.",
    "name": "calculate_area_under_curve",
    "parameters": {
      "properties": {
        "function": {
          "description": "The mathematical function as a string.",
          "type": "string"
        },
        "interval": {
          "description": "An array that defines the interval to calculate the area under the curve from the start to the end point.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "method": {
          "description": "The numerical method to approximate the area under the curve. The default value is 'trapezoidal'.",
          "type": "string"
        }
      },
      "required": [
        "function",
        "interval"
      ],
      "type": "dict"
    }
  }
]
```

## Item 606 -- `unc:d7f4ede8ed49e310e66fd3d3cdd3656657011061d2216c90c023f97e7fee71ae`

### Question

```
In 2020, who won the Walsh Cup?
```

### Available tools

```json
[
  {
    "description": "Calculate the discounted cash flow of a bond for a given annual coupon payment, time frame and discount rate.",
    "name": "calculate_discounted_cash_flow",
    "parameters": {
      "properties": {
        "coupon_payment": {
          "description": "The annual coupon payment.",
          "type": "integer"
        },
        "discount_rate": {
          "description": "The discount rate.",
          "type": "float"
        },
        "face_value": {
          "description": "The face value of the bond, default is 1000.",
          "type": "integer"
        },
        "period": {
          "description": "The time frame in years for which coupon payment is made.",
          "type": "integer"
        }
      },
      "required": [
        "coupon_payment",
        "period",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 607 -- `unc:4e9edf0ca3d85317319359899043cdb692f72a12d05cc1699b91b78d4c2d4679`

### Question

```
How hot will it get in Dakar, Senegal on 23 April 2036?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on location and food preferences.",
    "name": "find_restaurants",
    "parameters": {
      "properties": {
        "dietary_requirements": {
          "description": "Special dietary requirements, e.g. vegan, gluten-free. Default is empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "food_type": {
          "description": "The type of food preferred.",
          "type": "string"
        },
        "location": {
          "description": "The specific location or area. The location should be in the format of District, City.",
          "type": "string"
        },
        "number": {
          "description": "Number of results to return.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "food_type",
        "number"
      ],
      "type": "dict"
    }
  }
]
```

## Item 608 -- `unc:2d29f9c330f4f9695806a2b4668f97c93438d6e31d2c8da549051f27aa542d56`

### Question

```
What will the highest temperature recorded in Bhopal, India be on 2 May 2043?
```

### Available tools

```json
[
  {
    "description": "Find recipes based on dietary restrictions, meal type, and preferred ingredients.",
    "name": "find_recipes",
    "parameters": {
      "properties": {
        "diet": {
          "description": "The dietary restrictions, e.g., 'vegan', 'gluten-free'.",
          "type": "string"
        },
        "ingredients": {
          "description": "The preferred ingredients. If left blank, it will default to return general recipes.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "meal_type": {
          "description": "The type of meal, e.g., 'dinner', 'breakfast'.",
          "type": "string"
        }
      },
      "required": [
        "diet",
        "meal_type"
      ],
      "type": "dict"
    }
  }
]
```

## Item 609 -- `unc:f954429a5a0bc161707b8bbf82d9523a98b3bbad8b6ee0d801c0e639e4f4d970`

### Question

```
What will the highest temperature recorded in Zhangzhou, People's Republic of China be on 26 June 2058?
```

### Available tools

```json
[
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 610 -- `unc:7a64048e3f39cd476352125cc817a0469343a3b372b6f3be2c5d3de00a836b08`

### Question

```
Who is going to be the winner of the 2057 J.League Cup?
```

### Available tools

```json
[
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 611 -- `unc:40fb6689989a241d89baf91ffb1fcae2c35151f98dcea96f9e64007ba1602ef3`

### Question

```
What will the maximum temperature in Xuchang, People's Republic of China be on 4 March 2049?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby concerts based on specific criteria like genre.",
    "name": "concert.find_nearby",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Genre of music to be played at the concert.",
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Seattle, WA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 612 -- `unc:34b6b927c1a4e13d316cbdad45d64912db6f7d746f4e0d37d3caa02669711559`

### Question

```
What will the highest temperature recorded in City of Ekurhuleni Metropolitan Municipality, South Africa be on 8 April 2035?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 613 -- `unc:f687bdba290d986b43d0d2464b792b75ab812d97ef9aa6b4e1bf0e29c0647c69`

### Question

```
What was the population of Shenzhen, People's Republic of China as of 2022?
```

### Available tools

```json
[
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby concerts based on specific criteria like genre.",
    "name": "concert.find_nearby",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Genre of music to be played at the concert.",
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Seattle, WA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  }
]
```

## Item 614 -- `unc:b225bfe5083cb1b778cf083952198de161286763ec48b3eccf34538c5bfdd3a1`

### Question

```
Who is going to be the winner of the 2058 Autumn Gold Curling Classic?
```

### Available tools

```json
[
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Check the price of items at a specific Whole Foods location.",
    "name": "whole_foods.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items for which the price needs to be checked.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "Location of the Whole Foods store.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "items"
      ],
      "type": "dict"
    }
  }
]
```

## Item 615 -- `unc:097a93c4b5903688f3e2039729267472cf91e17f0d84ee536d81ddadba134fda`

### Question

```
Which team or competitor will win the NASCAR Canada Series in 2056?
```

### Available tools

```json
[
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  }
]
```

## Item 616 -- `unc:2d79e522857c5b4456f9670b039536d2bba3081ff31468333a810c76d6fbc018`

### Question

```
Who will win the 2043 Copa Catalunya de futbol femenina?
```

### Available tools

```json
[
  {
    "description": "Locate local nurseries based on location and plant types availability.",
    "name": "local_nursery.find",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city or locality where the nursery needs to be located.",
          "type": "string"
        },
        "plant_types": {
          "description": "Type of plants the nursery should provide.",
          "items": {
            "enum": [
              "Annual",
              "Perennial",
              "Shrub",
              "Tree",
              "Herbs",
              "Fruits"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "plant_types"
      ],
      "type": "dict"
    }
  }
]
```

## Item 617 -- `unc:5bd133ebdae0d56f5bf79dce8267d9dc01aaa9e5efffd097aecc6a3ff8d144d3`

### Question

```
Which team or competitor will win the Ukrainian Super Cup in 2050?
```

### Available tools

```json
[
  {
    "description": "Predicts the forest growth over the next N years based on current trends.",
    "name": "forest_growth_forecast",
    "parameters": {
      "properties": {
        "include_human_impact": {
          "description": "Whether or not to include the impact of human activities in the forecast. If not provided, defaults to false.",
          "type": "boolean"
        },
        "location": {
          "description": "The location where you want to predict forest growth.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for the forecast.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 618 -- `unc:90f4a3f58c09cc4171b0a20e358bbe651518530825513a5482d3db975e2cc343`

### Question

```
What will the maximum temperature in Tijuana, Mexico be on 18 May 2039?
```

### Available tools

```json
[
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 619 -- `unc:c0ff146815ffd736e08508f5ca79cdb578e65b6eaff22edf23cc6677844251a1`

### Question

```
What will the maximum temperature in Chaoyang, People's Republic of China be on 15 August 2053?
```

### Available tools

```json
[
  {
    "description": "Calculates the probability of an outcome based on the binomial distribution",
    "name": "calc_binomial_prob",
    "parameters": {
      "properties": {
        "num_success": {
          "description": "Number of times the event of interest has occurred.",
          "type": "integer"
        },
        "num_trials": {
          "description": "Number of independent experiments.",
          "type": "integer"
        },
        "prob_success": {
          "description": "Probability of the event of interest on any single experiment.",
          "type": "float"
        }
      },
      "required": [
        "num_trials",
        "num_success",
        "prob_success"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 620 -- `unc:4c8d50af7386b2e38bd0ae0b4e7e79b44f923ebd804724193c256a55cbfc4cf1`

### Question

```
Who won the 2005 Malaysia Premier League?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 21 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 401 -- `unc:4d29cbfa960e9115a691572314c1034cfa6cbb9bec054d43fbd11cc78cda86f0`

### Question

```
In 2042, who will win the Copa Verde?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  }
]
```

## Item 402 -- `unc:5386176de0982fa60d10785b5599552984e5d23b027f5b8309446fedbe8a663e`

### Question

```
Who is going to be the winner of the 2050 CAA women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 403 -- `unc:6610ee2cbf086d2aa2d5ccb2de816f53c57b70ef5c07c9225b45b816edeedeab`

### Question

```
How hot will it get in Brazzaville, Republic of the Congo on 7 July 2051?
```

### Available tools

```json
[
  {
    "description": "Locate the nearest parking lot based on a specific location and radius.",
    "name": "parking_lot.find_nearest",
    "parameters": {
      "properties": {
        "location": {
          "description": "The reference location e.g. Central Park, NY",
          "type": "string"
        },
        "radius": {
          "description": "The maximum distance from the location in miles. Default is 5 miles",
          "type": "integer"
        },
        "type": {
          "description": "The type of parking lot. Default is 'public'.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 404 -- `unc:116c74aebcbfcaeb94c18b23ddac0f91d4551c0391e5fa14420ffb1d7bfd3ec9`

### Question

```
What population did Maputo, Mozambique have in 2023?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given its radius.",
    "name": "geometry.calculate_area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit of the radius (optional parameter, default is 'units').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  }
]
```

## Item 405 -- `unc:da887eb72940c34fbb2a7a21978b62fa3316f7d2aef18bf23b1b7f915d78268d`

### Question

```
How hot will it get in Chifeng, People's Republic of China on 16 January 2054?
```

### Available tools

```json
[
  {
    "description": "Calculate the density of a substance based on its mass and volume.",
    "name": "calculate_density",
    "parameters": {
      "properties": {
        "mass": {
          "description": "The mass of the substance in kilograms.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of density. Default is kg/m³",
          "type": "string"
        },
        "volume": {
          "description": "The volume of the substance in cubic meters.",
          "type": "integer"
        }
      },
      "required": [
        "mass",
        "volume"
      ],
      "type": "dict"
    }
  }
]
```

## Item 406 -- `unc:8d2402f9c9bda67b1599a4f5d6a489bbe3cc0ee8c0a45f793b18f5a2a73927ad`

### Question

```
How hot will it get in Longnan, People's Republic of China on 18 August 2047?
```

### Available tools

```json
[
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  }
]
```

## Item 407 -- `unc:58bf4901b4a981c44ec8c6f741543b71b78eb60e94954efe4ad81e84d10c73aa`

### Question

```
Who is going to be the winner of the 2041 FIDE Women's Grand Swiss Tournament?
```

### Available tools

```json
[
  {
    "description": "Verify the details of a lawsuit case and check its status using case ID.",
    "name": "lawsuit.check_case",
    "parameters": {
      "properties": {
        "case_id": {
          "description": "The identification number of the lawsuit case.",
          "type": "integer"
        },
        "closed_status": {
          "description": "The status of the lawsuit case to be verified.",
          "type": "boolean"
        }
      },
      "required": [
        "case_id",
        "closed_status"
      ],
      "type": "dict"
    }
  }
]
```

## Item 408 -- `unc:529da3a11b7484b29f65907614725e6440f631a5efaed2735f813b8cccb0123e`

### Question

```
How hot will it get in Vasai-Virar, India on 14 February 2040?
```

### Available tools

```json
[
  {
    "description": "Examine the social dynamics and interactions within a group based on the personality traits and group size.",
    "name": "group_dynamics.pattern",
    "parameters": {
      "properties": {
        "extroverts": {
          "description": "The number of extroverted members in the group.",
          "type": "integer"
        },
        "introverts": {
          "description": "The number of introverted members in the group.",
          "type": "integer"
        },
        "total": {
          "description": "The total group size.",
          "type": "integer"
        }
      },
      "required": [
        "total",
        "extroverts",
        "introverts"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 409 -- `unc:247f5d535adb78e049fc1557e2cdf5aec6592b005bd3ef0759a74b3c4a77f58a`

### Question

```
What will the maximum temperature in Amritsar, India be on 28 January 2055?
```

### Available tools

```json
[
  {
    "description": "Calculates the circumference of a circle with a given radius.",
    "name": "calculate_circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle in the unit given.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measurement for the radius. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the probability of an event.",
    "name": "probability_of_event",
    "parameters": {
      "properties": {
        "format_as_ratio": {
          "description": "When true, formats the output as a ratio instead of a decimal. Default is false.",
          "type": "boolean"
        },
        "success_outcomes": {
          "description": "The number of successful outcomes.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "success_outcomes",
        "total_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 410 -- `unc:db45e046955dd647a35adec694140c6863d7e26bbc7c4bba203be73c5ba1ce80`

### Question

```
Who will win the 2048 Big West Conference men's volleyball tournament?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on location and food preferences.",
    "name": "find_restaurants",
    "parameters": {
      "properties": {
        "dietary_requirements": {
          "description": "Special dietary requirements, e.g. vegan, gluten-free. Default is empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "food_type": {
          "description": "The type of food preferred.",
          "type": "string"
        },
        "location": {
          "description": "The specific location or area. The location should be in the format of District, City.",
          "type": "string"
        },
        "number": {
          "description": "Number of results to return.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "food_type",
        "number"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Build a linear regression model using given predictor variables and a target variable.",
    "name": "run_linear_regression",
    "parameters": {
      "properties": {
        "predictors": {
          "description": "Array containing the names of predictor variables.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "standardize": {
          "description": "Option to apply standardization on the predictors. Defaults to False.",
          "type": "boolean"
        },
        "target": {
          "description": "The name of target variable.",
          "type": "string"
        }
      },
      "required": [
        "predictors",
        "target"
      ],
      "type": "dict"
    }
  }
]
```

## Item 411 -- `unc:7891ed79beaa538bf24cea265b5b0c7d98695dc8807e3619810182a0f0c2efc2`

### Question

```
On 24 July 2060, what high temperature will Jeddah, Saudi Arabia record?
```

### Available tools

```json
[
  {
    "description": "Find details of lawsuits involving a specific company from a given year.",
    "name": "lawsuit_details.find",
    "parameters": {
      "properties": {
        "case_type": {
          "description": "Type of the lawsuit, e.g., 'IPR', 'Patent', 'Commercial', etc. Default is 'all'.",
          "type": "string"
        },
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "year": {
          "description": "Year of the lawsuit.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

## Item 412 -- `unc:eeb040f4454e73b4db08ff7bb09f6f36b4256dd5fa856ef43d7cf34e4632f49e`

### Question

```
Who is going to be the winner of the 2037 Carlow GAA Senior Hurling Championship?
```

### Available tools

```json
[
  {
    "description": "Find the latest court case between two companies.",
    "name": "find_latest_court_case",
    "parameters": {
      "properties": {
        "company1": {
          "description": "The name of the first company.",
          "type": "string"
        },
        "company2": {
          "description": "The name of the second company.",
          "type": "string"
        },
        "country": {
          "default": "USA",
          "description": "The country in which the court case is located.",
          "type": "string"
        }
      },
      "required": [
        "company1",
        "company2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  }
]
```

## Item 413 -- `unc:fd98ac4242f56ace2ebe00ea4582c53448fb03ea30dd465ddcd67d8df36cead7`

### Question

```
How many people lived in Taichung, Taiwan in 1984?
```

### Available tools

```json
[
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  }
]
```

## Item 414 -- `unc:16164ef0a07c957044c3b0bd4db032fd4f977fc27292748f8d31e6f2fc9c9812`

### Question

```
On 11 February 2049, what high temperature will Ningbo, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 415 -- `unc:a5c92a0776be2d7da02d0c12d694ab93e55c99cf1d973296f10b1d4e38a5118a`

### Question

```
In 2005, who won the Women's Hockey Africa Cup of Nations?
```

### Available tools

```json
[
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 416 -- `unc:57d4245f8353aec4269c23405e2f77cbd930a0f66c9eab4cea34c23da1e4c1e6`

### Question

```
What will the highest temperature recorded in Astana, Kazakhstan be on 28 October 2060?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  }
]
```

## Item 417 -- `unc:e1bb31524e834a5a994307fdaa117f1b3710864c107d3c1eea5ec59eac1bbe80`

### Question

```
On 23 June 2038, what high temperature will Rizhao, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the Net Present Value (NPV) for a series of cash flows discounted at a certain interest rate.",
    "name": "finance_calculator.npv",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "A list of cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The annual interest rate used to discount the cash flows.",
          "type": "float"
        },
        "years": {
          "description": "A list of years when the cash flow occurs. Default is empty array.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 418 -- `unc:cc9cb06d36cd4e9ff762f9c7a171ed06d4ab3456741f697234a399cdc00c44b1`

### Question

```
How hot will it get in Zhaoqing, People's Republic of China on 14 January 2059?
```

### Available tools

```json
[
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  }
]
```

## Item 419 -- `unc:f250deda84fe93ed4f5814726c82cd993f85d2be4c2227c7f91a46e1bf7f88f9`

### Question

```
What will the highest temperature recorded in Porto Alegre, Brazil be on 7 December 2047?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 420 -- `unc:b93c52c3ac75abdddfed61113a7989a8fd13d9cff81bcd218cf831a8e5a29fdf`

### Question

```
What will the maximum temperature in Omsk, Russia be on 3 September 2047?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby public libraries based on specific criteria like English fiction availability and Wi-Fi.",
    "name": "public_library.find_nearby",
    "parameters": {
      "properties": {
        "facilities": {
          "description": "Facilities and sections in public library.",
          "items": {
            "enum": [
              "Wi-Fi",
              "Reading Room",
              "Fiction",
              "Children Section",
              "Cafe"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Boston, MA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "facilities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 19 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 361 -- `unc:72400f90a16b45ff1b93cec7d8552e3f861a2a9f094c86fd3e4857181d980042`

### Question

```
What will the highest temperature recorded in Kanpur, India be on 15 February 2046?
```

### Available tools

```json
[
  {
    "description": "Calculate the cooking time for a roast chicken.",
    "name": "calculate_cooking_time",
    "parameters": {
      "properties": {
        "cooking_method": {
          "description": "The method of cooking, defaults to 'roast'.",
          "type": "string"
        },
        "temp_celsius": {
          "description": "The cooking temperature in degrees celsius, defaults to 180.",
          "type": "integer"
        },
        "weight_kg": {
          "description": "The weight of the chicken in kilograms.",
          "type": "float"
        }
      },
      "required": [
        "weight_kg"
      ],
      "type": "dict"
    }
  }
]
```

## Item 362 -- `unc:01627a7587b1202136c953d1fa4f8c2b23d00e77df6e9d43d9d30bfc4cabbf38`

### Question

```
On 2 June 2051, what high temperature will Barcelona, Spain record?
```

### Available tools

```json
[
  {
    "description": "Calculate the neuronal activity (rate of firing) based on a given input synaptic rate, weight of inputs, and decay rate. Higher input or weight increases firing rate and higher decay rate decreases it.",
    "name": "calculate_neuronal_activity",
    "parameters": {
      "properties": {
        "decay_rate": {
          "description": "The rate at which the neuron's potential decays in the absence of inputs.",
          "type": "float"
        },
        "input_synaptic_rate": {
          "description": "The synaptic input rate, usually represented as number of inputs per second.",
          "type": "integer"
        },
        "weight": {
          "description": "The weight of the input, denoting its influence on the neuron's state. Default is 1.0.",
          "type": "float"
        }
      },
      "required": [
        "input_synaptic_rate",
        "decay_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 363 -- `unc:9c3d7d29800477d6076aaace7e182ce09719c831b927b16f653052e323ad5462`

### Question

```
What will the highest temperature recorded in Xianning, People's Republic of China be on 3 March 2060?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 364 -- `unc:c311ed19f02a44f572f3c8fbe4a24736d8c7cdc32ed165c01ef580004fed4026`

### Question

```
In 2051, who will win the USL League Two?
```

### Available tools

```json
[
  {
    "description": "Calculate compound interest for an initial principal amount.",
    "name": "calculate_compound_interest",
    "parameters": {
      "properties": {
        "n": {
          "description": "The number of times that interest is compounded per time period. Default is 1.",
          "type": "integer"
        },
        "principal": {
          "description": "The principal amount that the interest is applied to.",
          "type": "integer"
        },
        "rate": {
          "description": "The annual interest rate. Enter as a decimal. E.g, 5% is 0.05",
          "type": "float"
        },
        "time": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "rate",
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 365 -- `unc:8e2e7b5dc587585e6d4f79ffa0a1bb256e4987f1fc41bd049128170458eff2c5`

### Question

```
What will the maximum temperature in Taguig, Philippines be on 27 November 2055?
```

### Available tools

```json
[
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert time from one time zone to another.",
    "name": "timezone.convert",
    "parameters": {
      "properties": {
        "from_timezone": {
          "description": "The time zone you want to convert from.",
          "type": "string"
        },
        "time": {
          "description": "The local time you want to convert, e.g. 3pm",
          "type": "string"
        },
        "to_timezone": {
          "description": "The time zone you want to convert to.",
          "type": "string"
        }
      },
      "required": [
        "time",
        "from_timezone",
        "to_timezone"
      ],
      "type": "dict"
    }
  }
]
```

## Item 366 -- `unc:1e8d92a8449fced5411d13989baf001f591c2bad4f3835df23b7f787af1b6e3b`

### Question

```
Who is going to be the winner of the 2049 Copa de la Reina de Baloncesto?
```

### Available tools

```json
[
  {
    "description": "Generate a random DNA sequence with a specific length and nucleotide preference.",
    "name": "generate_DNA_sequence",
    "parameters": {
      "properties": {
        "length": {
          "description": "The length of the DNA sequence to be generated.",
          "type": "integer"
        },
        "preferences": {
          "description": "Preferred nucleotides to include more frequently in the DNA sequence.",
          "items": {
            "enum": [
              "A",
              "T",
              "C",
              "G"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "length",
        "preferences"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the final equilibrium temperature after mixing two bodies with different masses and temperatures",
    "name": "calculate_final_temperature",
    "parameters": {
      "properties": {
        "mass1": {
          "description": "The mass of the first body (kg).",
          "type": "integer"
        },
        "mass2": {
          "description": "The mass of the second body (kg).",
          "type": "integer"
        },
        "specific_heat_capacity": {
          "description": "The specific heat capacity of the bodies in kJ/kg/K. If not provided, will default to that of water at room temperature, which is 4.2 kJ/kg/K.",
          "type": "float"
        },
        "temperature1": {
          "description": "The initial temperature of the first body (Celsius).",
          "type": "integer"
        },
        "temperature2": {
          "description": "The initial temperature of the second body (Celsius).",
          "type": "integer"
        }
      },
      "required": [
        "mass1",
        "temperature1",
        "mass2",
        "temperature2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 367 -- `unc:f2893e516db5d4966959f041b287690780cb91c03af7961dae2ae79e78364b43`

### Question

```
On 5 December 2059, what high temperature will Yerevan, Armenia record?
```

### Available tools

```json
[
  {
    "description": "Calculate the circumference of a circle given the radius.",
    "name": "geometry.circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "Units for the output circumference measurement. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 368 -- `unc:63d966ccec75d238264d15a3b69e7a04c794d2ebf777dea2efcd32a018c3c351`

### Question

```
Which team or competitor won the Waterford Intermediate Hurling Championship in 2019?
```

### Available tools

```json
[
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  }
]
```

## Item 369 -- `unc:5e1d07ed2efd634054a2f48d873434b35157246499817663022ae7183dbce207`

### Question

```
What will the highest temperature recorded in Dazhou, People's Republic of China be on 28 June 2050?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 370 -- `unc:e846dacebda1722f3964e6c8cd42329bebd8d65f047efe5ddf37d45ccdd16992`

### Question

```
How many people lived in Santiago, Chile in 2017?
```

### Available tools

```json
[
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 371 -- `unc:997e92bdd1f2200e75d04bb7a08e2d5f67f962c7df6148f27ff2d3a092b16fb6`

### Question

```
In 2001, what was the population of Niamey, Niger?
```

### Available tools

```json
[
  {
    "description": "Combine two primary paint colors and adjust the resulting color's lightness level.",
    "name": "mix_paint_color",
    "parameters": {
      "properties": {
        "color1": {
          "description": "The first primary color to be mixed.",
          "type": "string"
        },
        "color2": {
          "description": "The second primary color to be mixed.",
          "type": "string"
        },
        "lightness": {
          "description": "The desired lightness level of the resulting color in percentage. The default level is set to 50.",
          "type": "integer"
        }
      },
      "required": [
        "color1",
        "color2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the final speed of an object in free fall after a certain time, neglecting air resistance. The acceleration due to gravity is considered as -9.81 m/s^2",
    "name": "calculate_final_speed",
    "parameters": {
      "properties": {
        "gravity": {
          "description": "The acceleration due to gravity. Default is -9.81 m/s^2.",
          "type": "float"
        },
        "initial_speed": {
          "description": "The initial speed of the object in m/s. Default is 0 for an object at rest.",
          "type": "integer"
        },
        "time": {
          "description": "The time in seconds for which the object is in free fall.",
          "type": "integer"
        }
      },
      "required": [
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  }
]
```

## Item 372 -- `unc:febca85ad586d28d7f07ad09dfcf25cef15c7a535f0e0959753f5a849542a101`

### Question

```
On 3 September 2043, what high temperature will Anshan, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get stock price data for a given company over a specified number of days.",
    "name": "stock_price",
    "parameters": {
      "properties": {
        "company": {
          "description": "The company name.",
          "type": "string"
        },
        "data_type": {
          "description": "The type of price data to retrieve (e.g., 'Open', 'Close', 'High', 'Low'). Default is 'Close'.",
          "type": "string"
        },
        "days": {
          "description": "The number of previous days to retrieve data for.",
          "type": "integer"
        }
      },
      "required": [
        "company",
        "days"
      ],
      "type": "dict"
    }
  }
]
```

## Item 373 -- `unc:7da01d88a744302309f012ed75827fdca574d346365878ded4a3788e786bc4eb`

### Question

```
Who is going to be the winner of the 2043 Big West Conference men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 374 -- `unc:6ba83a3ee052813b443638533ac754cff7248f46df13632ade6ce6d3a186778d`

### Question

```
Who will win the 2047 China League Two?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 375 -- `unc:6092d64d5944c2f500ffa6305d1893d15aa584b8def556a020d4c6b4e719a4af`

### Question

```
Who was the winner of the 2020 Leinster Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 376 -- `unc:055dc20c459df4b658a39adf48a6847f715e60c33aee4fb714c6406fe95594c3`

### Question

```
In 2043, who will win the Japan Football League?
```

### Available tools

```json
[
  {
    "description": "Calculate the compounded interest for a given principal, interest rate, and period.",
    "name": "calculate_compounded_interest",
    "parameters": {
      "properties": {
        "compounding_frequency": {
          "description": "The frequency of compounding per year. Defaults to 'Annually'.",
          "enum": [
            "Annually",
            "Semiannually",
            "Quarterly",
            "Monthly",
            "Daily"
          ],
          "type": "string"
        },
        "interest_rate": {
          "description": "The annual interest rate.",
          "type": "float"
        },
        "period": {
          "description": "The period in years.",
          "type": "integer"
        },
        "principal": {
          "description": "The initial principal.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "interest_rate",
        "period"
      ],
      "type": "dict"
    }
  }
]
```

## Item 377 -- `unc:f1126b5bf09c540e7e0d89fe3d14935d0361ce4358370c8477d3a14488f9865a`

### Question

```
In 2059, who will win the Summit League softball tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find details of lawsuits involving a specific company from a given year.",
    "name": "lawsuit_details.find",
    "parameters": {
      "properties": {
        "case_type": {
          "description": "Type of the lawsuit, e.g., 'IPR', 'Patent', 'Commercial', etc. Default is 'all'.",
          "type": "string"
        },
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "year": {
          "description": "Year of the lawsuit.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the discounted cash flow of a bond for a given annual coupon payment, time frame and discount rate.",
    "name": "calculate_discounted_cash_flow",
    "parameters": {
      "properties": {
        "coupon_payment": {
          "description": "The annual coupon payment.",
          "type": "integer"
        },
        "discount_rate": {
          "description": "The discount rate.",
          "type": "float"
        },
        "face_value": {
          "description": "The face value of the bond, default is 1000.",
          "type": "integer"
        },
        "period": {
          "description": "The time frame in years for which coupon payment is made.",
          "type": "integer"
        }
      },
      "required": [
        "coupon_payment",
        "period",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 378 -- `unc:673e15688638f316bdfdeaea22439ee1c65c3357ea0e778bfa8f6db5737431cb`

### Question

```
In 2056, who will win the Malaysia Super League?
```

### Available tools

```json
[
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a triangle given its base and height.",
    "name": "calculate_triangle_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure (defaults to 'units' if not specified)",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 379 -- `unc:cc6b4d70034af93eb2317acc49dc554eeafd50ab33d50f68284bc166d1594ddc`

### Question

```
Who will win the 2054 FIBA U16 EuroBasket?
```

### Available tools

```json
[
  {
    "description": "Finds the type of a genetic mutation based on its SNP (Single Nucleotide Polymorphism) ID.",
    "name": "mutation_type.find",
    "parameters": {
      "properties": {
        "snp_id": {
          "description": "The ID of the Single Nucleotide Polymorphism (SNP) mutation.",
          "type": "string"
        },
        "species": {
          "description": "Species in which the SNP occurs, default is 'Homo sapiens' (Humans).",
          "type": "string"
        }
      },
      "required": [
        "snp_id"
      ],
      "type": "dict"
    }
  }
]
```

## Item 380 -- `unc:69f998d3c71703ac5e5eaa3cfc2a5f27097fbef6612faa830f68190215a51651`

### Question

```
Which team or competitor will win the Teresa Herrera Trophy in 2058?
```

### Available tools

```json
[
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

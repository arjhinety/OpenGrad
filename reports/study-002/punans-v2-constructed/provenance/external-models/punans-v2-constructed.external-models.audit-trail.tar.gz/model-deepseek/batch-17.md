# Annotation batch 17 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 321 -- `unc:7bb274d3204e1e2b4bf8aa73addf7b1cd96289c651e32624c0e79bd4eee385cc`

### Question

```
How hot will it get in Bogotá, Colombia on 23 January 2050?
```

### Available tools

```json
[
  {
    "description": "Generate a travel itinerary based on specific destination, duration and daily budget, with preferred exploration type.",
    "name": "travel_itinerary_generator",
    "parameters": {
      "properties": {
        "daily_budget": {
          "description": "The maximum daily budget for the trip.",
          "type": "integer"
        },
        "days": {
          "description": "Number of days for the trip.",
          "type": "integer"
        },
        "destination": {
          "description": "Destination city of the trip.",
          "type": "string"
        },
        "exploration_type": {
          "default": "urban",
          "description": "The preferred exploration type.",
          "enum": [
            "nature",
            "urban",
            "history",
            "culture"
          ],
          "type": "string"
        }
      },
      "required": [
        "destination",
        "days",
        "daily_budget"
      ],
      "type": "dict"
    }
  }
]
```

## Item 322 -- `unc:fdb389ee768225b22f93dae676c2180fda34df1ad52cb6e720ba56149a87780d`

### Question

```
In 2059, who will win the Handball Cup of North Macedonia?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "probabilities.calculate_single",
    "parameters": {
      "properties": {
        "event_outcomes": {
          "description": "The number of outcomes where the event occurs.",
          "type": "integer"
        },
        "round": {
          "description": "Round the answer to a specified number of decimal places. Defaults to 2.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "event_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 323 -- `unc:a2b6a823f5b1657f1277f92a241e73f080f63c6d39c470860756175b85279959`

### Question

```
In 2000, who won the Czech Hockey Games?
```

### Available tools

```json
[
  {
    "description": "Calculate the Compound Annual Growth Rate (CAGR) given an initial investment value, a final investment value, and the number of years.",
    "name": "calculate_cagr",
    "parameters": {
      "properties": {
        "final_value": {
          "description": "The final investment value.",
          "type": "integer"
        },
        "initial_value": {
          "description": "The initial investment value.",
          "type": "integer"
        },
        "period_in_years": {
          "description": "The period of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_value",
        "final_value",
        "period_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 324 -- `unc:ed37ae850443e3654b0b82680dfcbed47d20afee0bd8b3727deb15275dcfbb99`

### Question

```
In 1950, what was the population of Prague, Czech Republic?
```

### Available tools

```json
[
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment in a specific stock based on the invested amount, expected annual return and number of years.",
    "name": "portfolio_future_value",
    "parameters": {
      "properties": {
        "expected_annual_return": {
          "description": "The expected annual return on investment as a decimal. E.g. 5% = 0.05",
          "type": "float"
        },
        "invested_amount": {
          "description": "The invested amount in USD.",
          "type": "integer"
        },
        "stock": {
          "description": "The ticker symbol of the stock.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "stock",
        "invested_amount",
        "expected_annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 325 -- `unc:3f86ad45f82e38ea4fd24ca15c7060c9a6bd24aee544107b3025f93e4d77684a`

### Question

```
What will the maximum temperature in Melbourne, Australia be on 12 June 2060?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 326 -- `unc:6e9062397741da8c7c83b48a696b529de0409fe48573c39721c989815273d06d`

### Question

```
Who is going to be the winner of the 2049 Big East Conference softball tournament?
```

### Available tools

```json
[
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 327 -- `unc:173cb98c3d02569b5b9efdb09f6cb712a5fcd767507ec6aa60be99078a7023b2`

### Question

```
Who is going to be the winner of the 2043 National Women's Soccer League regular season?
```

### Available tools

```json
[
  {
    "description": "Send an email to the specified email address.",
    "name": "send_email",
    "parameters": {
      "properties": {
        "bcc": {
          "description": "The email address to blind carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "body": {
          "description": "The body content of the email.",
          "type": "string"
        },
        "cc": {
          "description": "The email address to carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "subject": {
          "description": "The subject of the email.",
          "type": "string"
        },
        "to": {
          "description": "The email address to send to.",
          "type": "string"
        }
      },
      "required": [
        "to",
        "subject",
        "body"
      ],
      "type": "dict"
    }
  }
]
```

## Item 328 -- `unc:e61665f157b2087fef5fc2c1181c837ed647a423f3328e4f2289ea7f5bec5484`

### Question

```
Who is going to be the winner of the 2040 Northeast Conference women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 329 -- `unc:2eaec9672854f0a47df85b9ffd1b1862bcd3349cc5b358bfe39e147b32442e48`

### Question

```
Who won the 1997 Kerry Senior Hurling Championship?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  }
]
```

## Item 330 -- `unc:244cb8f378ddfec704d83adea3d4b4987feee93d05d1c3d9789cabe15a41a6e9`

### Question

```
What was the population of Quezon City, Philippines as of 1960?
```

### Available tools

```json
[
  {
    "description": "Calculate the distance between two locations, considering terrain.",
    "name": "distance_calculator.calculate",
    "parameters": {
      "properties": {
        "consider_terrain": {
          "description": "Whether to account for terrain in distance calculation, defaults to false.",
          "type": "boolean"
        },
        "destination": {
          "description": "Destination location of the distance measurement.",
          "type": "string"
        },
        "origin": {
          "description": "Starting location of the distance measurement.",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 331 -- `unc:a5ac440c869926a3001941d20ab2958c03c46f0fede59ebdf892aed6212e2ed3`

### Question

```
Who will win the 2038 Hockey East men's ice hockey tournament?
```

### Available tools

```json
[
  {
    "description": "Check the price of items at a specific Whole Foods location.",
    "name": "whole_foods.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items for which the price needs to be checked.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "Location of the Whole Foods store.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "items"
      ],
      "type": "dict"
    }
  }
]
```

## Item 332 -- `unc:8606aa01992d1de58ed7bc326386048433a488666ae6ac003d662c589dd6f165`

### Question

```
Who won the 2006 Supercopa de España femenina de baloncesto?
```

### Available tools

```json
[
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  }
]
```

## Item 333 -- `unc:fc5b26ba330cfc01d8b026114210bc6281618f2c3df33c60bd09f6548b3efd88`

### Question

```
Which team or competitor will win the Portuguese Volleyball Super Cup in 2048?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 334 -- `unc:8597e8a42330c10ec27ee3f2e6fedfeb5e47f6acc5dc082a79781482722c5629`

### Question

```
Who won the 2008 World Rugby Under 20 Championship?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds the type of a genetic mutation based on its SNP (Single Nucleotide Polymorphism) ID.",
    "name": "mutation_type.find",
    "parameters": {
      "properties": {
        "snp_id": {
          "description": "The ID of the Single Nucleotide Polymorphism (SNP) mutation.",
          "type": "string"
        },
        "species": {
          "description": "Species in which the SNP occurs, default is 'Homo sapiens' (Humans).",
          "type": "string"
        }
      },
      "required": [
        "snp_id"
      ],
      "type": "dict"
    }
  }
]
```

## Item 335 -- `unc:64ed2141cbf85a4e335cc6bc1ee105342544559b1b81ac1f2f93f1f255058e0d`

### Question

```
In 2019, who won the FIBA Europe SuperCup Women?
```

### Available tools

```json
[
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 336 -- `unc:588e7ddd4fc08b531e7b581ded0df7dc5115e298d363a7225eb23b505d880cbd`

### Question

```
What will the maximum temperature in Hefei, People's Republic of China be on 13 June 2052?
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  }
]
```

## Item 337 -- `unc:c58d2ebe6576ade0bb9a70e0cebc96fbfa11cda472bb85d6e773b60acaa03f43`

### Question

```
What will the maximum temperature in Tashkent, Uzbekistan be on 10 January 2046?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 338 -- `unc:499c5af5be891317e436d3ef4452e231078b185c5d777884e1e48671947f2e11`

### Question

```
In 2001, who won the Maui Invitational Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  }
]
```

## Item 339 -- `unc:fbe2f3c883fb4e96a37c5b6f2af4a5bd754916a0b541469f2eac724476074007`

### Question

```
What will the highest temperature recorded in Houston, United States be on 21 November 2054?
```

### Available tools

```json
[
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 340 -- `unc:0d2faa696870c7f1f29e1b6e427f0d35cd0da9b33fdde37a489448e8238a2a12`

### Question

```
Who is going to be the winner of the 2041 All-Star Keirin?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

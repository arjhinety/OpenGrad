# Annotation batch 09 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 161 -- `unc:51aae55e469edae4209f2532a7050633a3582e63762969ddd7b0f95b91408078`

### Question

```
Who is going to be the winner of the 2035 Svenska Cupen Women?
```

### Available tools

```json
[
  {
    "description": "Locate nearby grocery stores based on specific criteria like organic fruits and vegetables.",
    "name": "grocery_store.find_nearby",
    "parameters": {
      "properties": {
        "categories": {
          "description": "Categories of items to be found in the grocery store. Default is all if not specified.",
          "items": {
            "enum": [
              "Organic",
              "Vegetables",
              "Fruits",
              "Dairy",
              "Seafood",
              "Bakery"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Houston, TX",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 162 -- `unc:140ecfcc6f8ae33494a203f622488958798bbb5fdf9b298db85ec317c17f9bce`

### Question

```
Who will win the 2048 Women's Deutschland Cup?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for an initial principal amount.",
    "name": "calculate_compound_interest",
    "parameters": {
      "properties": {
        "n": {
          "description": "The number of times that interest is compounded per time period. Default is 1.",
          "type": "integer"
        },
        "principal": {
          "description": "The principal amount that the interest is applied to.",
          "type": "integer"
        },
        "rate": {
          "description": "The annual interest rate. Enter as a decimal. E.g, 5% is 0.05",
          "type": "float"
        },
        "time": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "rate",
        "time"
      ],
      "type": "dict"
    }
  }
]
```

## Item 163 -- `unc:c014b0ea2251358ec71a7d9bea973a911e58005619e8a22ad8bd597ba876c8ac`

### Question

```
Who will win the 2044 Leaders Cup?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  }
]
```

## Item 164 -- `unc:700fe2d987d85ba97f1ee5d094480998677907e8474a2e45fd10367f8c8ad8f1`

### Question

```
In 2040, who will win the Australia Cup?
```

### Available tools

```json
[
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) of a person.",
    "name": "calculate_bmi",
    "parameters": {
      "properties": {
        "height": {
          "description": "Height of the person in centimeters.",
          "type": "integer"
        },
        "unit": {
          "description": "Optional parameter to choose between 'imperial' and 'metric' systems. Default is 'metric'.",
          "type": "string"
        },
        "weight": {
          "description": "Weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 165 -- `unc:b91c56762fa467b027c8fe2adcc65f75f51024859c672824f99704038e766f10`

### Question

```
In 2010, what was the population of Zhumadian, People's Republic of China?
```

### Available tools

```json
[
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the distance between two GPS coordinates.",
    "name": "calculate_distance",
    "parameters": {
      "properties": {
        "coord1": {
          "description": "The first coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "coord2": {
          "description": "The second coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "unit": {
          "description": "The unit of distance. Options: 'miles', 'kilometers'.",
          "type": "string"
        }
      },
      "required": [
        "coord1",
        "coord2",
        "unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the circumference of a circle with a given radius.",
    "name": "calculate_circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle in the unit given.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measurement for the radius. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 166 -- `unc:64a31b048715f36e1372a44d5629ddb55c9e34a116450d6856d4a5d469a0efca`

### Question

```
Who will win the 2057 Japan Series?
```

### Available tools

```json
[
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Combine two primary paint colors and adjust the resulting color's lightness level.",
    "name": "mix_paint_color",
    "parameters": {
      "properties": {
        "color1": {
          "description": "The first primary color to be mixed.",
          "type": "string"
        },
        "color2": {
          "description": "The second primary color to be mixed.",
          "type": "string"
        },
        "lightness": {
          "description": "The desired lightness level of the resulting color in percentage. The default level is set to 50.",
          "type": "integer"
        }
      },
      "required": [
        "color1",
        "color2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 167 -- `unc:ad30f7c39e3799b1a94fe4ca5b99cd5a216893c0310631cfef5c2dad6c08a3fd`

### Question

```
In 2057, who will win the Rally Cidade de Narón?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 168 -- `unc:e20e3c446f6e22d3fd2a0457b0d2480bbb2bc155cd64731d4617bb8d87045c93`

### Question

```
What will the maximum temperature in Mandalay, Myanmar be on 28 April 2057?
```

### Available tools

```json
[
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  }
]
```

## Item 169 -- `unc:7c9ed34934a8097be58f0e2800740645f84fcc5977f06fc23220ae63e4ff14e8`

### Question

```
What will the maximum temperature in Montreal, Canada be on 2 November 2041?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find details of lawsuits involving a specific company from a given year.",
    "name": "lawsuit_details.find",
    "parameters": {
      "properties": {
        "case_type": {
          "description": "Type of the lawsuit, e.g., 'IPR', 'Patent', 'Commercial', etc. Default is 'all'.",
          "type": "string"
        },
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "year": {
          "description": "Year of the lawsuit.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 170 -- `unc:335c35d9706f4abd921e4b629e363c02c85bfbee79d349358e149e32b373b28e`

### Question

```
What will the maximum temperature in Bayannur, People's Republic of China be on 21 August 2041?
```

### Available tools

```json
[
  {
    "description": "Locate nearby grocery stores based on specific criteria like organic fruits and vegetables.",
    "name": "grocery_store.find_nearby",
    "parameters": {
      "properties": {
        "categories": {
          "description": "Categories of items to be found in the grocery store. Default is all if not specified.",
          "items": {
            "enum": [
              "Organic",
              "Vegetables",
              "Fruits",
              "Dairy",
              "Seafood",
              "Bakery"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Houston, TX",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 171 -- `unc:63e1c297f653e9596cea473f62495ab00c9fa589a380267fb8a5db5f5fdd16ba`

### Question

```
What will the highest temperature recorded in Tbilisi, Georgia be on 9 January 2051?
```

### Available tools

```json
[
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  }
]
```

## Item 172 -- `unc:dec204b8ccfdc75371a38da7cbcbf8db0e16256a9a89168df3eb03ced0bcc404`

### Question

```
How hot will it get in Ibadan, Nigeria on 24 March 2053?
```

### Available tools

```json
[
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under a mathematical function within a given interval.",
    "name": "calculate_area_under_curve",
    "parameters": {
      "properties": {
        "function": {
          "description": "The mathematical function as a string.",
          "type": "string"
        },
        "interval": {
          "description": "An array that defines the interval to calculate the area under the curve from the start to the end point.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "method": {
          "description": "The numerical method to approximate the area under the curve. The default value is 'trapezoidal'.",
          "type": "string"
        }
      },
      "required": [
        "function",
        "interval"
      ],
      "type": "dict"
    }
  }
]
```

## Item 173 -- `unc:3e378cb49ea57d493f9580d39942b92611ad9e9fd5e60bd5543fc5d124349e60`

### Question

```
Who won the 1994 Water polo at the World Aquatics Championships – Men's tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a right-angled triangle given the lengths of its base and height.",
    "name": "calculate_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the right-angled triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the right-angled triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure used. Defaults to 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 174 -- `unc:8303afdcfd252e8d4af12c407f70b469b3f1f28b731b4d6b9eac38705867d6c0`

### Question

```
Which team or competitor won the Czech Rally Championship in 2013?
```

### Available tools

```json
[
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of having 'success' outcome from binomial distribution.",
    "name": "prob_dist.binomial",
    "parameters": {
      "properties": {
        "p": {
          "description": "The probability of success on any given trial, defaults to 0.5",
          "type": "float"
        },
        "successes": {
          "description": "The number of success events.",
          "type": "integer"
        },
        "trials": {
          "description": "The number of independent experiments.",
          "type": "integer"
        }
      },
      "required": [
        "trials",
        "successes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 175 -- `unc:dfcbea65502ddadf4bbea76d12136bae2363b2145bd91099003b07bbbc706008`

### Question

```
How hot will it get in Islamabad, Pakistan on 6 January 2040?
```

### Available tools

```json
[
  {
    "description": "Locate nearby public libraries based on specific criteria like English fiction availability and Wi-Fi.",
    "name": "public_library.find_nearby",
    "parameters": {
      "properties": {
        "facilities": {
          "description": "Facilities and sections in public library.",
          "items": {
            "enum": [
              "Wi-Fi",
              "Reading Room",
              "Fiction",
              "Children Section",
              "Cafe"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Boston, MA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "facilities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  }
]
```

## Item 176 -- `unc:b169df1cbbaf38ae3ccce80a71beb640ce463914edd78f01642f56ee7ff89304`

### Question

```
Who was the winner of the 2018 Joe McDonagh Cup?
```

### Available tools

```json
[
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 177 -- `unc:b3caa281f596666a457c6c522796078120fa2abc81fb72feacbfb9c7cff04eee`

### Question

```
How hot will it get in Denizli, Turkey on 2 October 2056?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the discounted cash flow of a bond for a given annual coupon payment, time frame and discount rate.",
    "name": "calculate_discounted_cash_flow",
    "parameters": {
      "properties": {
        "coupon_payment": {
          "description": "The annual coupon payment.",
          "type": "integer"
        },
        "discount_rate": {
          "description": "The discount rate.",
          "type": "float"
        },
        "face_value": {
          "description": "The face value of the bond, default is 1000.",
          "type": "integer"
        },
        "period": {
          "description": "The time frame in years for which coupon payment is made.",
          "type": "integer"
        }
      },
      "required": [
        "coupon_payment",
        "period",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 178 -- `unc:8cdb479066607f80f1cc81e78f791a12a086c124406f22ca9d91d5a383381a1e`

### Question

```
In 2051, who will win the Big South Conference men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the return on investment for a given stock based on its purchase price, sale price, and any dividends received.",
    "name": "calculate_return_on_investment",
    "parameters": {
      "properties": {
        "dividend": {
          "default": 0,
          "description": "Any dividends received from the stock.",
          "type": "integer"
        },
        "purchase_price": {
          "description": "The price the stock was bought at.",
          "type": "integer"
        },
        "sale_price": {
          "description": "The price the stock was sold at.",
          "type": "integer"
        }
      },
      "required": [
        "purchase_price",
        "sale_price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 179 -- `unc:d495fe7754ed00f12d8ec39bbb53d59fdb070663b0f17759bc772567e5d79031`

### Question

```
How hot will it get in Luoyang, People's Republic of China on 16 September 2046?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "calculate_probability",
    "parameters": {
      "properties": {
        "favorable_outcomes": {
          "description": "Number of outcomes considered as 'successful'.",
          "type": "integer"
        },
        "round_to": {
          "default": 2,
          "description": "Number of decimal places to round the result to.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "Total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "favorable_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 180 -- `unc:61a27e61d58c24c8f7787d269b9d196446f0709127da2ac88934b639a5f16043`

### Question

```
Who is going to be the winner of the 2036 Copa del Rey Juvenil de Fútbol?
```

### Available tools

```json
[
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 01 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 1 -- `unc:0a83b5140aa9b5ed1a68a8f07f3da2ee9c5109f93f912a1a6075261b8b86c8d4`

### Question

```
How hot will it get in Panzhihua, People's Republic of China on 7 October 2054?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest Model on given data",
    "name": "random_forest.train",
    "parameters": {
      "properties": {
        "data": {
          "description": "The training data for the model.",
          "type": "any"
        },
        "max_depth": {
          "description": "The maximum depth of the tree.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "n_estimators",
        "max_depth",
        "data"
      ],
      "type": "dict"
    }
  }
]
```

## Item 2 -- `unc:84a4ed34265ad14b5b58cebd78d0bd933cd83f687683a40b193a4aa33321f848`

### Question

```
In 1970, what was the population of Kyiv, Ukraine?
```

### Available tools

```json
[
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 3 -- `unc:031c6d6746df274a7088abd67e9cb56ddb59e6743b74f69c85904b761124d969`

### Question

```
What population did Davao City, Philippines have in 2015?
```

### Available tools

```json
[
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 4 -- `unc:e99bf4e2232d2aab805c0c27bec805963a3c2ab43834ba3897684d87923f2466`

### Question

```
Who was the winner of the 2019 West Coast Conference women's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the probability of an outcome based on the binomial distribution",
    "name": "calc_binomial_prob",
    "parameters": {
      "properties": {
        "num_success": {
          "description": "Number of times the event of interest has occurred.",
          "type": "integer"
        },
        "num_trials": {
          "description": "Number of independent experiments.",
          "type": "integer"
        },
        "prob_success": {
          "description": "Probability of the event of interest on any single experiment.",
          "type": "float"
        }
      },
      "required": [
        "num_trials",
        "num_success",
        "prob_success"
      ],
      "type": "dict"
    }
  }
]
```

## Item 5 -- `unc:d4a7616c85cd86eed03e436f0153bf242b70c1bcc18c7c8c110e67ce2e849afa`

### Question

```
What will the highest temperature recorded in Suwon, South Korea be on 10 June 2044?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 6 -- `unc:ec01c3a9f77b84110452587582eecd1b762f2064454b1cd09531e0b9c8a88b44`

### Question

```
Which team or competitor will win the J1 League in 2051?
```

### Available tools

```json
[
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Compound Annual Growth Rate (CAGR) given an initial investment value, a final investment value, and the number of years.",
    "name": "calculate_cagr",
    "parameters": {
      "properties": {
        "final_value": {
          "description": "The final investment value.",
          "type": "integer"
        },
        "initial_value": {
          "description": "The initial investment value.",
          "type": "integer"
        },
        "period_in_years": {
          "description": "The period of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_value",
        "final_value",
        "period_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 7 -- `unc:6a98b3aef48ab01d8d44a3504b5d871fd50ab154062b8dc807149aad060ebd97`

### Question

```
What will the maximum temperature in Shaoyang, People's Republic of China be on 30 March 2060?
```

### Available tools

```json
[
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Runs a two sample t-test for two given data groups.",
    "name": "run_two_sample_ttest",
    "parameters": {
      "properties": {
        "equal_variance": {
          "default": true,
          "description": "Assumption about whether the two samples have equal variance.",
          "type": "boolean"
        },
        "group1": {
          "description": "First group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "group2": {
          "description": "Second group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 8 -- `unc:810e4bb5805b9105d1d0f84089043a81fcda23bbf236ff59ff9438474c31c3fe`

### Question

```
Which team or competitor will win the Big East Conference women's soccer tournament in 2056?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 9 -- `unc:1432d87ee03db4d0a914691e5636a8cba5a219997303ebb0a40b7795f8d7f5d1`

### Question

```
What will the highest temperature recorded in Zhangjiajie, People's Republic of China be on 3 February 2045?
```

### Available tools

```json
[
  {
    "description": "Get stock price data for a given company over a specified number of days.",
    "name": "stock_price",
    "parameters": {
      "properties": {
        "company": {
          "description": "The company name.",
          "type": "string"
        },
        "data_type": {
          "description": "The type of price data to retrieve (e.g., 'Open', 'Close', 'High', 'Low'). Default is 'Close'.",
          "type": "string"
        },
        "days": {
          "description": "The number of previous days to retrieve data for.",
          "type": "integer"
        }
      },
      "required": [
        "company",
        "days"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby grocery stores based on specific criteria like organic fruits and vegetables.",
    "name": "grocery_store.find_nearby",
    "parameters": {
      "properties": {
        "categories": {
          "description": "Categories of items to be found in the grocery store. Default is all if not specified.",
          "items": {
            "enum": [
              "Organic",
              "Vegetables",
              "Fruits",
              "Dairy",
              "Seafood",
              "Bakery"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Houston, TX",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 10 -- `unc:b23b2ba2bec5f87fcaa93dc32bd0be0b3443b0bbf6684f9261079ea4656b8d3d`

### Question

```
Who will win the 2039 Besta deild kvenna?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 11 -- `unc:28dc8b2c60c36e57fd81700382ca4759772908d9954363bb67ca570b24e10013`

### Question

```
In 2057, who will win the Derry Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 12 -- `unc:2c9a5b3edb9ddc728826ba4360eee613e67a7e5db1ae1a9fc09c6ec391e93644`

### Question

```
How hot will it get in Hamburg, Germany on 5 July 2058?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 13 -- `unc:7288f54bbfa8aee5171b15b19e93acd3ba7e30ec15db12bd17deb8644a92fd8d`

### Question

```
What will the highest temperature recorded in Tangshan, People's Republic of China be on 21 February 2053?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest Model on given data",
    "name": "random_forest.train",
    "parameters": {
      "properties": {
        "data": {
          "description": "The training data for the model.",
          "type": "any"
        },
        "max_depth": {
          "description": "The maximum depth of the tree.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "n_estimators",
        "max_depth",
        "data"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a flute for sale based on specific requirements.",
    "name": "find_flute",
    "parameters": {
      "properties": {
        "brand": {
          "description": "The brand of the flute. Example, 'Yamaha'",
          "type": "string"
        },
        "specs": {
          "description": "The specifications of the flute desired.",
          "items": {
            "enum": [
              "open hole",
              "C foot",
              "silver headjoint"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "brand",
        "specs"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a right-angled triangle given the lengths of its base and height.",
    "name": "calculate_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the right-angled triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the right-angled triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure used. Defaults to 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 14 -- `unc:2167096c8eee1ccbef71ad9b364d91d5ee04a9bd08b0a75585c262102bf9081b`

### Question

```
Who is going to be the winner of the 2047 FIDE Grand Swiss Tournament?
```

### Available tools

```json
[
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 15 -- `unc:80720afb550eb17d2af8da56d5f6beab45d7c6d43a05f86750996452e1e484c3`

### Question

```
Who will win the 2054 Monte Carlo Rally?
```

### Available tools

```json
[
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 16 -- `unc:559c23bed1341342c5a4738c5c67e8fbf410508add106d373393b3cbb2c0f4df`

### Question

```
What will the maximum temperature in Chengdu, People's Republic of China be on 30 December 2057?
```

### Available tools

```json
[
  {
    "description": "Calculate the cell density of a biological sample based on its optical density and the experiment dilution.",
    "name": "calculate_cell_density",
    "parameters": {
      "properties": {
        "calibration_factor": {
          "description": "The calibration factor to adjust the density, default value is 1e9 assuming cell density is in CFU/mL.",
          "type": "float"
        },
        "dilution": {
          "description": "The dilution factor applied during the experiment.",
          "type": "integer"
        },
        "optical_density": {
          "description": "The optical density of the sample, usually obtained from a spectrophotometer reading.",
          "type": "float"
        }
      },
      "required": [
        "optical_density",
        "dilution"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 17 -- `unc:5764cf245f71af31b015bd8e57c0162672f30fff151324d93696f266d78228b3`

### Question

```
Who is going to be the winner of the 2051 Mid-American Conference Baseball Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 18 -- `unc:7a44931165540faa7bee22dd1734e974c2bb3ebfbf90c21174142a11768b743a`

### Question

```
Which team or competitor will win the Romanian Chess Championship in 2047?
```

### Available tools

```json
[
  {
    "description": "Combine two primary paint colors and adjust the resulting color's lightness level.",
    "name": "mix_paint_color",
    "parameters": {
      "properties": {
        "color1": {
          "description": "The first primary color to be mixed.",
          "type": "string"
        },
        "color2": {
          "description": "The second primary color to be mixed.",
          "type": "string"
        },
        "lightness": {
          "description": "The desired lightness level of the resulting color in percentage. The default level is set to 50.",
          "type": "integer"
        }
      },
      "required": [
        "color1",
        "color2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 19 -- `unc:4cb58e60eed6ba5ba5301b0cc8973e980c9272e2b7e36a909ce82983d145baed`

### Question

```
Which team or competitor will win the Japanese Regional Football League Competition in 2035?
```

### Available tools

```json
[
  {
    "description": "Verify the details of a lawsuit case and check its status using case ID.",
    "name": "lawsuit.check_case",
    "parameters": {
      "properties": {
        "case_id": {
          "description": "The identification number of the lawsuit case.",
          "type": "integer"
        },
        "closed_status": {
          "description": "The status of the lawsuit case to be verified.",
          "type": "boolean"
        }
      },
      "required": [
        "case_id",
        "closed_status"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 20 -- `unc:068474072c450ac167625421aed255c670a56518af9b9892b6bc92b91f49b40f`

### Question

```
Who is going to be the winner of the 2044 Big 12 Conference women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Get the working hours of a museum in a specific location.",
    "name": "museum_working_hours.get",
    "parameters": {
      "properties": {
        "day": {
          "description": "Specific day of the week. Default is 'Monday'",
          "type": "string"
        },
        "location": {
          "description": "The location of the museum.",
          "type": "string"
        },
        "museum": {
          "description": "The name of the museum.",
          "type": "string"
        }
      },
      "required": [
        "museum",
        "location"
      ],
      "type": "dict"
    }
  }
]
```

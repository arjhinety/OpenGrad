# Annotation batch 08 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 141 -- `unc:d679df86e4256361569c93eea0b7e4270bc38e93f9b8b08cc7b5c29ce7bd4952`

### Question

```
On 31 December 2055, what high temperature will Jiamusi, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  }
]
```

## Item 142 -- `unc:a7647d65e1a4a049b61ec3060d46dce05b428dd21b479e1aee32fe7f5503339f`

### Question

```
What will the highest temperature recorded in Ulanqab, People's Republic of China be on 20 January 2058?
```

### Available tools

```json
[
  {
    "description": "Calculates the binomial probability given the number of trials, successes and the probability of success on an individual trial.",
    "name": "calculate_binomial_probability",
    "parameters": {
      "properties": {
        "number_of_successes": {
          "description": "The desired number of successful outcomes.",
          "type": "integer"
        },
        "number_of_trials": {
          "description": "The total number of trials.",
          "type": "integer"
        },
        "probability_of_success": {
          "default": 0.5,
          "description": "The probability of a successful outcome on any given trial.",
          "type": "float"
        }
      },
      "required": [
        "number_of_trials",
        "number_of_successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 143 -- `unc:c4df7acbfb5649beaec7799f269965042eea4359b3e630bf95997a7374f6754c`

### Question

```
Who was the winner of the 2018 Mountain West Conference women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the power of one number raised to another.",
    "name": "math.power",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base number.",
          "type": "integer"
        },
        "exponent": {
          "description": "The exponent.",
          "type": "integer"
        },
        "mod": {
          "description": "The modulus. Default is 1. Calculates pow(base, exponent) % mod when provided.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "exponent"
      ],
      "type": "dict"
    }
  }
]
```

## Item 144 -- `unc:09be7b52784b9959bf291295ae31b98e27f78c69a2798e0d1646e7b8343f4a47`

### Question

```
What will the maximum temperature in eThekwini Metropolitan Municipality, South Africa be on 20 July 2054?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 145 -- `unc:16904bf19e9fbc20132214081b2a76d299cf263b2850413a4d21a774de3a1775`

### Question

```
What will the highest temperature recorded in City of Cape Town, South Africa be on 7 March 2048?
```

### Available tools

```json
[
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  }
]
```

## Item 146 -- `unc:6d92dc053eb58693d8829a983c0a47272eee3524759fe610034ad6dbcd4dff3d`

### Question

```
On 25 March 2038, what high temperature will Gaziantep, Turkey record?
```

### Available tools

```json
[
  {
    "description": "Runs a two sample t-test for two given data groups.",
    "name": "run_two_sample_ttest",
    "parameters": {
      "properties": {
        "equal_variance": {
          "default": true,
          "description": "Assumption about whether the two samples have equal variance.",
          "type": "boolean"
        },
        "group1": {
          "description": "First group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "group2": {
          "description": "Second group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 147 -- `unc:617a5d00c0f97767050d46f33c2acacdf9c3f53dd1a03db750e55cf9e88bc782`

### Question

```
What will the maximum temperature in Huludao, People's Republic of China be on 11 May 2049?
```

### Available tools

```json
[
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the working hours of a museum in a specific location.",
    "name": "museum_working_hours.get",
    "parameters": {
      "properties": {
        "day": {
          "description": "Specific day of the week. Default is 'Monday'",
          "type": "string"
        },
        "location": {
          "description": "The location of the museum.",
          "type": "string"
        },
        "museum": {
          "description": "The name of the museum.",
          "type": "string"
        }
      },
      "required": [
        "museum",
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 148 -- `unc:b2855354710be2738fb57a4fb669def1062e3ba58ebe769da915ef6c4a21ff62`

### Question

```
Which team or competitor will win the NAIA men's basketball championships in 2055?
```

### Available tools

```json
[
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Combine two primary paint colors and adjust the resulting color's lightness level.",
    "name": "mix_paint_color",
    "parameters": {
      "properties": {
        "color1": {
          "description": "The first primary color to be mixed.",
          "type": "string"
        },
        "color2": {
          "description": "The second primary color to be mixed.",
          "type": "string"
        },
        "lightness": {
          "description": "The desired lightness level of the resulting color in percentage. The default level is set to 50.",
          "type": "integer"
        }
      },
      "required": [
        "color1",
        "color2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 149 -- `unc:50c67aeb435f11f29695bbcd9185b3b968668a7a0a4c80f7d581e3b71a1c58c0`

### Question

```
Who is going to be the winner of the 2043 ABA League Supercup?
```

### Available tools

```json
[
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  }
]
```

## Item 150 -- `unc:6cb9809501ffe5e149463bf33eeae10546e2057ef8c192697099597e148f1003`

### Question

```
In 2052, who will win the Spanish Trial Championship?
```

### Available tools

```json
[
  {
    "description": "Find details of lawsuits involving a specific company from a given year.",
    "name": "lawsuit_details.find",
    "parameters": {
      "properties": {
        "case_type": {
          "description": "Type of the lawsuit, e.g., 'IPR', 'Patent', 'Commercial', etc. Default is 'all'.",
          "type": "string"
        },
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "year": {
          "description": "Year of the lawsuit.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 151 -- `unc:6a4386b77ec30cb74d758908b45f37c7d8a039413ec0ff79e3088c9a4e6e4ca6`

### Question

```
How hot will it get in Lanzhou, People's Republic of China on 28 October 2053?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the probability of an outcome based on the binomial distribution",
    "name": "calc_binomial_prob",
    "parameters": {
      "properties": {
        "num_success": {
          "description": "Number of times the event of interest has occurred.",
          "type": "integer"
        },
        "num_trials": {
          "description": "Number of independent experiments.",
          "type": "integer"
        },
        "prob_success": {
          "description": "Probability of the event of interest on any single experiment.",
          "type": "float"
        }
      },
      "required": [
        "num_trials",
        "num_success",
        "prob_success"
      ],
      "type": "dict"
    }
  }
]
```

## Item 152 -- `unc:bdf0fd041bac2b1c62ae56ad04648650e67bd8a34906d2fa6f6e9fb3c67288e6`

### Question

```
Who will win the 2058 Water polo at the World Aquatics Championships – Women's tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the neuronal activity (rate of firing) based on a given input synaptic rate, weight of inputs, and decay rate. Higher input or weight increases firing rate and higher decay rate decreases it.",
    "name": "calculate_neuronal_activity",
    "parameters": {
      "properties": {
        "decay_rate": {
          "description": "The rate at which the neuron's potential decays in the absence of inputs.",
          "type": "float"
        },
        "input_synaptic_rate": {
          "description": "The synaptic input rate, usually represented as number of inputs per second.",
          "type": "integer"
        },
        "weight": {
          "description": "The weight of the input, denoting its influence on the neuron's state. Default is 1.0.",
          "type": "float"
        }
      },
      "required": [
        "input_synaptic_rate",
        "decay_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Build a linear regression model using given predictor variables and a target variable.",
    "name": "run_linear_regression",
    "parameters": {
      "properties": {
        "predictors": {
          "description": "Array containing the names of predictor variables.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "standardize": {
          "description": "Option to apply standardization on the predictors. Defaults to False.",
          "type": "boolean"
        },
        "target": {
          "description": "The name of target variable.",
          "type": "string"
        }
      },
      "required": [
        "predictors",
        "target"
      ],
      "type": "dict"
    }
  }
]
```

## Item 153 -- `unc:3bdf4111b1edc5087cd2e54a78097e410efabda51a3a9f1cfd06e6a09211fa35`

### Question

```
Who was the winner of the 2017 Elitettan?
```

### Available tools

```json
[
  {
    "description": "Calculate the entropy change for an isothermal and reversible process.",
    "name": "calculate_entropy_change",
    "parameters": {
      "properties": {
        "final_temp": {
          "description": "The final temperature in Kelvin.",
          "type": "integer"
        },
        "heat_capacity": {
          "description": "The heat capacity in J/K.",
          "type": "integer"
        },
        "initial_temp": {
          "description": "The initial temperature in Kelvin.",
          "type": "integer"
        },
        "isothermal": {
          "description": "Whether the process is isothermal. Default is True.",
          "type": "boolean"
        }
      },
      "required": [
        "initial_temp",
        "final_temp",
        "heat_capacity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 154 -- `unc:db33ac881abf326ac6c7576695ac5574f290482ddd09d7db46bf81815aa56819`

### Question

```
What will the highest temperature recorded in Hengshui, People's Republic of China be on 12 March 2044?
```

### Available tools

```json
[
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 155 -- `unc:596ed03df82895007cc47b2f2e67dea1ef8ff7e9716bf27530451ed8ce2cc278`

### Question

```
Who was the winner of the 2016 STOK Integration Championship?
```

### Available tools

```json
[
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  }
]
```

## Item 156 -- `unc:5b316af2ab3bfd2b4c1a5de3ee6a38191f20f0b89e3f79730c851aacd702e9bb`

### Question

```
In 2042, who will win the 1. divisjon football?
```

### Available tools

```json
[
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  }
]
```

## Item 157 -- `unc:93d4372b88501894ea4a4ecf6776d9e26d3513ab4b1d99956939af3e163d8951`

### Question

```
Who is going to be the winner of the 2035 NCAA Division III Field Hockey Championship?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  }
]
```

## Item 158 -- `unc:12d28f64bde1ced3c958422ab41a0328e99bee1ef3197c93027cf2cff1d4036f`

### Question

```
Which team or competitor will win the World Baseball Classic in 2044?
```

### Available tools

```json
[
  {
    "description": "Calculate the speed of an object based on the distance travelled and the time taken.",
    "name": "calculate_speed",
    "parameters": {
      "properties": {
        "distance": {
          "description": "The distance the object travelled in meters.",
          "type": "integer"
        },
        "time": {
          "description": "The time it took for the object to travel in seconds.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit in which the speed should be calculated, default is m/s.",
          "type": "string"
        }
      },
      "required": [
        "distance",
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 159 -- `unc:117b92c8451b627fca9b917de83461f04ad9e53e5e767086191561937c67fd6f`

### Question

```
Who is going to be the winner of the 2056 Campeonato Carioca?
```

### Available tools

```json
[
  {
    "description": "Examine the social dynamics and interactions within a group based on the personality traits and group size.",
    "name": "group_dynamics.pattern",
    "parameters": {
      "properties": {
        "extroverts": {
          "description": "The number of extroverted members in the group.",
          "type": "integer"
        },
        "introverts": {
          "description": "The number of introverted members in the group.",
          "type": "integer"
        },
        "total": {
          "description": "The total group size.",
          "type": "integer"
        }
      },
      "required": [
        "total",
        "extroverts",
        "introverts"
      ],
      "type": "dict"
    }
  }
]
```

## Item 160 -- `unc:2c79ba7785efa0f3f0e39afa8598be387669a6893fca72f8c038e8cc8fa2ac5c`

### Question

```
Which team or competitor will win the Women's Chess World Cup in 2041?
```

### Available tools

```json
[
  {
    "description": "Fetch the brain MRI report of the patient for a given status.",
    "name": "patient.get_mri_report",
    "parameters": {
      "properties": {
        "mri_type": {
          "description": "Type of the MRI. Default to be 'brain'.",
          "enum": [
            "brain",
            "spinal",
            "chest",
            "abdominal"
          ],
          "type": "string"
        },
        "patient_id": {
          "description": "The patient identifier.",
          "type": "string"
        },
        "status": {
          "description": "Status of the report, could be 'in progress', 'concluded' or 'draft'.",
          "enum": [
            "in progress",
            "concluded",
            "draft"
          ],
          "type": "string"
        }
      },
      "required": [
        "patient_id",
        "status"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the average of a list of numbers.",
    "name": "calculate_average",
    "parameters": {
      "properties": {
        "numbers": {
          "description": "The list of numbers to calculate the average of.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "numbers"
      ],
      "type": "dict"
    }
  }
]
```

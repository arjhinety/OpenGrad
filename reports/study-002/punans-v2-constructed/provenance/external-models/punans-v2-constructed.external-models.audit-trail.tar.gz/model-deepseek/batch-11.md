# Annotation batch 11 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 201 -- `unc:ad3a530fdd0ca709312d09ee1fea89988c02bb7038994cb79b0a96cc7cf786e4`

### Question

```
Who is going to be the winner of the 2058 Supercopa de España femenina de Hockey Patines?
```

### Available tools

```json
[
  {
    "description": "Locate nearby concerts based on specific criteria like genre.",
    "name": "concert.find_nearby",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Genre of music to be played at the concert.",
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Seattle, WA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Modify an existing painting's attributes such as size, medium, and color.",
    "name": "modify_painting",
    "parameters": {
      "properties": {
        "dominant_color": {
          "description": "The dominant color of the painting. Default to 'black'.",
          "type": "string"
        },
        "medium": {
          "description": "The medium of the painting, such as oil, acrylic, etc.",
          "type": "string"
        },
        "size": {
          "description": "The size of the painting in inches, width by height.",
          "type": "string"
        }
      },
      "required": [
        "size",
        "medium"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 202 -- `unc:3eb83d6e98787c09a72ded068b52824438d4c02c099506f52ac903695b81b435`

### Question

```
What will the highest temperature recorded in Kaifeng, People's Republic of China be on 19 April 2049?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 203 -- `unc:b98ffa7d5195df1edf15de7a908eb896242909f4ac856763bc62cba07a2b5590`

### Question

```
In 2055, who will win the PDC World Darts Championship?
```

### Available tools

```json
[
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  }
]
```

## Item 204 -- `unc:566991b59b1fcb820982b3f5daa92b9728ecab5c5b8dded9a964e3b33a8125ee`

### Question

```
What was the population of Yongzhou, People's Republic of China as of 2020?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  }
]
```

## Item 205 -- `unc:40d0498ad06969156f2a61f913892a6bf283177c67eda221934a85ab5f6f4c1c`

### Question

```
How hot will it get in Kota, India on 6 May 2055?
```

### Available tools

```json
[
  {
    "description": "Calculate the density of a substance based on its mass and volume.",
    "name": "calculate_density",
    "parameters": {
      "properties": {
        "mass": {
          "description": "The mass of the substance in kilograms.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of density. Default is kg/m³",
          "type": "string"
        },
        "volume": {
          "description": "The volume of the substance in cubic meters.",
          "type": "integer"
        }
      },
      "required": [
        "mass",
        "volume"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the nearest parking lot based on a specific location and radius.",
    "name": "parking_lot.find_nearest",
    "parameters": {
      "properties": {
        "location": {
          "description": "The reference location e.g. Central Park, NY",
          "type": "string"
        },
        "radius": {
          "description": "The maximum distance from the location in miles. Default is 5 miles",
          "type": "integer"
        },
        "type": {
          "description": "The type of parking lot. Default is 'public'.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 206 -- `unc:6a14cd4817a33f50864900de3eb6e1d371acc02c36374dbbb1a5f0015560f52b`

### Question

```
Who was the winner of the 2002 Men's World Floorball Championship?
```

### Available tools

```json
[
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  }
]
```

## Item 207 -- `unc:820b97e6de564509bd62c25384e9100613cde75bf3e330f9367734a6a301516e`

### Question

```
What will the highest temperature recorded in Zaozhuang, People's Republic of China be on 21 February 2050?
```

### Available tools

```json
[
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 208 -- `unc:05ee0292f25691f55ed6d201a7ace2fc55fbbfcece9f51cce1f8e9c4897c036b`

### Question

```
Which team or competitor will win the UEFA Women's Championship in 2053?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area and circumference of a circle based on the radius.",
    "name": "calculate_circle_dimensions",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 209 -- `unc:3ecae2e4f0c804bff25c1759f070da6c7aeac817a73ab751248dd6a1bbed8d1f`

### Question

```
Who will win the 2042 NCAA Division II football?
```

### Available tools

```json
[
  {
    "description": "Get the list of proteins in a specific cell compartment.",
    "name": "cellbio.get_proteins",
    "parameters": {
      "properties": {
        "cell_compartment": {
          "description": "The specific cell compartment.",
          "type": "string"
        },
        "include_description": {
          "default": "false",
          "description": "Set true if you want a brief description of each protein.",
          "type": "boolean"
        }
      },
      "required": [
        "cell_compartment"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 210 -- `unc:3a9572ad0795c8b591a4c8ad6beb3d2d149391061a91c7b5d55d49b422e5258a`

### Question

```
What was the population of Chandigarh, India as of 2011?
```

### Available tools

```json
[
  {
    "description": "Predict the price of a house in a given area based on number of bedrooms, bathrooms and area.",
    "name": "predict_house_price",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area of the house in square feet.",
          "type": "integer"
        },
        "bathrooms": {
          "description": "The number of bathrooms in the house.",
          "type": "integer"
        },
        "bedrooms": {
          "description": "The number of bedrooms in the house.",
          "type": "integer"
        },
        "location": {
          "description": "The location of the house in the format of city name.",
          "type": "string"
        }
      },
      "required": [
        "bedrooms",
        "bathrooms",
        "area",
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 211 -- `unc:3d32933a02f5322ee21f1b151aafb4d3326ff6d66c47d81b1946f0b6c6c1e14a`

### Question

```
Who will win the 2036 SMART Modified Tour?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 212 -- `unc:6c4977f3f5db3ee0b566e73ee81273b18f8815898d7a3d4b506fec757248e3aa`

### Question

```
In 2046, who will win the USF Juniors?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a recipe based on name and its calorie content",
    "name": "find_recipe",
    "parameters": {
      "properties": {
        "maxCalories": {
          "default": 1000,
          "description": "The maximum calorie content of the recipe.",
          "type": "integer"
        },
        "recipeName": {
          "description": "The recipe's name.",
          "type": "string"
        }
      },
      "required": [
        "recipeName"
      ],
      "type": "dict"
    }
  }
]
```

## Item 213 -- `unc:204ed0ed4c303a2ce23866c34f1fc0abc4c8266449cafaa8337fce7e971145cf`

### Question

```
On 5 April 2057, what high temperature will Bishkek, Kyrgyzstan record?
```

### Available tools

```json
[
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 214 -- `unc:90060c37becfe8ce5f9b4dd57d3aeddb3d85a9311582db93200af4527b62e217`

### Question

```
Which team or competitor will win the Ivy League Baseball Championship Series in 2043?
```

### Available tools

```json
[
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 215 -- `unc:38c78f1024405c1103ab1d90b0da1f1b60cd1205bac9f0000e907ebe0b3c0d99`

### Question

```
Who is going to be the winner of the 2051 Galway Senior Hurling Club Championship?
```

### Available tools

```json
[
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 216 -- `unc:e7dd2c43d6f34c889cc8bf2ec5c3cfc705ebffb2a561832bbfb667a2deb7aa62`

### Question

```
Who will win the 2057 National Collegiate Hockey Conference Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the electromagnetic force between two charges placed at a certain distance.",
    "name": "electromagnetic_force",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The magnitude of the first charge in coulombs.",
          "type": "integer"
        },
        "charge2": {
          "description": "The magnitude of the second charge in coulombs.",
          "type": "integer"
        },
        "distance": {
          "description": "The distance between the two charges in meters.",
          "type": "integer"
        },
        "medium_permittivity": {
          "description": "The relative permittivity of the medium in which the charges are present. Default is 8.854e-12 (Vacuum Permittivity).",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generates a random number from a normal distribution given the mean and standard deviation.",
    "name": "random.normalvariate",
    "parameters": {
      "properties": {
        "mu": {
          "description": "Mean of the normal distribution.",
          "type": "integer"
        },
        "sigma": {
          "description": "Standard deviation of the normal distribution.",
          "type": "integer"
        }
      },
      "required": [
        "mu",
        "sigma"
      ],
      "type": "dict"
    }
  }
]
```

## Item 217 -- `unc:3415fccfb1da922d4d44a38e33401ba3fa3be095dccaa81bf5d9be2284563da0`

### Question

```
In 2054, who will win the Oceania Rugby Women's Championship?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a right-angled triangle given the lengths of its base and height.",
    "name": "calculate_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the right-angled triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the right-angled triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure used. Defaults to 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on location and food preferences.",
    "name": "find_restaurants",
    "parameters": {
      "properties": {
        "dietary_requirements": {
          "description": "Special dietary requirements, e.g. vegan, gluten-free. Default is empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "food_type": {
          "description": "The type of food preferred.",
          "type": "string"
        },
        "location": {
          "description": "The specific location or area. The location should be in the format of District, City.",
          "type": "string"
        },
        "number": {
          "description": "Number of results to return.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "food_type",
        "number"
      ],
      "type": "dict"
    }
  }
]
```

## Item 218 -- `unc:5d24a77996b35e29d3bd7a1904730dea549b28513d60881118a83f7187111e6a`

### Question

```
In 2041, who will win the Girls' TV-pucken?
```

### Available tools

```json
[
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 219 -- `unc:6e11a01bb2e2d0ce96daaae84ebbc1a303e01615d34dda4c662eab2dc7967044`

### Question

```
On 2 May 2054, what high temperature will Hanzhong, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Finds the fastest route from one location to another, with an option to avoid toll roads.",
    "name": "map_routing.fastest_route",
    "parameters": {
      "properties": {
        "avoid_tolls": {
          "description": "Option to avoid toll roads during the journey. Default is false.",
          "type": "boolean"
        },
        "end_location": {
          "description": "The destination for the journey.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the journey.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 220 -- `unc:6cd974698f9fb748349601c3d3cdbbd59ddc69a48fdcd42a6b4d8c12e6e58310`

### Question

```
How hot will it get in Leiyang, People's Republic of China on 8 May 2057?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the estimated return on a mutual fund given the yearly yield, the investment amount and the time period.",
    "name": "estimate_mutual_fund_return",
    "parameters": {
      "properties": {
        "investment_amount": {
          "description": "The initial investment amount in the mutual fund.",
          "type": "integer"
        },
        "yearly_yield": {
          "description": "The yearly yield of the mutual fund as a percentage.",
          "type": "float"
        },
        "years": {
          "description": "The time period for which the investment is made in years.",
          "type": "integer"
        }
      },
      "required": [
        "yearly_yield",
        "investment_amount",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

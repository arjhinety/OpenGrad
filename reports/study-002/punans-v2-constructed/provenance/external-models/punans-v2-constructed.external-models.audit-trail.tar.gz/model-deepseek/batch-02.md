# Annotation batch 02 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 21 -- `unc:2faeb670c459872a36be3d8d6a4c96588850a88828b82b3f76b7270045984b74`

### Question

```
What will the highest temperature recorded in Konya, Turkey be on 18 January 2051?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  }
]
```

## Item 22 -- `unc:fe53c56e9e735e3ce99ca25c0731dc0c84c1b06b8dd8eb82b1f8ab666d3edd30`

### Question

```
Which team or competitor will win the J2 League in 2041?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 23 -- `unc:2230aaf309e7ba7ae0688b9f2cc6d7ea55769bba87a9aff516e083f37f1916c7`

### Question

```
Who won the 2001 Russian Premier League?
```

### Available tools

```json
[
  {
    "description": "Calculates the probability of an event.",
    "name": "probability_of_event",
    "parameters": {
      "properties": {
        "format_as_ratio": {
          "description": "When true, formats the output as a ratio instead of a decimal. Default is false.",
          "type": "boolean"
        },
        "success_outcomes": {
          "description": "The number of successful outcomes.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "success_outcomes",
        "total_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  }
]
```

## Item 24 -- `unc:bfa171f60bf849e691ed6dd4d83af8276b677ab288321fc4ca8f3f3f0a4fbefd`

### Question

```
What will the maximum temperature in Belém, Brazil be on 16 September 2058?
```

### Available tools

```json
[
  {
    "description": "Calculates the probability of an outcome based on the binomial distribution",
    "name": "calc_binomial_prob",
    "parameters": {
      "properties": {
        "num_success": {
          "description": "Number of times the event of interest has occurred.",
          "type": "integer"
        },
        "num_trials": {
          "description": "Number of independent experiments.",
          "type": "integer"
        },
        "prob_success": {
          "description": "Probability of the event of interest on any single experiment.",
          "type": "float"
        }
      },
      "required": [
        "num_trials",
        "num_success",
        "prob_success"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  }
]
```

## Item 25 -- `unc:d245f0b8ce8f60e84275c7d1d22f5a6367c9d49803557c91f0358a383e4fb870`

### Question

```
What will the highest temperature recorded in Abu Dhabi, United Arab Emirates be on 21 January 2044?
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the projected return of a stock investment given the investment amount, the annual growth rate and holding period in years.",
    "name": "calculate_stock_return",
    "parameters": {
      "properties": {
        "annual_growth_rate": {
          "description": "The expected annual growth rate of the stock.",
          "type": "float"
        },
        "dividends": {
          "description": "Optional. True if the calculation should take into account potential dividends. Default is false.",
          "type": "boolean"
        },
        "holding_period": {
          "description": "The number of years you intend to hold the stock.",
          "type": "integer"
        },
        "investment_amount": {
          "description": "The amount of money to invest.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_growth_rate",
        "holding_period"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 26 -- `unc:e7a51373eb4ca6d8d5a3756fc2c38ed5272534b67ecb02c12976cec970eb5818`

### Question

```
Who is going to be the winner of the 2049 Uzbekistan Cup?
```

### Available tools

```json
[
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the circumference of a circle with a given radius.",
    "name": "calculate_circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle in the unit given.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measurement for the radius. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 27 -- `unc:6bac343908ccd64c87ec029af21713d526edd2a82a33af9cddb3812cd6eb3d62`

### Question

```
How hot will it get in Yangzhou, People's Republic of China on 24 February 2045?
```

### Available tools

```json
[
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 28 -- `unc:f54fa425e3143419331280c39159da531c7bf09bbbd4bc7ec69ff4186a4120a2`

### Question

```
How many people lived in Wuhan, People's Republic of China in 2019?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electrostatic potential between two charged bodies using the principle of Coulomb's Law.",
    "name": "calculate_electrostatic_potential",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The quantity of charge on the first body.",
          "type": "float"
        },
        "charge2": {
          "description": "The quantity of charge on the second body.",
          "type": "float"
        },
        "constant": {
          "description": "The value of the electrostatic constant. Default is 8.99e9.",
          "type": "float"
        },
        "distance": {
          "description": "The distance between the two bodies.",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 29 -- `unc:1977f4fd94fc99f2772667851edb2f082cdf860941fee93becb4882874ceb90b`

### Question

```
How hot will it get in Monterrey, Mexico on 3 May 2040?
```

### Available tools

```json
[
  {
    "description": "Verify the details of a lawsuit case and check its status using case ID.",
    "name": "lawsuit.check_case",
    "parameters": {
      "properties": {
        "case_id": {
          "description": "The identification number of the lawsuit case.",
          "type": "integer"
        },
        "closed_status": {
          "description": "The status of the lawsuit case to be verified.",
          "type": "boolean"
        }
      },
      "required": [
        "case_id",
        "closed_status"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 30 -- `unc:dabb22a57fc114a326b9460bb2728fa150659c81099ebfc70f2eacb46671717c`

### Question

```
Who is going to be the winner of the 2049 Tata Steel Chess Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 31 -- `unc:1a67457d36894d447cb0d316a5f5bddc60b566b3fae5156a110e85c7c619d174`

### Question

```
In 2057, who will win the Rally Islas Canarias?
```

### Available tools

```json
[
  {
    "description": "Analyzes the DNA sequence based on a reference sequence and return any potential mutations.",
    "name": "analyze_dna_sequence",
    "parameters": {
      "properties": {
        "mutation_type": {
          "description": "Type of the mutation to be looked for in the sequence. Default to 'substitution'.",
          "enum": [
            "insertion",
            "deletion",
            "substitution"
          ],
          "type": "string"
        },
        "reference_sequence": {
          "description": "The reference DNA sequence.",
          "type": "string"
        },
        "sequence": {
          "description": "The DNA sequence to be analyzed.",
          "type": "string"
        }
      },
      "required": [
        "sequence",
        "reference_sequence"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 32 -- `unc:cb9f40f2ee37e3ba822b7f9ddb6927f35bb0546e08b13efdc149c3c0d5656db8`

### Question

```
In 2054, who will win the Kyrgyzstan League?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "probabilities.calculate_single",
    "parameters": {
      "properties": {
        "event_outcomes": {
          "description": "The number of outcomes where the event occurs.",
          "type": "integer"
        },
        "round": {
          "description": "Round the answer to a specified number of decimal places. Defaults to 2.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "The total number of outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "event_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get stock price data for a given company over a specified number of days.",
    "name": "stock_price",
    "parameters": {
      "properties": {
        "company": {
          "description": "The company name.",
          "type": "string"
        },
        "data_type": {
          "description": "The type of price data to retrieve (e.g., 'Open', 'Close', 'High', 'Low'). Default is 'Close'.",
          "type": "string"
        },
        "days": {
          "description": "The number of previous days to retrieve data for.",
          "type": "integer"
        }
      },
      "required": [
        "company",
        "days"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

## Item 33 -- `unc:882dcbe237f13be970a69f1a0fc1a93cd80e16c3b239b92dd55e85a62e3403b4`

### Question

```
What will the maximum temperature in Patna, India be on 24 February 2050?
```

### Available tools

```json
[
  {
    "description": "Calculates the binomial probability given the number of trials, successes and the probability of success on an individual trial.",
    "name": "calculate_binomial_probability",
    "parameters": {
      "properties": {
        "number_of_successes": {
          "description": "The desired number of successful outcomes.",
          "type": "integer"
        },
        "number_of_trials": {
          "description": "The total number of trials.",
          "type": "integer"
        },
        "probability_of_success": {
          "default": 0.5,
          "description": "The probability of a successful outcome on any given trial.",
          "type": "float"
        }
      },
      "required": [
        "number_of_trials",
        "number_of_successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for a certain time period.",
    "name": "compound_interest",
    "parameters": {
      "properties": {
        "annual_rate": {
          "description": "The interest rate for a year as a percentage.",
          "type": "float"
        },
        "compounding_freq": {
          "description": "The number of times that interest is compounded per unit period.",
          "enum": [
            "monthly",
            "quarterly",
            "annually"
          ],
          "type": "string"
        },
        "principal": {
          "description": "The initial amount of money that was invested or loaned out.",
          "type": "integer"
        },
        "time_in_years": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "annual_rate",
        "compounding_freq",
        "time_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 34 -- `unc:9b1796cd9a89c3b7be13f812feb584a9fd0ab4a2613ecf7ed3c99471bc2c82cc`

### Question

```
In 1998, who won the ARCA Racing Series?
```

### Available tools

```json
[
  {
    "description": "Calculate the area and circumference of a circle based on the radius.",
    "name": "calculate_circle_dimensions",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the future value of an investment based on the present value, interest rate, and time period.",
    "name": "calculate_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate in decimal form. Example, 5% is 0.05.",
          "type": "float"
        },
        "compounds_per_year": {
          "description": "The number of times the interest is compounded per year. Default is 1 (annual compounding).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value or principal amount.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 35 -- `unc:a3ca1a553895fde2903d082dad24c20e686c969d31a5647a075ae8cea505e731`

### Question

```
In 2043, who will win the British Grand Prix?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 36 -- `unc:e665ab62b5ae9b949978d64a537b605a23414bf6767a069600b436bc2534384d`

### Question

```
In 2049, who will win the Major League Soccer?
```

### Available tools

```json
[
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 37 -- `unc:043401fa60addb33ad9635a42f61b1069277853f6e911224203e0015dd0cdaef`

### Question

```
On 5 April 2050, what high temperature will Dar es Salaam, Tanzania record?
```

### Available tools

```json
[
  {
    "description": "Generate a random DNA sequence with a specific length and nucleotide preference.",
    "name": "generate_DNA_sequence",
    "parameters": {
      "properties": {
        "length": {
          "description": "The length of the DNA sequence to be generated.",
          "type": "integer"
        },
        "preferences": {
          "description": "Preferred nucleotides to include more frequently in the DNA sequence.",
          "items": {
            "enum": [
              "A",
              "T",
              "C",
              "G"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "length",
        "preferences"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  }
]
```

## Item 38 -- `unc:e87b98411cb04a5b12d731e8d341d1f30fab625ebbf2878646e144bc05d8b942`

### Question

```
What will the highest temperature recorded in Hwaseong, South Korea be on 13 September 2052?
```

### Available tools

```json
[
  {
    "description": "Locate local nurseries based on location and plant types availability.",
    "name": "local_nursery.find",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city or locality where the nursery needs to be located.",
          "type": "string"
        },
        "plant_types": {
          "description": "Type of plants the nursery should provide.",
          "items": {
            "enum": [
              "Annual",
              "Perennial",
              "Shrub",
              "Tree",
              "Herbs",
              "Fruits"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "plant_types"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the future value of an investment based on the present value, interest rate, and time period.",
    "name": "calculate_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate in decimal form. Example, 5% is 0.05.",
          "type": "float"
        },
        "compounds_per_year": {
          "description": "The number of times the interest is compounded per year. Default is 1 (annual compounding).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value or principal amount.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 39 -- `unc:384ec687c7771156a3467e450c28d91b9a31d634ac169fb8889ecde0a029d5dc`

### Question

```
What will the highest temperature recorded in Zhaotong, People's Republic of China be on 19 April 2045?
```

### Available tools

```json
[
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 40 -- `unc:3af40b583886b113e15bb5a9b4c08699bdb24d5fdfc0b128d14203908b0d860c`

### Question

```
In 2058, who will win the Tenno Sho?
```

### Available tools

```json
[
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  }
]
```

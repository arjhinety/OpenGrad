# Annotation batch 15 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 281 -- `unc:5f84f7ff8541ab4dcab89b7e045fa0495e06294a9562e8000ddcfa4144595c64`

### Question

```
How hot will it get in Cần Thơ, Vietnam on 1 July 2048?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one kitchen unit to another for cooking purposes.",
    "name": "recipe.unit_conversion",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "precision": {
          "description": "The precision to round the output to, in case of a non-integer result. Optional, default is 1.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "value": {
          "description": "The value to be converted.",
          "type": "integer"
        }
      },
      "required": [
        "value",
        "from_unit",
        "to_unit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 282 -- `unc:f19c473fb376215a02a159f0e4536c25657d26422976b620d2907304c905c17a`

### Question

```
In 2037, who will win the NCAA Division III men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of having 'success' outcome from binomial distribution.",
    "name": "prob_dist.binomial",
    "parameters": {
      "properties": {
        "p": {
          "description": "The probability of success on any given trial, defaults to 0.5",
          "type": "float"
        },
        "successes": {
          "description": "The number of success events.",
          "type": "integer"
        },
        "trials": {
          "description": "The number of independent experiments.",
          "type": "integer"
        }
      },
      "required": [
        "trials",
        "successes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 283 -- `unc:88086f2b119b9536fadc659beb9b48720ce3c7abe0447d2d6ca2f2dd69c50ef1`

### Question

```
What will the maximum temperature in Gwalior, India be on 20 March 2040?
```

### Available tools

```json
[
  {
    "description": "Calculate the Compound Annual Growth Rate (CAGR) given an initial investment value, a final investment value, and the number of years.",
    "name": "calculate_cagr",
    "parameters": {
      "properties": {
        "final_value": {
          "description": "The final investment value.",
          "type": "integer"
        },
        "initial_value": {
          "description": "The initial investment value.",
          "type": "integer"
        },
        "period_in_years": {
          "description": "The period of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_value",
        "final_value",
        "period_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 284 -- `unc:dc801abab4e15ad23a6397004f3ae0f9135d4b15980677371a807d12545d8a59`

### Question

```
In 2020, what was the population of Xuzhou, People's Republic of China?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

## Item 285 -- `unc:3a82a7ef02c48b1654a027484204f3038b680ad3d1edb3ea732ddefcb5422314`

### Question

```
What was the population of Qingyuan, People's Republic of China as of 2020?
```

### Available tools

```json
[
  {
    "description": "This function identifies the RGB values of a named color.",
    "name": "identify_color_rgb",
    "parameters": {
      "properties": {
        "color_name": {
          "description": "Name of the color.",
          "type": "string"
        },
        "standard": {
          "description": "The color standard (e.g. basic, pantone). Default is 'basic'",
          "type": "string"
        }
      },
      "required": [
        "color_name"
      ],
      "type": "dict"
    }
  }
]
```

## Item 286 -- `unc:de2008572ad3b16f8e3194b5e58b44299860d6ebf73c0599ebf90d21d75a0b07`

### Question

```
What will the highest temperature recorded in Hiroshima, Japan be on 17 May 2047?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  }
]
```

## Item 287 -- `unc:4398bd5968150b6871948b06ea49dc81aeee26ef25c59446f3806f141be338cd`

### Question

```
In 2020, what was the population of Zhenjiang, People's Republic of China?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given its present value, interest rate, the number of compounding periods per year, and the time horizon.",
    "name": "finance.predict_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate of the investment.",
          "type": "float"
        },
        "compounding_periods_per_year": {
          "description": "The number of times that interest is compounded per year. Default is 1 (annually).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value of the investment.",
          "type": "integer"
        },
        "time_years": {
          "description": "The investment horizon in years.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "time_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the cell density of a biological sample based on its optical density and the experiment dilution.",
    "name": "calculate_cell_density",
    "parameters": {
      "properties": {
        "calibration_factor": {
          "description": "The calibration factor to adjust the density, default value is 1e9 assuming cell density is in CFU/mL.",
          "type": "float"
        },
        "dilution": {
          "description": "The dilution factor applied during the experiment.",
          "type": "integer"
        },
        "optical_density": {
          "description": "The optical density of the sample, usually obtained from a spectrophotometer reading.",
          "type": "float"
        }
      },
      "required": [
        "optical_density",
        "dilution"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 288 -- `unc:d3d37a500140ef90a4deb64a9767da79378f5b371ee19912d733a4fb4df5691b`

### Question

```
What will the highest temperature recorded in Goiânia, Brazil be on 7 July 2044?
```

### Available tools

```json
[
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 289 -- `unc:71d09da82d390b1ed5edf98bd9e467df148584bd6a041de600a36465a7ae02d5`

### Question

```
Who will win the 2054 Rose Bowl Game?
```

### Available tools

```json
[
  {
    "description": "Analyzes the DNA sequence based on a reference sequence and return any potential mutations.",
    "name": "analyze_dna_sequence",
    "parameters": {
      "properties": {
        "mutation_type": {
          "description": "Type of the mutation to be looked for in the sequence. Default to 'substitution'.",
          "enum": [
            "insertion",
            "deletion",
            "substitution"
          ],
          "type": "string"
        },
        "reference_sequence": {
          "description": "The reference DNA sequence.",
          "type": "string"
        },
        "sequence": {
          "description": "The DNA sequence to be analyzed.",
          "type": "string"
        }
      },
      "required": [
        "sequence",
        "reference_sequence"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 290 -- `unc:f73b8058b6b96eea2f257b93e2252ef6759d487959cf96b608c0b71de61eb49d`

### Question

```
What will the maximum temperature in Hangzhou, People's Republic of China be on 28 March 2059?
```

### Available tools

```json
[
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electromagnetic force between two charges placed at a certain distance.",
    "name": "electromagnetic_force",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The magnitude of the first charge in coulombs.",
          "type": "integer"
        },
        "charge2": {
          "description": "The magnitude of the second charge in coulombs.",
          "type": "integer"
        },
        "distance": {
          "description": "The distance between the two charges in meters.",
          "type": "integer"
        },
        "medium_permittivity": {
          "description": "The relative permittivity of the medium in which the charges are present. Default is 8.854e-12 (Vacuum Permittivity).",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 291 -- `unc:cb7a609a167024d28101e2e29efba1c41405f4cc1b0395a293adacdc7de94264`

### Question

```
Which team or competitor will win the Barum Czech Rally Zlín in 2043?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  }
]
```

## Item 292 -- `unc:01c0ab4f8e6be26f8c22ff0e25710bd6f2480b20eea6b44fa1f9703c64b7fe6a`

### Question

```
Which team or competitor will win the AFC U-23 Asian Cup in 2044?
```

### Available tools

```json
[
  {
    "description": "Finds the type of a genetic mutation based on its SNP (Single Nucleotide Polymorphism) ID.",
    "name": "mutation_type.find",
    "parameters": {
      "properties": {
        "snp_id": {
          "description": "The ID of the Single Nucleotide Polymorphism (SNP) mutation.",
          "type": "string"
        },
        "species": {
          "description": "Species in which the SNP occurs, default is 'Homo sapiens' (Humans).",
          "type": "string"
        }
      },
      "required": [
        "snp_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 293 -- `unc:d2933b4b647d58943d04a550967ac9bed6f5aab2696c04032349d3ed3e022522`

### Question

```
How hot will it get in Kawasaki, Japan on 26 July 2040?
```

### Available tools

```json
[
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  }
]
```

## Item 294 -- `unc:3d287719c2413ab0c44987a644d4ac35debda07bca0dbb3c9a559e89a2250e9d`

### Question

```
Which team or competitor will win the NORCECA Women's Volleyball Championship in 2053?
```

### Available tools

```json
[
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 295 -- `unc:afb37d2357f50fbabcb14643e46ab0bce435ddcafd41c4b5750e853f6f01f5fd`

### Question

```
How many people lived in Maiduguri, Nigeria in 2009?
```

### Available tools

```json
[
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  }
]
```

## Item 296 -- `unc:43486da4dcc9c988babd9a2d979fdb24642b44bc470b8e0fb9b203405740c176`

### Question

```
How hot will it get in Jieyang, People's Republic of China on 30 April 2040?
```

### Available tools

```json
[
  {
    "description": "Calculate the Body Mass Index (BMI) of a person.",
    "name": "calculate_bmi",
    "parameters": {
      "properties": {
        "height": {
          "description": "Height of the person in centimeters.",
          "type": "integer"
        },
        "unit": {
          "description": "Optional parameter to choose between 'imperial' and 'metric' systems. Default is 'metric'.",
          "type": "string"
        },
        "weight": {
          "description": "Weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 297 -- `unc:595108d983b02881920b18179077638addcd473d7cb538f334c205e63a2f1569`

### Question

```
How hot will it get in Haikou, People's Republic of China on 12 March 2055?
```

### Available tools

```json
[
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 298 -- `unc:d7ebd0b3522f266b26df5d906ee65e3c4c4b7612e8cc715572c1ca269d027252`

### Question

```
How hot will it get in Volgograd, Russia on 4 April 2037?
```

### Available tools

```json
[
  {
    "description": "Locate local nurseries based on location and plant types availability.",
    "name": "local_nursery.find",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city or locality where the nursery needs to be located.",
          "type": "string"
        },
        "plant_types": {
          "description": "Type of plants the nursery should provide.",
          "items": {
            "enum": [
              "Annual",
              "Perennial",
              "Shrub",
              "Tree",
              "Herbs",
              "Fruits"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "plant_types"
      ],
      "type": "dict"
    }
  }
]
```

## Item 299 -- `unc:4c0ab2ecb6948772eea19165411f1d00922a9b0675e85edb57a60766cbe52b0a`

### Question

```
Who won the 2014 West Coast Conference men's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  }
]
```

## Item 300 -- `unc:fb46c3ab3cde4d719ea43d0794a81e9aab091cab5775ade4596e9a8cac620b94`

### Question

```
Who is going to be the winner of the 2055 Dakar Rally?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 13 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 241 -- `unc:a6295c4fa69f0d7dcbdd4d617296d0248c1851076e85f5a6b56c8c6b9267f0ea`

### Question

```
Who is going to be the winner of the 2053 Big South Conference women's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 242 -- `unc:dc3a03f104811d6cfdb03359ac03be231452489acf1bced9a8de5b4e2e5d5ad3`

### Question

```
Who is going to be the winner of the 2047 Frontier League?
```

### Available tools

```json
[
  {
    "description": "Send an email to the specified email address.",
    "name": "send_email",
    "parameters": {
      "properties": {
        "bcc": {
          "description": "The email address to blind carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "body": {
          "description": "The body content of the email.",
          "type": "string"
        },
        "cc": {
          "description": "The email address to carbon copy. Default is empty if not specified.",
          "type": "string"
        },
        "subject": {
          "description": "The subject of the email.",
          "type": "string"
        },
        "to": {
          "description": "The email address to send to.",
          "type": "string"
        }
      },
      "required": [
        "to",
        "subject",
        "body"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the latest court case between two companies.",
    "name": "find_latest_court_case",
    "parameters": {
      "properties": {
        "company1": {
          "description": "The name of the first company.",
          "type": "string"
        },
        "company2": {
          "description": "The name of the second company.",
          "type": "string"
        },
        "country": {
          "default": "USA",
          "description": "The country in which the court case is located.",
          "type": "string"
        }
      },
      "required": [
        "company1",
        "company2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 243 -- `unc:d2848a96c99530d821729230fd7b4b89ad0cb3c8371de94ea7b2f2a7403c0ccb`

### Question

```
Who was the winner of the 2019 WAC women's basketball tournament?
```

### Available tools

```json
[
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  }
]
```

## Item 244 -- `unc:0457b560641f652b163b3ac32f0a40c5e704c6bc2f0b9803fb733f9d6ff7dce8`

### Question

```
Who is going to be the winner of the 2060 Premier League Darts?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 245 -- `unc:4e7618ec6715113f6a7cd28298c728c12861c56a14b01e9f1d958fea9875f9ac`

### Question

```
What will the maximum temperature in Chiang Mai, Thailand be on 2 October 2040?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 246 -- `unc:b7f204c32cb51e3d76c30d3f4765bbbffd36daf12c38acb46ecaadb275f164e8`

### Question

```
Which team or competitor won the Kilkenny Senior Hurling League in 2017?
```

### Available tools

```json
[
  {
    "description": "Compose a melody using the specified chord progression for a certain number of measures on specified instrument.",
    "name": "compose_melody",
    "parameters": {
      "properties": {
        "instrument": {
          "description": "The instrument for the composition. Default is 'Piano'.",
          "type": "string"
        },
        "measures": {
          "description": "The number of measures of the melody.",
          "type": "integer"
        },
        "progression": {
          "description": "The progression of chords.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "progression",
        "measures"
      ],
      "type": "dict"
    }
  }
]
```

## Item 247 -- `unc:9c52aee497cb7a8da67a015b5c208f4529394cead3895d1ddfe80722694ffc1b`

### Question

```
What will the highest temperature recorded in Suqian, People's Republic of China be on 12 March 2057?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 248 -- `unc:8800f597f8cbfd465b43f1c153a133514ada0430155e4d04f88cc647206d7636`

### Question

```
Who is going to be the winner of the 2041 Big South Conference women's soccer tournament?
```

### Available tools

```json
[
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 249 -- `unc:46e024e29d48e4d7473c94c8636f551295bbfab61ca8e0bea47bb46dc0b76469`

### Question

```
In 2036, who will win the NASCAR O'Reilly Auto Parts Series?
```

### Available tools

```json
[
  {
    "description": "Predict the evolutionary rate for a specific species for a given timeframe.",
    "name": "prediction.evolution",
    "parameters": {
      "properties": {
        "model": {
          "description": "The model used to make the prediction, options: 'Darwin', 'Lamarck', default is 'Darwin'.",
          "type": "string"
        },
        "species": {
          "description": "The species that the evolution rate will be predicted for.",
          "type": "string"
        },
        "years": {
          "description": "Number of years for the prediction.",
          "type": "integer"
        }
      },
      "required": [
        "species",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 250 -- `unc:500a9078413846ac9371cb55e63262c0f15cdc146616c422ecf8d4f4b23757ae`

### Question

```
Who will win the 2037 Takamatsunomiya Kinen?
```

### Available tools

```json
[
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electrostatic potential between two charged bodies using the principle of Coulomb's Law.",
    "name": "calculate_electrostatic_potential",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The quantity of charge on the first body.",
          "type": "float"
        },
        "charge2": {
          "description": "The quantity of charge on the second body.",
          "type": "float"
        },
        "constant": {
          "description": "The value of the electrostatic constant. Default is 8.99e9.",
          "type": "float"
        },
        "distance": {
          "description": "The distance between the two bodies.",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 251 -- `unc:781b64d784080b33bc3d7e1ecb7802595275d34dbe7d2ec019470720ded3c5d6`

### Question

```
In 2007, who won the Asia Rugby Women's Championship?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch the brain MRI report of the patient for a given status.",
    "name": "patient.get_mri_report",
    "parameters": {
      "properties": {
        "mri_type": {
          "description": "Type of the MRI. Default to be 'brain'.",
          "enum": [
            "brain",
            "spinal",
            "chest",
            "abdominal"
          ],
          "type": "string"
        },
        "patient_id": {
          "description": "The patient identifier.",
          "type": "string"
        },
        "status": {
          "description": "Status of the report, could be 'in progress', 'concluded' or 'draft'.",
          "enum": [
            "in progress",
            "concluded",
            "draft"
          ],
          "type": "string"
        }
      },
      "required": [
        "patient_id",
        "status"
      ],
      "type": "dict"
    }
  }
]
```

## Item 252 -- `unc:240ee4f787a052a1fbceab5639189079f811fa908cf45b755ac114097d9540ec`

### Question

```
On 5 September 2046, what high temperature will Marrakech, Morocco record?
```

### Available tools

```json
[
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 253 -- `unc:f6105fdebac186a444cbe865e10a1018d3d822b60f7549a80d507705dfa836ef`

### Question

```
What will the maximum temperature in Quetta, Pakistan be on 5 September 2037?
```

### Available tools

```json
[
  {
    "description": "Fetch the recipe for a specific dish along with preparation steps.",
    "name": "get_recipe",
    "parameters": {
      "properties": {
        "diet_preference": {
          "default": "none",
          "description": "Preferred dietary consideration like vegan, vegetarian, gluten-free etc. Default is none.",
          "type": "string"
        },
        "dish_name": {
          "description": "Name of the dish whose recipe needs to be fetched.",
          "type": "string"
        }
      },
      "required": [
        "dish_name"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given its radius.",
    "name": "geometry.calculate_area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit of the radius (optional parameter, default is 'units').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 254 -- `unc:a398b217918a80bc792a908e028076d359c71327a6818b4ba9100c5b497bad67`

### Question

```
Who will win the 2036 Rally Terra da Auga?
```

### Available tools

```json
[
  {
    "description": "Calculates the annual carbon dioxide emissions produced by a vehicle based on the distance traveled, the fuel type and the fuel efficiency of the vehicle.",
    "name": "calculate_emissions",
    "parameters": {
      "properties": {
        "distance": {
          "description": "The distance travelled in miles.",
          "type": "integer"
        },
        "efficiency_reduction": {
          "description": "The percentage decrease in fuel efficiency per year (optional). Default is 0",
          "type": "integer"
        },
        "fuel_efficiency": {
          "description": "The vehicle's fuel efficiency in miles per gallon.",
          "type": "float"
        },
        "fuel_type": {
          "description": "Type of fuel used by the vehicle.",
          "type": "string"
        }
      },
      "required": [
        "distance",
        "fuel_type",
        "fuel_efficiency"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  }
]
```

## Item 255 -- `unc:2fb2abf5a72257fe8169ed57bdd04da042e5231ec678b64d42335428b1dbbb74`

### Question

```
Who will win the 2039 NCAA Division III women's basketball?
```

### Available tools

```json
[
  {
    "description": "Calculate the power of one number raised to another.",
    "name": "math.power",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base number.",
          "type": "integer"
        },
        "exponent": {
          "description": "The exponent.",
          "type": "integer"
        },
        "mod": {
          "description": "The modulus. Default is 1. Calculates pow(base, exponent) % mod when provided.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "exponent"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generate a random DNA sequence with a specific length and nucleotide preference.",
    "name": "generate_DNA_sequence",
    "parameters": {
      "properties": {
        "length": {
          "description": "The length of the DNA sequence to be generated.",
          "type": "integer"
        },
        "preferences": {
          "description": "Preferred nucleotides to include more frequently in the DNA sequence.",
          "items": {
            "enum": [
              "A",
              "T",
              "C",
              "G"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "length",
        "preferences"
      ],
      "type": "dict"
    }
  }
]
```

## Item 256 -- `unc:ef43052d0a046ca61467900687471f2cc5962b9093efb93e33e452326e7f9e85`

### Question

```
Who won the 2002 Cork Premier Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Find the roots of a quadratic equation ax^2 + bx + c = 0.",
    "name": "algebra.quadratic_roots",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x^2.",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x.",
          "type": "integer"
        },
        "c": {
          "description": "Constant term.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 257 -- `unc:718377d8ba77a9bb0d60ab241723355b849c2f4b3c943ddd0aa41f06ff31f3e7`

### Question

```
What will the highest temperature recorded in Ludhiana, India be on 13 August 2053?
```

### Available tools

```json
[
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 258 -- `unc:887be48dadea642a347140b285447c4e5fff905b95e1a21db6cf0ed54c1fb9f3`

### Question

```
On 11 July 2050, what high temperature will Nagpur, India record?
```

### Available tools

```json
[
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the greatest common divisor of two given integers.",
    "name": "number_theory.gcd",
    "parameters": {
      "properties": {
        "number1": {
          "description": "The first integer.",
          "type": "integer"
        },
        "number2": {
          "description": "The second integer.",
          "type": "integer"
        }
      },
      "required": [
        "number1",
        "number2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 259 -- `unc:baa56c6cf9e36a300e1209ca9cd5f1d6731984ba5335c21c038810255e872783`

### Question

```
How hot will it get in Jakarta, Indonesia on 18 September 2058?
```

### Available tools

```json
[
  {
    "description": "Calculate compound interest for a certain time period.",
    "name": "compound_interest",
    "parameters": {
      "properties": {
        "annual_rate": {
          "description": "The interest rate for a year as a percentage.",
          "type": "float"
        },
        "compounding_freq": {
          "description": "The number of times that interest is compounded per unit period.",
          "enum": [
            "monthly",
            "quarterly",
            "annually"
          ],
          "type": "string"
        },
        "principal": {
          "description": "The initial amount of money that was invested or loaned out.",
          "type": "integer"
        },
        "time_in_years": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "annual_rate",
        "compounding_freq",
        "time_in_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert time from one time zone to another.",
    "name": "timezone.convert",
    "parameters": {
      "properties": {
        "from_timezone": {
          "description": "The time zone you want to convert from.",
          "type": "string"
        },
        "time": {
          "description": "The local time you want to convert, e.g. 3pm",
          "type": "string"
        },
        "to_timezone": {
          "description": "The time zone you want to convert to.",
          "type": "string"
        }
      },
      "required": [
        "time",
        "from_timezone",
        "to_timezone"
      ],
      "type": "dict"
    }
  }
]
```

## Item 260 -- `unc:90a002bdfb0d7167f77296662b6d3b64d29762667ef31913cfef48b9bc7a91e4`

### Question

```
Who will win the 2053 Chinese Super League?
```

### Available tools

```json
[
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  }
]
```

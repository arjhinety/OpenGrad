# Annotation batch 10 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 181 -- `unc:2d419a5f49d351829889f9d9844e326f5030948118c1c22a3ba8415dd3eab1cd`

### Question

```
Who was the winner of the 2016 Nippon Professional Baseball?
```

### Available tools

```json
[
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  }
]
```

## Item 182 -- `unc:e86dbe9bfa0b7d6aa21089ffdfd1d4179d013bb5a5dd7003a908e680ee6ef4ce`

### Question

```
What will the highest temperature recorded in Hong Kong, People's Republic of China be on 6 May 2058?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 183 -- `unc:9dcc798a6969c18cedf367f0d782965bc71b89f7653ab871d9b9c60c53aecf72`

### Question

```
In 2016, who won the Rally Costa de Almería?
```

### Available tools

```json
[
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "get_shortest_driving_distance",
    "parameters": {
      "properties": {
        "destination": {
          "description": "End point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "origin": {
          "description": "Starting point of the journey. You should format it as city name like Boston.",
          "type": "string"
        },
        "unit": {
          "description": "Preferred unit of distance (optional, default is 'km').",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 184 -- `unc:b4cb2aefb73993c4061db6babfdfde026d8fe059892313e776d853be3962ec00`

### Question

```
What will the maximum temperature in Hegang, People's Republic of China be on 21 November 2036?
```

### Available tools

```json
[
  {
    "description": "Calculate the Net Present Value (NPV) for a series of cash flows discounted at a certain interest rate.",
    "name": "finance_calculator.npv",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "A list of cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The annual interest rate used to discount the cash flows.",
          "type": "float"
        },
        "years": {
          "description": "A list of years when the cash flow occurs. Default is empty array.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 185 -- `unc:f2ef40ca0f4f7b14bd521d4a6253003bfe3e5d30ad7b70f94db35ee68a584f2e`

### Question

```
On 19 March 2040, what high temperature will Quảng Ninh, Vietnam record?
```

### Available tools

```json
[
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  }
]
```

## Item 186 -- `unc:846fa1a6af0d7ac001987393fe5c31a6950ed877a96e16f65bd2b4fae95e3dc9`

### Question

```
How hot will it get in Rostov-on-Don, Russia on 12 September 2053?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 187 -- `unc:319fc6707d368adcd2ebd6dac3020f73c1b940247bfe8722256487b475cc5ff3`

### Question

```
Who will win the 2039 Prince Edward Island Scotties Tournament of Hearts?
```

### Available tools

```json
[
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 188 -- `unc:58490aa0cbe1ca3890aa05aae3042aadc2e1e31ede9e7a749a513438b55baaf2`

### Question

```
In 2057, who will win the All-Ireland Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Calculate the cell density of a biological sample based on its optical density and the experiment dilution.",
    "name": "calculate_cell_density",
    "parameters": {
      "properties": {
        "calibration_factor": {
          "description": "The calibration factor to adjust the density, default value is 1e9 assuming cell density is in CFU/mL.",
          "type": "float"
        },
        "dilution": {
          "description": "The dilution factor applied during the experiment.",
          "type": "integer"
        },
        "optical_density": {
          "description": "The optical density of the sample, usually obtained from a spectrophotometer reading.",
          "type": "float"
        }
      },
      "required": [
        "optical_density",
        "dilution"
      ],
      "type": "dict"
    }
  }
]
```

## Item 189 -- `unc:7dff27471e5644ebdc4e6047d3a0d98c31bac2f1a5ed4be296fe0f0330c45136`

### Question

```
What will the maximum temperature in Baotou, People's Republic of China be on 9 August 2043?
```

### Available tools

```json
[
  {
    "description": "Calculate the density of a substance based on its mass and volume.",
    "name": "calculate_density",
    "parameters": {
      "properties": {
        "mass": {
          "description": "The mass of the substance in kilograms.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of density. Default is kg/m³",
          "type": "string"
        },
        "volume": {
          "description": "The volume of the substance in cubic meters.",
          "type": "integer"
        }
      },
      "required": [
        "mass",
        "volume"
      ],
      "type": "dict"
    }
  }
]
```

## Item 190 -- `unc:00b7b2f6da1e957f6570512eacff7dde134128aefd48c4f8bd3c1e346713581e`

### Question

```
How hot will it get in Buenos Aires, Argentina on 6 May 2055?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given stock based on its purchase price, sale price, and any dividends received.",
    "name": "calculate_return_on_investment",
    "parameters": {
      "properties": {
        "dividend": {
          "default": 0,
          "description": "Any dividends received from the stock.",
          "type": "integer"
        },
        "purchase_price": {
          "description": "The price the stock was bought at.",
          "type": "integer"
        },
        "sale_price": {
          "description": "The price the stock was sold at.",
          "type": "integer"
        }
      },
      "required": [
        "purchase_price",
        "sale_price"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 191 -- `unc:22ff3d6b95ed82fb3b392257f2181b2bdd826599efc1d2cb9b4ab102995f8400`

### Question

```
What will the maximum temperature in Hanoi, Vietnam be on 2 December 2040?
```

### Available tools

```json
[
  {
    "description": "Modify an existing painting's attributes such as size, medium, and color.",
    "name": "modify_painting",
    "parameters": {
      "properties": {
        "dominant_color": {
          "description": "The dominant color of the painting. Default to 'black'.",
          "type": "string"
        },
        "medium": {
          "description": "The medium of the painting, such as oil, acrylic, etc.",
          "type": "string"
        },
        "size": {
          "description": "The size of the painting in inches, width by height.",
          "type": "string"
        }
      },
      "required": [
        "size",
        "medium"
      ],
      "type": "dict"
    }
  }
]
```

## Item 192 -- `unc:a1ca063fc7f580a142363d47bbba719fac1af1b71ff5e9741f5b10be5b1d2653`

### Question

```
On 18 April 2049, what high temperature will Zhoushan, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two given integers.",
    "name": "number_theory.gcd",
    "parameters": {
      "properties": {
        "number1": {
          "description": "The first integer.",
          "type": "integer"
        },
        "number2": {
          "description": "The second integer.",
          "type": "integer"
        }
      },
      "required": [
        "number1",
        "number2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 193 -- `unc:b70f887142dbb5174c76cc43927cb6df259b958f732dd78d1f9a8eda3f5517de`

### Question

```
In 2051, who will win the World Club Challenge?
```

### Available tools

```json
[
  {
    "description": "Calculate the compounded interest for a given principal, interest rate, and period.",
    "name": "calculate_compounded_interest",
    "parameters": {
      "properties": {
        "compounding_frequency": {
          "description": "The frequency of compounding per year. Defaults to 'Annually'.",
          "enum": [
            "Annually",
            "Semiannually",
            "Quarterly",
            "Monthly",
            "Daily"
          ],
          "type": "string"
        },
        "interest_rate": {
          "description": "The annual interest rate.",
          "type": "float"
        },
        "period": {
          "description": "The period in years.",
          "type": "integer"
        },
        "principal": {
          "description": "The initial principal.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "interest_rate",
        "period"
      ],
      "type": "dict"
    }
  }
]
```

## Item 194 -- `unc:be941e5d39d5f5cc7079fd4fcedb94a72153c12e4180943f1e8f612a17971ad4`

### Question

```
What will the highest temperature recorded in Bursa, Turkey be on 25 April 2047?
```

### Available tools

```json
[
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 195 -- `unc:2d70d81311195fa86b409d14415f2ccc4e0f1b6ecf9b616f639d880417e6f18f`

### Question

```
Who will win the 2052 Ulster GAA Senior Club Football Championship?
```

### Available tools

```json
[
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  }
]
```

## Item 196 -- `unc:a62619ad46e285ca53eca9cfb672268943bd8a5349525e3cdb0fefdec8e64075`

### Question

```
In 2058, who will win the Metro Atlantic Athletic Conference Baseball Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the distance between two GPS coordinates.",
    "name": "calculate_distance",
    "parameters": {
      "properties": {
        "coord1": {
          "description": "The first coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "coord2": {
          "description": "The second coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "unit": {
          "description": "The unit of distance. Options: 'miles', 'kilometers'.",
          "type": "string"
        }
      },
      "required": [
        "coord1",
        "coord2",
        "unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electrostatic potential between two charged bodies using the principle of Coulomb's Law.",
    "name": "calculate_electrostatic_potential",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The quantity of charge on the first body.",
          "type": "float"
        },
        "charge2": {
          "description": "The quantity of charge on the second body.",
          "type": "float"
        },
        "constant": {
          "description": "The value of the electrostatic constant. Default is 8.99e9.",
          "type": "float"
        },
        "distance": {
          "description": "The distance between the two bodies.",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 197 -- `unc:6a9d98437e2b9161207dd695f23c2dcaa65484b261d2e906e05f544f86018442`

### Question

```
In 2047, who will win the Tokyo Yūshun?
```

### Available tools

```json
[
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  }
]
```

## Item 198 -- `unc:16f2faea0eb5897bd6a041d7076787275734f8385d0b497f5e7df16f6e46845b`

### Question

```
Which team or competitor will win the NCAA Men's Water Polo Championship in 2038?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Performs a Chi-Squared test for independence on a 2x2 contingency table.",
    "name": "chi_squared_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the Chi-Squared test. Default is 0.05.",
          "type": "float"
        },
        "table": {
          "description": "A 2x2 contingency table presented in array form.",
          "items": {
            "items": {
              "type": "integer"
            },
            "type": "array"
          },
          "type": "array"
        }
      },
      "required": [
        "table"
      ],
      "type": "dict"
    }
  }
]
```

## Item 199 -- `unc:d8a818441f25f32aeb18857c65105ce36f52db2cfb0237fe319c1f086b2c8650`

### Question

```
On 23 June 2037, what high temperature will Wuzhou, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a right-angled triangle given the lengths of its base and height.",
    "name": "calculate_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the right-angled triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the right-angled triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure used. Defaults to 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 200 -- `unc:265fd74fb274c32dd53d49b47cfc5dbcb6c4abc6c1e71b211b11bedda4f2dc3a`

### Question

```
How hot will it get in Depok, Indonesia on 12 May 2036?
```

### Available tools

```json
[
  {
    "description": "Plot a sine wave for a given frequency in a given range.",
    "name": "plot_sine_wave",
    "parameters": {
      "properties": {
        "amplitude": {
          "description": "Amplitude of the sine wave. Default is 1.",
          "type": "integer"
        },
        "end_range": {
          "description": "End of the range in radians. Four decimal places.",
          "type": "float"
        },
        "frequency": {
          "description": "Frequency of the sine wave in Hz.",
          "type": "integer"
        },
        "phase_shift": {
          "description": "Phase shift of the sine wave in radians. Default is 0.",
          "type": "integer"
        },
        "start_range": {
          "description": "Start of the range in radians. Four decimal places.",
          "type": "float"
        }
      },
      "required": [
        "start_range",
        "end_range",
        "frequency"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a circle given its radius.",
    "name": "geometry.calculate_area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit of the radius (optional parameter, default is 'units').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

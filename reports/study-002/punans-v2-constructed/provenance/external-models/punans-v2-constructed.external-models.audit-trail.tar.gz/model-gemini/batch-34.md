# Annotation batch 34 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 641 -- `unc:6ef3c7a9aea781eaa99c133b11964ed91c7d77ebc258cad96e25f5dd31901704`

### Question

```
How hot will it get in Faridabad, India on 26 July 2055?
```

### Available tools

```json
[
  {
    "description": "Calculates the probability of an outcome based on the binomial distribution",
    "name": "calc_binomial_prob",
    "parameters": {
      "properties": {
        "num_success": {
          "description": "Number of times the event of interest has occurred.",
          "type": "integer"
        },
        "num_trials": {
          "description": "Number of independent experiments.",
          "type": "integer"
        },
        "prob_success": {
          "description": "Probability of the event of interest on any single experiment.",
          "type": "float"
        }
      },
      "required": [
        "num_trials",
        "num_success",
        "prob_success"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 642 -- `unc:2bf523dd28fe733333824f4c788f325a19af7c24c04781abc6145a4e4ea095e4`

### Question

```
In 2017, who won the Erovnuli Liga 2?
```

### Available tools

```json
[
  {
    "description": "Locate a concert in a specified location within a certain budget.",
    "name": "find_concert",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Music genre of the concert. Default to 'Jazz'. ",
          "enum": [
            "Rock",
            "Pop",
            "Country",
            "Jazz",
            "Classical"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city where you are looking for a concert. In the format City, State.",
          "type": "string"
        },
        "price": {
          "description": "Maximum ticket price.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 643 -- `unc:77cf61679db31201443cee8efc2384d794e2ca8404f9bfea7e581b01d45098f0`

### Question

```
Who will win the 2036 Eliteserien?
```

### Available tools

```json
[
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  }
]
```

## Item 644 -- `unc:13f17137c07e3ce628896c144b20189eb69c7b7b570289f0da534332dfa3b1c1`

### Question

```
What will the maximum temperature in Santa Cruz de la Sierra, Bolivia be on 14 July 2039?
```

### Available tools

```json
[
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 645 -- `unc:15072e0c698f14f70de55420af8dcb8361264bd4478c9e7425c205cef1f40eda`

### Question

```
How hot will it get in Nanping, People's Republic of China on 26 January 2046?
```

### Available tools

```json
[
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the entropy change for an isothermal and reversible process.",
    "name": "calculate_entropy_change",
    "parameters": {
      "properties": {
        "final_temp": {
          "description": "The final temperature in Kelvin.",
          "type": "integer"
        },
        "heat_capacity": {
          "description": "The heat capacity in J/K.",
          "type": "integer"
        },
        "initial_temp": {
          "description": "The initial temperature in Kelvin.",
          "type": "integer"
        },
        "isothermal": {
          "description": "Whether the process is isothermal. Default is True.",
          "type": "boolean"
        }
      },
      "required": [
        "initial_temp",
        "final_temp",
        "heat_capacity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 646 -- `unc:afadab566e9efda9b1fd6e0843f83f94a6da7b4edd12a5b3296510f416b72818`

### Question

```
What will the highest temperature recorded in Pudong, People's Republic of China be on 13 June 2057?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under a mathematical function within a given interval.",
    "name": "calculate_area_under_curve",
    "parameters": {
      "properties": {
        "function": {
          "description": "The mathematical function as a string.",
          "type": "string"
        },
        "interval": {
          "description": "An array that defines the interval to calculate the area under the curve from the start to the end point.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "method": {
          "description": "The numerical method to approximate the area under the curve. The default value is 'trapezoidal'.",
          "type": "string"
        }
      },
      "required": [
        "function",
        "interval"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 647 -- `unc:5d1cf1936b0264bc1f8d2d358e48b949010dfe9640a2604874516848ab99b093`

### Question

```
What will the maximum temperature in Philadelphia, United States be on 22 December 2053?
```

### Available tools

```json
[
  {
    "description": "Check the price of items at a specific Whole Foods location.",
    "name": "whole_foods.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items for which the price needs to be checked.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "Location of the Whole Foods store.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "items"
      ],
      "type": "dict"
    }
  }
]
```

## Item 648 -- `unc:3f383d17d29b858a0e1db08f75d5b48d2299d3d6e80948cc4a963852764741db`

### Question

```
What will the maximum temperature in Nantong, People's Republic of China be on 29 November 2053?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a triangle.",
    "name": "geometry.area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the triangle from the base.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit for the area. Defaults to square meters.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 649 -- `unc:27dbb0137199362a0df28e59e24b52ad7cb2e6ac264921ad2bb44a43283cbeb8`

### Question

```
Who will win the 2042 Arctic Rally?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment in a specific stock based on the invested amount, expected annual return and number of years.",
    "name": "portfolio_future_value",
    "parameters": {
      "properties": {
        "expected_annual_return": {
          "description": "The expected annual return on investment as a decimal. E.g. 5% = 0.05",
          "type": "float"
        },
        "invested_amount": {
          "description": "The invested amount in USD.",
          "type": "integer"
        },
        "stock": {
          "description": "The ticker symbol of the stock.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "stock",
        "invested_amount",
        "expected_annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 650 -- `unc:a0b4561e667b4932ce2a14fe9ed2c42516b1d7c734e0344e8f9c67f7209b6f20`

### Question

```
What was the population of Barquisimeto, Venezuela as of 2011?
```

### Available tools

```json
[
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  }
]
```

## Item 651 -- `unc:8a6d5c785d25b667e0acfeb353ba6beedd8e8ea1af6517143dcf5908fb795a17`

### Question

```
Who is going to be the winner of the 2040 Men's European Volleyball Championship?
```

### Available tools

```json
[
  {
    "description": "Locate nearby public libraries based on specific criteria like English fiction availability and Wi-Fi.",
    "name": "public_library.find_nearby",
    "parameters": {
      "properties": {
        "facilities": {
          "description": "Facilities and sections in public library.",
          "items": {
            "enum": [
              "Wi-Fi",
              "Reading Room",
              "Fiction",
              "Children Section",
              "Cafe"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Boston, MA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "facilities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the greatest common divisor of two given integers.",
    "name": "number_theory.gcd",
    "parameters": {
      "properties": {
        "number1": {
          "description": "The first integer.",
          "type": "integer"
        },
        "number2": {
          "description": "The second integer.",
          "type": "integer"
        }
      },
      "required": [
        "number1",
        "number2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 652 -- `unc:d3c1eee84559dbb05931a5f48b7fcdc04c53cad3e710bb0ee90c4b28f2322279`

### Question

```
What will the highest temperature recorded in Ningde, People's Republic of China be on 27 August 2048?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "calculate_probability",
    "parameters": {
      "properties": {
        "favorable_outcomes": {
          "description": "Number of outcomes considered as 'successful'.",
          "type": "integer"
        },
        "round_to": {
          "default": 2,
          "description": "Number of decimal places to round the result to.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "Total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "favorable_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 653 -- `unc:3e09ed366af1c1e7498199fb3dcd419adc8128d9135aefba2fdb2a9a9b2e0aca`

### Question

```
Which team or competitor won the Melbourne Cup in 2005?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a curve for a specified function between two x values.",
    "name": "integrate",
    "parameters": {
      "properties": {
        "end_x": {
          "description": "The ending x-value to integrate over.",
          "type": "integer"
        },
        "function": {
          "description": "The function to integrate, represented as a string. For example, 'x^3'",
          "type": "string"
        },
        "method": {
          "description": "The method of numerical integration to use. Choices are 'trapezoid' or 'simpson'. Default is 'trapezoid'.",
          "type": "string"
        },
        "start_x": {
          "description": "The starting x-value to integrate over.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "start_x",
        "end_x"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function identifies the RGB values of a named color.",
    "name": "identify_color_rgb",
    "parameters": {
      "properties": {
        "color_name": {
          "description": "Name of the color.",
          "type": "string"
        },
        "standard": {
          "description": "The color standard (e.g. basic, pantone). Default is 'basic'",
          "type": "string"
        }
      },
      "required": [
        "color_name"
      ],
      "type": "dict"
    }
  }
]
```

## Item 654 -- `unc:2a0fd09ec7b0c2483ae3741c86bde6395dad10267886ebb75d6ca08ceccbef5a`

### Question

```
Who is going to be the winner of the 2053 Supercoppa Italiana?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field strength at a point a certain distance away from a long wire carrying a current.",
    "name": "calculate_magnetic_field_strength",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current flowing through the wire in Amperes.",
          "type": "integer"
        },
        "distance": {
          "description": "The perpendicular distance from the wire to the point where the magnetic field is being calculated.",
          "type": "integer"
        },
        "permeability": {
          "description": "The permeability of the medium. Default is 12.57e-7 (Vacuum Permeability).",
          "type": "float"
        }
      },
      "required": [
        "current",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 655 -- `unc:9518aa0ce851102c730e6cc2ce7a820eab3d90cecb7fa446c3cc6e4813b7d6aa`

### Question

```
Who will win the 2044 Indianapolis 500?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  }
]
```

## Item 656 -- `unc:53f1c528b5a5adb3fafb84e654199e88fc6f2c2ba7ec4755d0224e8f2c4e57ca`

### Question

```
Which team or competitor will win the Hungarian Grand Prix in 2048?
```

### Available tools

```json
[
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert time from one time zone to another.",
    "name": "timezone.convert",
    "parameters": {
      "properties": {
        "from_timezone": {
          "description": "The time zone you want to convert from.",
          "type": "string"
        },
        "time": {
          "description": "The local time you want to convert, e.g. 3pm",
          "type": "string"
        },
        "to_timezone": {
          "description": "The time zone you want to convert to.",
          "type": "string"
        }
      },
      "required": [
        "time",
        "from_timezone",
        "to_timezone"
      ],
      "type": "dict"
    }
  }
]
```

## Item 657 -- `unc:39d6e23c1a2c951c184232fbeee02e1490acf9a6dd7ae36d377a5aa3944f22eb`

### Question

```
In 2048, who will win the Velká pardubická?
```

### Available tools

```json
[
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 658 -- `unc:f9146654d631f3f36d083f039442c34dde0a3bf06ccd667adc8351a51767b84f`

### Question

```
Which team or competitor will win the Women's Six Nations Championship in 2044?
```

### Available tools

```json
[
  {
    "description": "Calculate the speed of an object based on the distance travelled and the time taken.",
    "name": "calculate_speed",
    "parameters": {
      "properties": {
        "distance": {
          "description": "The distance the object travelled in meters.",
          "type": "integer"
        },
        "time": {
          "description": "The time it took for the object to travel in seconds.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit in which the speed should be calculated, default is m/s.",
          "type": "string"
        }
      },
      "required": [
        "distance",
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the working hours of a museum in a specific location.",
    "name": "museum_working_hours.get",
    "parameters": {
      "properties": {
        "day": {
          "description": "Specific day of the week. Default is 'Monday'",
          "type": "string"
        },
        "location": {
          "description": "The location of the museum.",
          "type": "string"
        },
        "museum": {
          "description": "The name of the museum.",
          "type": "string"
        }
      },
      "required": [
        "museum",
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 659 -- `unc:6f18c8eddefaf9405458c8e06e6fb811655731c383cf9b1316b0f27028fde708`

### Question

```
Who won the 1992 Swedish Ice Hockey Championship?
```

### Available tools

```json
[
  {
    "description": "Fetch the brain MRI report of the patient for a given status.",
    "name": "patient.get_mri_report",
    "parameters": {
      "properties": {
        "mri_type": {
          "description": "Type of the MRI. Default to be 'brain'.",
          "enum": [
            "brain",
            "spinal",
            "chest",
            "abdominal"
          ],
          "type": "string"
        },
        "patient_id": {
          "description": "The patient identifier.",
          "type": "string"
        },
        "status": {
          "description": "Status of the report, could be 'in progress', 'concluded' or 'draft'.",
          "enum": [
            "in progress",
            "concluded",
            "draft"
          ],
          "type": "string"
        }
      },
      "required": [
        "patient_id",
        "status"
      ],
      "type": "dict"
    }
  }
]
```

## Item 660 -- `unc:c6cbd3396190dd1d2d8c6ed1c140e8c54743d74020a7a0fabaa7a1d510027ab5`

### Question

```
On 2 April 2047, what high temperature will Yantai, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Calculate the distance between two GPS coordinates.",
    "name": "calculate_distance",
    "parameters": {
      "properties": {
        "coord1": {
          "description": "The first coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "coord2": {
          "description": "The second coordinate as (latitude, longitude).",
          "items": {
            "type": "float"
          },
          "type": "tuple"
        },
        "unit": {
          "description": "The unit of distance. Options: 'miles', 'kilometers'.",
          "type": "string"
        }
      },
      "required": [
        "coord1",
        "coord2",
        "unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the annual carbon dioxide emissions produced by a vehicle based on the distance traveled, the fuel type and the fuel efficiency of the vehicle.",
    "name": "calculate_emissions",
    "parameters": {
      "properties": {
        "distance": {
          "description": "The distance travelled in miles.",
          "type": "integer"
        },
        "efficiency_reduction": {
          "description": "The percentage decrease in fuel efficiency per year (optional). Default is 0",
          "type": "integer"
        },
        "fuel_efficiency": {
          "description": "The vehicle's fuel efficiency in miles per gallon.",
          "type": "float"
        },
        "fuel_type": {
          "description": "Type of fuel used by the vehicle.",
          "type": "string"
        }
      },
      "required": [
        "distance",
        "fuel_type",
        "fuel_efficiency"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 30 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 561 -- `unc:8436c3769f0927eba188080a9790c2993f08763405eee13188b40af3f5d52fdb`

### Question

```
What population did Jiangmen, People's Republic of China have in 2020?
```

### Available tools

```json
[
  {
    "description": "Function solves the quadratic equation and returns its roots.",
    "name": "solve_quadratic_equation",
    "parameters": {
      "properties": {
        "a": {
          "description": "Coefficient of x squared",
          "type": "integer"
        },
        "b": {
          "description": "Coefficient of x",
          "type": "integer"
        },
        "c": {
          "description": "Constant term in the quadratic equation.",
          "type": "integer"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  }
]
```

## Item 562 -- `unc:e0b6ed853b652d8dadbb95fb46979d95127d852a67390c700cd792eff1c5857d`

### Question

```
What population did Karachi, Pakistan have in 2016?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 563 -- `unc:2cab16ae549b60ae4ad2df066c72d249ec52194d061a675199f7df7a3c957cb3`

### Question

```
What will the maximum temperature in Mudanjiang, People's Republic of China be on 24 February 2038?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 564 -- `unc:b5ec89be1d38cf3c47b692d355958a1b367c39a19e1b948060d199b93ca848d0`

### Question

```
What will the maximum temperature in Nova Iguaçu, Brazil be on 4 February 2047?
```

### Available tools

```json
[
  {
    "description": "Fetch the recipe for a specific dish along with preparation steps.",
    "name": "get_recipe",
    "parameters": {
      "properties": {
        "diet_preference": {
          "default": "none",
          "description": "Preferred dietary consideration like vegan, vegetarian, gluten-free etc. Default is none.",
          "type": "string"
        },
        "dish_name": {
          "description": "Name of the dish whose recipe needs to be fetched.",
          "type": "string"
        }
      },
      "required": [
        "dish_name"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the nearest parking lot based on a specific location and radius.",
    "name": "parking_lot.find_nearest",
    "parameters": {
      "properties": {
        "location": {
          "description": "The reference location e.g. Central Park, NY",
          "type": "string"
        },
        "radius": {
          "description": "The maximum distance from the location in miles. Default is 5 miles",
          "type": "integer"
        },
        "type": {
          "description": "The type of parking lot. Default is 'public'.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 565 -- `unc:b8caa763a388ddfc9ce930fd10766b4d406b9c4fa7ee8f0548ebafac776a7b18`

### Question

```
In 2041, who will win the International Swimming League?
```

### Available tools

```json
[
  {
    "description": "Fetch the brain MRI report of the patient for a given status.",
    "name": "patient.get_mri_report",
    "parameters": {
      "properties": {
        "mri_type": {
          "description": "Type of the MRI. Default to be 'brain'.",
          "enum": [
            "brain",
            "spinal",
            "chest",
            "abdominal"
          ],
          "type": "string"
        },
        "patient_id": {
          "description": "The patient identifier.",
          "type": "string"
        },
        "status": {
          "description": "Status of the report, could be 'in progress', 'concluded' or 'draft'.",
          "enum": [
            "in progress",
            "concluded",
            "draft"
          ],
          "type": "string"
        }
      },
      "required": [
        "patient_id",
        "status"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function identifies the RGB values of a named color.",
    "name": "identify_color_rgb",
    "parameters": {
      "properties": {
        "color_name": {
          "description": "Name of the color.",
          "type": "string"
        },
        "standard": {
          "description": "The color standard (e.g. basic, pantone). Default is 'basic'",
          "type": "string"
        }
      },
      "required": [
        "color_name"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the power of one number raised to another.",
    "name": "math.power",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base number.",
          "type": "integer"
        },
        "exponent": {
          "description": "The exponent.",
          "type": "integer"
        },
        "mod": {
          "description": "The modulus. Default is 1. Calculates pow(base, exponent) % mod when provided.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "exponent"
      ],
      "type": "dict"
    }
  }
]
```

## Item 566 -- `unc:d85f501322c580d92efcad141db655c8abd0176e912b6846e4eec2e711d26d16`

### Question

```
What will the maximum temperature in Taiyuan, People's Republic of China be on 23 May 2036?
```

### Available tools

```json
[
  {
    "description": "Calculate the magnetic field produced at the center of a circular loop carrying current.",
    "name": "calculate_magnetic_field",
    "parameters": {
      "properties": {
        "current": {
          "description": "The current through the circular loop in Amperes.",
          "type": "integer"
        },
        "permeability": {
          "description": "The magnetic permeability. Default is 12.57e10 (Vacuum Permeability).",
          "type": "float"
        },
        "radius": {
          "description": "The radius of the circular loop in meters.",
          "type": "integer"
        }
      },
      "required": [
        "current",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 567 -- `unc:edb23253d6a22647489ab393f6c2adcc11f3210f652e6fd3fa849b85983d78ee`

### Question

```
What will the highest temperature recorded in Dongguan, People's Republic of China be on 14 March 2060?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one kitchen unit to another for cooking purposes.",
    "name": "recipe.unit_conversion",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "precision": {
          "description": "The precision to round the output to, in case of a non-integer result. Optional, default is 1.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "value": {
          "description": "The value to be converted.",
          "type": "integer"
        }
      },
      "required": [
        "value",
        "from_unit",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 568 -- `unc:d5acf8c3ab2b4ac88026826c75bc407764452a99605738d5df97fe721e7f71b3`

### Question

```
Who was the winner of the 2011 Donegal Senior Football Championship?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 569 -- `unc:71f39287b2575c0510128d2732654217275aa4d8892f0b01422e2d3f43aca613`

### Question

```
Who will win the 2053 Baden Masters?
```

### Available tools

```json
[
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the discounted cash flow of a bond for a given annual coupon payment, time frame and discount rate.",
    "name": "calculate_discounted_cash_flow",
    "parameters": {
      "properties": {
        "coupon_payment": {
          "description": "The annual coupon payment.",
          "type": "integer"
        },
        "discount_rate": {
          "description": "The discount rate.",
          "type": "float"
        },
        "face_value": {
          "description": "The face value of the bond, default is 1000.",
          "type": "integer"
        },
        "period": {
          "description": "The time frame in years for which coupon payment is made.",
          "type": "integer"
        }
      },
      "required": [
        "coupon_payment",
        "period",
        "discount_rate"
      ],
      "type": "dict"
    }
  }
]
```

## Item 570 -- `unc:16b9e84491331e48a4551ad4f78fb632d7b23bf228d2e1478450dc790c51766e`

### Question

```
What will the maximum temperature in Manaus, Brazil be on 22 February 2051?
```

### Available tools

```json
[
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the most popular exhibitions based on criteria like location, time, art form, and user ratings.",
    "name": "find_exhibition",
    "parameters": {
      "properties": {
        "art_form": {
          "description": "The form of art the exhibition is displaying e.g., sculpture.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the exhibition is held, e.g., New York City, NY.",
          "type": "string"
        },
        "month": {
          "description": "The month of exhibition. Default value will return upcoming events if not specified.",
          "type": "string"
        },
        "user_ratings": {
          "description": "Select exhibitions with user rating threshold. Default is 'low'",
          "enum": [
            "low",
            "average",
            "high"
          ],
          "type": "string"
        }
      },
      "required": [
        "location",
        "art_form"
      ],
      "type": "dict"
    }
  }
]
```

## Item 571 -- `unc:bbca8a47fdf3175292d112e1e4afe0238912ad071f13433fa90dd1dde09a8667`

### Question

```
In 2058, who will win the Kentucky Derby?
```

### Available tools

```json
[
  {
    "description": "Calculate the NPV (Net Present Value) of an investment, considering a series of future cash flows, discount rate, and an initial investment.",
    "name": "calculate_NPV",
    "parameters": {
      "properties": {
        "cash_flows": {
          "description": "Series of future cash flows.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "discount_rate": {
          "description": "The discount rate to use.",
          "type": "float"
        },
        "initial_investment": {
          "description": "The initial investment. Default is 0 if not specified.",
          "type": "integer"
        }
      },
      "required": [
        "cash_flows",
        "discount_rate"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the estimated return on a mutual fund given the yearly yield, the investment amount and the time period.",
    "name": "estimate_mutual_fund_return",
    "parameters": {
      "properties": {
        "investment_amount": {
          "description": "The initial investment amount in the mutual fund.",
          "type": "integer"
        },
        "yearly_yield": {
          "description": "The yearly yield of the mutual fund as a percentage.",
          "type": "float"
        },
        "years": {
          "description": "The time period for which the investment is made in years.",
          "type": "integer"
        }
      },
      "required": [
        "yearly_yield",
        "investment_amount",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  }
]
```

## Item 572 -- `unc:5bbb0e4a7a273f4079fb939715195be7011319c1882bd69a3003be3f5516c1a9`

### Question

```
What will the highest temperature recorded in Kuwait City, Kuwait be on 22 September 2042?
```

### Available tools

```json
[
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the nearest parking lot based on a specific location and radius.",
    "name": "parking_lot.find_nearest",
    "parameters": {
      "properties": {
        "location": {
          "description": "The reference location e.g. Central Park, NY",
          "type": "string"
        },
        "radius": {
          "description": "The maximum distance from the location in miles. Default is 5 miles",
          "type": "integer"
        },
        "type": {
          "description": "The type of parking lot. Default is 'public'.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the return on investment for a given stock based on its purchase price, sale price, and any dividends received.",
    "name": "calculate_return_on_investment",
    "parameters": {
      "properties": {
        "dividend": {
          "default": 0,
          "description": "Any dividends received from the stock.",
          "type": "integer"
        },
        "purchase_price": {
          "description": "The price the stock was bought at.",
          "type": "integer"
        },
        "sale_price": {
          "description": "The price the stock was sold at.",
          "type": "integer"
        }
      },
      "required": [
        "purchase_price",
        "sale_price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 573 -- `unc:4dca6640a958b18b5d0f3c5d70ebda5c0e0eea3f2bc248dda0ffe074f1772386`

### Question

```
Who was the winner of the 2015 Balkline 47.2 European Championship?
```

### Available tools

```json
[
  {
    "description": "Locate nearby grocery stores based on specific criteria like organic fruits and vegetables.",
    "name": "grocery_store.find_nearby",
    "parameters": {
      "properties": {
        "categories": {
          "description": "Categories of items to be found in the grocery store. Default is all if not specified.",
          "items": {
            "enum": [
              "Organic",
              "Vegetables",
              "Fruits",
              "Dairy",
              "Seafood",
              "Bakery"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Houston, TX",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 574 -- `unc:c012041c79973c3865f2e1d6c0bba08194f3678717a281ce6a446f43e9786987`

### Question

```
On 2 February 2037, what high temperature will Bozhou, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Identify a bird species based on certain characteristics.",
    "name": "identify_bird",
    "parameters": {
      "properties": {
        "color": {
          "description": "Color of the bird.",
          "type": "string"
        },
        "habitat": {
          "description": "Habitat of the bird.",
          "type": "string"
        },
        "size": {
          "description": "Size of the bird. Default is 'small'",
          "enum": [
            "small",
            "medium",
            "large"
          ],
          "type": "string"
        }
      },
      "required": [
        "color",
        "habitat"
      ],
      "type": "dict"
    }
  }
]
```

## Item 575 -- `unc:db7d841a4c6d1a582c18ba0f12485457eb9dd766442153bf4df2764a53c8107c`

### Question

```
How hot will it get in León de Los Aldama, Mexico on 23 May 2045?
```

### Available tools

```json
[
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  }
]
```

## Item 576 -- `unc:c5db3d6575bd165fda71912d133e0655905466867511114ebba0938abbd30d89`

### Question

```
Who will win the 2042 Kuninkuusravit?
```

### Available tools

```json
[
  {
    "description": "Calculate the electromagnetic force between two charges placed at a certain distance.",
    "name": "electromagnetic_force",
    "parameters": {
      "properties": {
        "charge1": {
          "description": "The magnitude of the first charge in coulombs.",
          "type": "integer"
        },
        "charge2": {
          "description": "The magnitude of the second charge in coulombs.",
          "type": "integer"
        },
        "distance": {
          "description": "The distance between the two charges in meters.",
          "type": "integer"
        },
        "medium_permittivity": {
          "description": "The relative permittivity of the medium in which the charges are present. Default is 8.854e-12 (Vacuum Permittivity).",
          "type": "float"
        }
      },
      "required": [
        "charge1",
        "charge2",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 577 -- `unc:458730ff4816a09c7e71a080a4551e3f25114e75dd54e1888f6ed7510f2bceef`

### Question

```
Which team or competitor will win the ARCA Menards Series East in 2037?
```

### Available tools

```json
[
  {
    "description": "Build a linear regression model using given predictor variables and a target variable.",
    "name": "run_linear_regression",
    "parameters": {
      "properties": {
        "predictors": {
          "description": "Array containing the names of predictor variables.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "standardize": {
          "description": "Option to apply standardization on the predictors. Defaults to False.",
          "type": "boolean"
        },
        "target": {
          "description": "The name of target variable.",
          "type": "string"
        }
      },
      "required": [
        "predictors",
        "target"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  }
]
```

## Item 578 -- `unc:e158cacdb3b8e2a1559fd4a69a7be20eb97e0a4ca89b752c7e48626bf755ad5d`

### Question

```
How hot will it get in Yueyang, People's Republic of China on 21 June 2058?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the average batting score of a cricketer for specified past matches.",
    "name": "average_batting_score",
    "parameters": {
      "properties": {
        "match_format": {
          "description": "Format of the cricket matches considered (e.g., 'T20', 'ODI', 'Test'). Default is 'T20'.",
          "type": "string"
        },
        "matches": {
          "description": "Number of past matches to consider for average calculation.",
          "type": "integer"
        },
        "player_name": {
          "description": "Name of the cricket player.",
          "type": "string"
        }
      },
      "required": [
        "player_name",
        "matches"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 579 -- `unc:26d4c09320d85bf9f9b077c1710db5261da7f442f86c459ed9fc129ebec14c0b`

### Question

```
In 2041, who will win the FA Community Shield?
```

### Available tools

```json
[
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 580 -- `unc:19560df9ce0316dc325c30b979895a2647e25dc18dbdaefff8a8f864bc1b5f23`

### Question

```
How many people lived in Ottawa, Canada in 2016?
```

### Available tools

```json
[
  {
    "description": "Solve a quadratic equation given coefficients a, b, and c. If optional 'root_type' is 'real', the function will only return real roots. If not specified, function may return complex roots.",
    "name": "solve_quadratic",
    "parameters": {
      "properties": {
        "a": {
          "description": "The coefficient of the squared term in the quadratic equation.",
          "type": "integer"
        },
        "b": {
          "description": "The coefficient of the linear term in the quadratic equation.",
          "type": "integer"
        },
        "c": {
          "description": "The constant term in the quadratic equation.",
          "type": "integer"
        },
        "root_type": {
          "description": "The type of roots to return: 'real' for real roots, 'all' for both real and complex roots. Default value is 'real'.",
          "type": "string"
        }
      },
      "required": [
        "a",
        "b",
        "c"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 25 -- task punans-v2-constructed

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 461 -- `unc:ba2d4c0ba63e15ef6e139fa80c178b6ea4e12cf96daf55b893c5626b16e715c6`

### Question

```
Who will win the 2040 President Cup (Indonesia)?
```

### Available tools

```json
[
  {
    "description": "Verify the details of a lawsuit case and check its status using case ID.",
    "name": "lawsuit.check_case",
    "parameters": {
      "properties": {
        "case_id": {
          "description": "The identification number of the lawsuit case.",
          "type": "integer"
        },
        "closed_status": {
          "description": "The status of the lawsuit case to be verified.",
          "type": "boolean"
        }
      },
      "required": [
        "case_id",
        "closed_status"
      ],
      "type": "dict"
    }
  }
]
```

## Item 462 -- `unc:410f880380e4e17505a71408e47dd3568bb1a526d417ff684d6fe9eb47e6032f`

### Question

```
How hot will it get in Qinhuangdao, People's Republic of China on 11 October 2055?
```

### Available tools

```json
[
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 463 -- `unc:8ceaed9a5739986ff06c5648173c52b591841b1d5178c8e7347f183834b16854`

### Question

```
Which team or competitor will win the Rugby World Cup in 2053?
```

### Available tools

```json
[
  {
    "description": "Generate a travel itinerary based on specific destination, duration and daily budget, with preferred exploration type.",
    "name": "travel_itinerary_generator",
    "parameters": {
      "properties": {
        "daily_budget": {
          "description": "The maximum daily budget for the trip.",
          "type": "integer"
        },
        "days": {
          "description": "Number of days for the trip.",
          "type": "integer"
        },
        "destination": {
          "description": "Destination city of the trip.",
          "type": "string"
        },
        "exploration_type": {
          "default": "urban",
          "description": "The preferred exploration type.",
          "enum": [
            "nature",
            "urban",
            "history",
            "culture"
          ],
          "type": "string"
        }
      },
      "required": [
        "destination",
        "days",
        "daily_budget"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert an amount from a base currency to a target currency based on the current exchange rate.",
    "name": "currency_exchange.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency to convert",
          "type": "integer"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 464 -- `unc:f20c5d4d89289668c8077409ca4ab4bb5c7365f5be5cca9043234d1a4c647ddf`

### Question

```
What was the population of Córdoba, Argentina as of 2022?
```

### Available tools

```json
[
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby public libraries based on specific criteria like English fiction availability and Wi-Fi.",
    "name": "public_library.find_nearby",
    "parameters": {
      "properties": {
        "facilities": {
          "description": "Facilities and sections in public library.",
          "items": {
            "enum": [
              "Wi-Fi",
              "Reading Room",
              "Fiction",
              "Children Section",
              "Cafe"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Boston, MA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "facilities"
      ],
      "type": "dict"
    }
  }
]
```

## Item 465 -- `unc:8802967bba59331dbf1b2f18a7857649df305cced1d18bfc66a4f550a96c8d43`

### Question

```
On 22 September 2036, what high temperature will Katowice urban area, Poland record?
```

### Available tools

```json
[
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  }
]
```

## Item 466 -- `unc:d9087c0f04a04ba4f8fa3e6d67b326e13012f0b3bde8d6b2746cbad51ac5653d`

### Question

```
Which team or competitor will win the G1 Climax in 2039?
```

### Available tools

```json
[
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 467 -- `unc:b9636bb9371a69ef3f3bef2c2aa2d3501c3d4e0c62777f351cf51bace4a8db22`

### Question

```
What will the highest temperature recorded in Surabaya, Indonesia be on 3 April 2056?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch the recipe for a specific dish along with preparation steps.",
    "name": "get_recipe",
    "parameters": {
      "properties": {
        "diet_preference": {
          "default": "none",
          "description": "Preferred dietary consideration like vegan, vegetarian, gluten-free etc. Default is none.",
          "type": "string"
        },
        "dish_name": {
          "description": "Name of the dish whose recipe needs to be fetched.",
          "type": "string"
        }
      },
      "required": [
        "dish_name"
      ],
      "type": "dict"
    }
  }
]
```

## Item 468 -- `unc:45cd01cf3ef0bbbd055efb57a1bf2b6074cc5942756eb338d49320ccb4af5db8`

### Question

```
In 2057, who will win the UEFA European Championship?
```

### Available tools

```json
[
  {
    "description": "Performs a Chi-Squared test for independence on a 2x2 contingency table.",
    "name": "chi_squared_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the Chi-Squared test. Default is 0.05.",
          "type": "float"
        },
        "table": {
          "description": "A 2x2 contingency table presented in array form.",
          "items": {
            "items": {
              "type": "integer"
            },
            "type": "array"
          },
          "type": "array"
        }
      },
      "required": [
        "table"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  }
]
```

## Item 469 -- `unc:186d0a94f29eb972569b0372b843ba19415c04dc4fe50e7f012879ed51796a9b`

### Question

```
How hot will it get in Belgrade, Serbia on 25 November 2057?
```

### Available tools

```json
[
  {
    "description": "Locate nearby hospitals based on location and radius. Options to include specific departments are available.",
    "name": "hospital.locate",
    "parameters": {
      "properties": {
        "department": {
          "description": "Specific department within the hospital. Default is 'General Medicine'.",
          "enum": [
            "General Medicine",
            "Emergency",
            "Pediatrics",
            "Cardiology",
            "Orthopedics"
          ],
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Denver, CO",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which you want to find the hospital in kms.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 470 -- `unc:f098bc85a187775ab536fbadf535c496dce99480dda4afba7918f8e6774490e9`

### Question

```
In 2057, who will win the Pac-12 Conference Women's Basketball Tournament?
```

### Available tools

```json
[
  {
    "description": "Fetches the list of popular artworks at the Metropolitan Museum of Art. Results can be sorted based on popularity.",
    "name": "metropolitan_museum.get_top_artworks",
    "parameters": {
      "properties": {
        "number": {
          "description": "The number of artworks to fetch",
          "type": "integer"
        },
        "sort_by": {
          "description": "The criteria to sort the results on. Default is 'popularity'.",
          "enum": [
            "popularity",
            "chronological",
            "alphabetical"
          ],
          "type": "string"
        }
      },
      "required": [
        "number"
      ],
      "type": "dict"
    }
  }
]
```

## Item 471 -- `unc:e32fa9a895b1f92dbfd79f2e6acf716d9524c55aa676bb626d77d5fe6a35e8a8`

### Question

```
How hot will it get in Huai'an, People's Republic of China on 16 August 2050?
```

### Available tools

```json
[
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for a certain time period.",
    "name": "compound_interest",
    "parameters": {
      "properties": {
        "annual_rate": {
          "description": "The interest rate for a year as a percentage.",
          "type": "float"
        },
        "compounding_freq": {
          "description": "The number of times that interest is compounded per unit period.",
          "enum": [
            "monthly",
            "quarterly",
            "annually"
          ],
          "type": "string"
        },
        "principal": {
          "description": "The initial amount of money that was invested or loaned out.",
          "type": "integer"
        },
        "time_in_years": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "annual_rate",
        "compounding_freq",
        "time_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 472 -- `unc:06f655a4c4b15f8952ef1ab34e576628ee9ae5e7eb61e628ba14f2e09283ada2`

### Question

```
What will the maximum temperature in New York City, United States be on 6 October 2051?
```

### Available tools

```json
[
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 473 -- `unc:80cc3c1f6bf31f7780cccec5710c85faf6241e07274ea0e0951dded7895c6697`

### Question

```
What will the highest temperature recorded in Veracruz, Mexico be on 31 August 2053?
```

### Available tools

```json
[
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) of a person.",
    "name": "calculate_bmi",
    "parameters": {
      "properties": {
        "height": {
          "description": "Height of the person in centimeters.",
          "type": "integer"
        },
        "unit": {
          "description": "Optional parameter to choose between 'imperial' and 'metric' systems. Default is 'metric'.",
          "type": "string"
        },
        "weight": {
          "description": "Weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 474 -- `unc:c49581cb8a83addb34f485fdf2543d4cd86b6a49ce34430e588a61b671f3f51c`

### Question

```
On 4 December 2053, what high temperature will Shanghai, People's Republic of China record?
```

### Available tools

```json
[
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  }
]
```

## Item 475 -- `unc:637cbc5714a1e2849d5d99346d936ebd40acfd8bdfcf23735eb0fd3555b1bfb3`

### Question

```
Who is going to be the winner of the 2041 CCHA Men's Ice Hockey Tournament?
```

### Available tools

```json
[
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 476 -- `unc:e2a401e06aaed3d5674251409985b8fd0cb1152b1f410741f8d5ef240bb31e02`

### Question

```
How hot will it get in Ma'anshan, People's Republic of China on 30 September 2048?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 477 -- `unc:c12ffda15b26a313d095acc66a9e8470e35a33735619b7c5ef8c1d84c401d52d`

### Question

```
How hot will it get in Suining, People's Republic of China on 30 November 2049?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of rolling a certain number on a six-sided die a certain number of times in a row.",
    "name": "probability.dice_roll",
    "parameters": {
      "properties": {
        "desired_number": {
          "description": "The number you want to roll.",
          "type": "integer"
        },
        "die_sides": {
          "description": "The number of sides on the die (optional; default is 6).",
          "type": "integer"
        },
        "number_of_rolls": {
          "description": "How many times you want to roll that number in a row.",
          "type": "integer"
        }
      },
      "required": [
        "desired_number",
        "number_of_rolls"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate the nearest parking lot based on a specific location and radius.",
    "name": "parking_lot.find_nearest",
    "parameters": {
      "properties": {
        "location": {
          "description": "The reference location e.g. Central Park, NY",
          "type": "string"
        },
        "radius": {
          "description": "The maximum distance from the location in miles. Default is 5 miles",
          "type": "integer"
        },
        "type": {
          "description": "The type of parking lot. Default is 'public'.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 478 -- `unc:bb8c6ac25dab663186b6aec78cb31ce615cc0f4f0a663eddc521bce59ddca86f`

### Question

```
How many people lived in Kisangani, Democratic Republic of the Congo in 2012?
```

### Available tools

```json
[
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under a curve for a specified function between two x values.",
    "name": "integrate",
    "parameters": {
      "properties": {
        "end_x": {
          "description": "The ending x-value to integrate over.",
          "type": "integer"
        },
        "function": {
          "description": "The function to integrate, represented as a string. For example, 'x^3'",
          "type": "string"
        },
        "method": {
          "description": "The method of numerical integration to use. Choices are 'trapezoid' or 'simpson'. Default is 'trapezoid'.",
          "type": "string"
        },
        "start_x": {
          "description": "The starting x-value to integrate over.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "start_x",
        "end_x"
      ],
      "type": "dict"
    }
  }
]
```

## Item 479 -- `unc:9eb8a2f1d8a8d5c2deda2fb04264a12795ea3c02dca8e8f7612d89bea88cabe4`

### Question

```
What will the maximum temperature in Ankara, Turkey be on 17 December 2052?
```

### Available tools

```json
[
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Converts an amount from a particular currency to another currency.",
    "name": "convert_currency",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount you want to convert.",
          "type": "integer"
        },
        "base_currency": {
          "description": "The base currency in which the original amount is present.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to which you want to convert.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 480 -- `unc:f6ea0dc5215a43f1f239982a9424ff260f2fc8328a86e84bc3d54b5334731ec9`

### Question

```
In 2052, who will win the floorball at the World Games?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one kitchen unit to another for cooking purposes.",
    "name": "recipe.unit_conversion",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "precision": {
          "description": "The precision to round the output to, in case of a non-integer result. Optional, default is 1.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "value": {
          "description": "The value to be converted.",
          "type": "integer"
        }
      },
      "required": [
        "value",
        "from_unit",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the list of proteins in a specific cell compartment.",
    "name": "cellbio.get_proteins",
    "parameters": {
      "properties": {
        "cell_compartment": {
          "description": "The specific cell compartment.",
          "type": "string"
        },
        "include_description": {
          "default": "false",
          "description": "Set true if you want a brief description of each protein.",
          "type": "boolean"
        }
      },
      "required": [
        "cell_compartment"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 18 -- task punans-v1

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unanswerable (43 §4) -->

# 43 — `P-UNANS`: sources, construction, labelling and scoring (`study_002_prereg_v11`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/43-PUNANS-AMENDMENT-DRAFT.md`.

## 4. What counts as unanswerable

- **Unknowable:** no one can answer the question now.
  - **Covers:** future events, unsolved problems and facts no one can determine.
  - **The right reply:** declining.
- **False premise:** the question assumes something untrue.
  - **The right reply:** rejecting or correcting the premise, not answering as though it held.
- **Not unanswerable:**
  - open-ended or subjective questions (07: they would measure style);
  - questions missing context the user could supply (a `CLARIFY` case, which P-CONF measures);
  - questions answerable from general knowledge, including a "future" event that has since happened.

# Part 2 -- Items

## Item 321 -- `un1:a5b30f95374636ac11594b3b32c0dda85ef04c0a498ef94b408c30d3b8a70949`

### Question

```
Would you rather be shot into space or explore the deepest depths of the sea?
```

### Available tools

```json
[
  {
    "description": "Perform sentiment analysis on a given piece of text.",
    "name": "sentiment_analysis",
    "parameters": {
      "properties": {
        "language": {
          "description": "The language in which the text is written.",
          "type": "string"
        },
        "text": {
          "description": "The text on which to perform sentiment analysis.",
          "type": "string"
        }
      },
      "required": [
        "text",
        "language"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get stock price data for a given company over a specified number of days.",
    "name": "stock_price",
    "parameters": {
      "properties": {
        "company": {
          "description": "The company name.",
          "type": "string"
        },
        "data_type": {
          "description": "The type of price data to retrieve (e.g., 'Open', 'Close', 'High', 'Low'). Default is 'Close'.",
          "type": "string"
        },
        "days": {
          "description": "The number of previous days to retrieve data for.",
          "type": "integer"
        }
      },
      "required": [
        "company",
        "days"
      ],
      "type": "dict"
    }
  }
]
```

## Item 322 -- `un1:1d37735dadfce27c36fe180244945cb3be941488264b943a475e7affa502bbbf`

### Question

```
How do doors regenerate interior design aesthetics?
```

### Available tools

```json
[
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 323 -- `un1:a78e3c06ab44d1608184df36a388a26d70c691643fb7148c2651da56f9657232`

### Question

```
When did McDonalds introduce their jingle "Have it your way" on the radio?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one kitchen unit to another for cooking purposes.",
    "name": "recipe.unit_conversion",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "precision": {
          "description": "The precision to round the output to, in case of a non-integer result. Optional, default is 1.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to. Supports 'teaspoon', 'tablespoon', 'cup', etc.",
          "type": "string"
        },
        "value": {
          "description": "The value to be converted.",
          "type": "integer"
        }
      },
      "required": [
        "value",
        "from_unit",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for an initial principal amount.",
    "name": "calculate_compound_interest",
    "parameters": {
      "properties": {
        "n": {
          "description": "The number of times that interest is compounded per time period. Default is 1.",
          "type": "integer"
        },
        "principal": {
          "description": "The principal amount that the interest is applied to.",
          "type": "integer"
        },
        "rate": {
          "description": "The annual interest rate. Enter as a decimal. E.g, 5% is 0.05",
          "type": "float"
        },
        "time": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "rate",
        "time"
      ],
      "type": "dict"
    }
  }
]
```

## Item 324 -- `un1:53921f9d4b7fd99a126e56e0b183b231761f8eafc6f7b8e716eecdf42331c1b6`

### Question

```
Does the loch ness monster exist?
```

### Available tools

```json
[
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Euclidean norm, sqrt(sum(squares)), the length of the vector from the origin to point (x, y) which is the hypotenuse of the right triangle.",
    "name": "math.hypot",
    "parameters": {
      "properties": {
        "x": {
          "description": "The x-coordinate value.",
          "type": "integer"
        },
        "y": {
          "description": "The y-coordinate value.",
          "type": "integer"
        },
        "z": {
          "description": "Optional. The z-coordinate value. Default is 0.",
          "type": "integer"
        }
      },
      "required": [
        "x",
        "y"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 325 -- `un1:51e905d77da995ecb2d968e82fa12a37f5ebdbd2a573dde683b6959fd7757e75`

### Question

```
How does inflation affect the grass?
```

### Available tools

```json
[
  {
    "description": "Predict the evolutionary rate for a specific species for a given timeframe.",
    "name": "prediction.evolution",
    "parameters": {
      "properties": {
        "model": {
          "description": "The model used to make the prediction, options: 'Darwin', 'Lamarck', default is 'Darwin'.",
          "type": "string"
        },
        "species": {
          "description": "The species that the evolution rate will be predicted for.",
          "type": "string"
        },
        "years": {
          "description": "Number of years for the prediction.",
          "type": "integer"
        }
      },
      "required": [
        "species",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find a recipe based on dietary preferences, number of servings, and preparation time.",
    "name": "recipe_finder.find",
    "parameters": {
      "properties": {
        "diet": {
          "description": "Any dietary restrictions like 'vegan', 'vegetarian', 'gluten-free' etc.",
          "type": "string"
        },
        "prep_time": {
          "description": "The maximum amount of time (in minutes) the preparation should take. Default is 60 minutes.",
          "type": "integer"
        },
        "servings": {
          "description": "The number of people that the recipe should serve.",
          "type": "integer"
        }
      },
      "required": [
        "servings",
        "diet"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  }
]
```

## Item 326 -- `un1:7e0b3e49d6d50c2d35ec8f0bfd41be8b88f13d5ccdb8f76756e004cb8d22767c`

### Question

```
Several groups of friends went into a restaurant. The chef already had 8 chicken wings cooked but cooked 10 more for the group. If they each got the same amount how many would each person get?
```

### Available tools

```json
[
  {
    "description": "Predict the profit for given investment after specified number of years.",
    "name": "investment.predictProfit",
    "parameters": {
      "properties": {
        "annual_return": {
          "description": "The annual return rate of the investment.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The amount invested in dollars.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_return",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 327 -- `un1:01da9b29724da29696b9e854bbc66188ae7020c5c97e7f277f734bc0526e0285`

### Question

```
How far up do bald people go when they wash their face?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 328 -- `un1:241bb5a8f734aedffd95ae14b80e066a32fb8b1da1814baea2e140993010d8ee`

### Question

```
How will new AI technologies revolutionize video production budgets?
```

### Available tools

```json
[
  {
    "description": "Calculates the current cost in target currency given the amount in base currency and exchange rate",
    "name": "currency_converter",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount in base currency",
          "type": "float"
        },
        "base_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "target_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "base_currency",
        "target_currency",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 329 -- `un1:ea4c7fe5f42a3ccf78715747240f8e38ad96fdfbd5f0b36f1547ffc78380c614`

### Question

```
What do people who are born deaf hear when they think?
```

### Available tools

```json
[
  {
    "description": "Perform sentiment analysis on a given piece of text.",
    "name": "sentiment_analysis",
    "parameters": {
      "properties": {
        "language": {
          "description": "The language in which the text is written.",
          "type": "string"
        },
        "text": {
          "description": "The text on which to perform sentiment analysis.",
          "type": "string"
        }
      },
      "required": [
        "text",
        "language"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby concerts based on specific criteria like genre.",
    "name": "concert.find_nearby",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Genre of music to be played at the concert.",
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Seattle, WA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  }
]
```

## Item 330 -- `un1:a3757c98bb38b90437bae57d3f7e82dadce55be6b7ffc69ba34fb476c5ddaa3d`

### Question

```
Does unemployment always have a negative impact on mental health?
```

### Available tools

```json
[
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 331 -- `un1:588b3553c391e987ed9bf05ad5363a879059f538006eb4bf59aecd3b952d1056`

### Question

```
Where should I go to kayak when I graduate in 2030?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a mathematical function within a given interval.",
    "name": "calculate_area_under_curve",
    "parameters": {
      "properties": {
        "function": {
          "description": "The mathematical function as a string.",
          "type": "string"
        },
        "interval": {
          "description": "An array that defines the interval to calculate the area under the curve from the start to the end point.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "method": {
          "description": "The numerical method to approximate the area under the curve. The default value is 'trapezoidal'.",
          "type": "string"
        }
      },
      "required": [
        "function",
        "interval"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the distance between two locations, considering terrain.",
    "name": "distance_calculator.calculate",
    "parameters": {
      "properties": {
        "consider_terrain": {
          "description": "Whether to account for terrain in distance calculation, defaults to false.",
          "type": "boolean"
        },
        "destination": {
          "description": "Destination location of the distance measurement.",
          "type": "string"
        },
        "origin": {
          "description": "Starting location of the distance measurement.",
          "type": "string"
        }
      },
      "required": [
        "origin",
        "destination"
      ],
      "type": "dict"
    }
  }
]
```

## Item 332 -- `un1:ca4387470bbbb8eff62a265b8d7ea47cc83407d520fc6f07357df75e9ca24113`

### Question

```
Will the next Don Don DeLillo novel be his most successful novel?
```

### Available tools

```json
[
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  }
]
```

## Item 333 -- `un1:78eb0dbc6c87370813a9bc2fb55ecc8dbb1db74629a0d23b26a5f3b05a1743f0`

### Question

```
When will construction equipment be able to construct skyscrapers within a day?
```

### Available tools

```json
[
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  }
]
```

## Item 334 -- `un1:aaa724541c3d018d7a270bd164d9097ab26dc5b341438e9859b021ba7f506b48`

### Question

```
What undiscovered patterns exist in medical billing errors?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of rolling a certain number on a six-sided die a certain number of times in a row.",
    "name": "probability.dice_roll",
    "parameters": {
      "properties": {
        "desired_number": {
          "description": "The number you want to roll.",
          "type": "integer"
        },
        "die_sides": {
          "description": "The number of sides on the die (optional; default is 6).",
          "type": "integer"
        },
        "number_of_rolls": {
          "description": "How many times you want to roll that number in a row.",
          "type": "integer"
        }
      },
      "required": [
        "desired_number",
        "number_of_rolls"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  }
]
```

## Item 335 -- `un1:b3898b393c7b0a2dba8ad5264742fe4ecfbb7d6f8c9066239988433d18942a9f`

### Question

```
Will AI fraud detection completely eradicate fraud?
```

### Available tools

```json
[
  {
    "description": "Calculate the recommended daily water intake for a person based on their weight.",
    "name": "calculate_daily_water_intake",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "The level of physical activity of the person. Default is 'moderate'.",
          "type": "string"
        },
        "climate": {
          "description": "The climate of the area where the person lives. Default is 'temperate'.",
          "type": "string"
        },
        "weight": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the future value of an investment based on the present value, interest rate, and time period.",
    "name": "calculate_future_value",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate in decimal form. Example, 5% is 0.05.",
          "type": "float"
        },
        "compounds_per_year": {
          "description": "The number of times the interest is compounded per year. Default is 1 (annual compounding).",
          "type": "integer"
        },
        "present_value": {
          "description": "The present value or principal amount.",
          "type": "integer"
        },
        "years": {
          "description": "The time period in years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "present_value",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 336 -- `un1:b8b8d7c9fdf35780da26810ffc5b4f8941c220cd6b685c364e72f0c3efee4d19`

### Question

```
How do neural networks without neurons function?
```

### Available tools

```json
[
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Draw a rectangle given its width and height.",
    "name": "draw_rectangle",
    "parameters": {
      "properties": {
        "color": {
          "description": "The color of the rectangle. Default is 'black'.",
          "type": "string"
        },
        "height": {
          "description": "The height of the rectangle.",
          "type": "integer"
        },
        "width": {
          "description": "The width of the rectangle.",
          "type": "integer"
        }
      },
      "required": [
        "width",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 337 -- `un1:aaf1cf46427b6cfdb529d2e2ad9a1e40a0bf2650916ecc1c4a413fcf378d2de9`

### Question

```
What disease did Cured Ham have originally?
```

### Available tools

```json
[
  {
    "description": "Predict the evolutionary rate for a specific species for a given timeframe.",
    "name": "prediction.evolution",
    "parameters": {
      "properties": {
        "model": {
          "description": "The model used to make the prediction, options: 'Darwin', 'Lamarck', default is 'Darwin'.",
          "type": "string"
        },
        "species": {
          "description": "The species that the evolution rate will be predicted for.",
          "type": "string"
        },
        "years": {
          "description": "Number of years for the prediction.",
          "type": "integer"
        }
      },
      "required": [
        "species",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the circumference of a circle with a given radius.",
    "name": "calculate_circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle in the unit given.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measurement for the radius. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetches the year a particular scientific work was published.",
    "name": "publication_year.find",
    "parameters": {
      "properties": {
        "author": {
          "description": "Name of the author of the work.",
          "type": "string"
        },
        "location": {
          "description": "Place of the publication, if known. Default to 'all'.",
          "type": "string"
        },
        "work_title": {
          "description": "Title of the scientific work.",
          "type": "string"
        }
      },
      "required": [
        "author",
        "work_title"
      ],
      "type": "dict"
    }
  }
]
```

## Item 338 -- `un1:e3002e28f8368a72cc82003d455a50314af970a0d412180e9e242b29239de8e4`

### Question

```
Is there any good time or good day to say ‘I love you’
```

### Available tools

```json
[
  {
    "description": "Calculate compound interest for an initial principal amount.",
    "name": "calculate_compound_interest",
    "parameters": {
      "properties": {
        "n": {
          "description": "The number of times that interest is compounded per time period. Default is 1.",
          "type": "integer"
        },
        "principal": {
          "description": "The principal amount that the interest is applied to.",
          "type": "integer"
        },
        "rate": {
          "description": "The annual interest rate. Enter as a decimal. E.g, 5% is 0.05",
          "type": "float"
        },
        "time": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "rate",
        "time"
      ],
      "type": "dict"
    }
  }
]
```

## Item 339 -- `un1:5206d09d5c64c02d2df95bab2a5af6dab7944dbbb1ee9fcfaed811b33a10543e`

### Question

```
Are there Vampires in Dallas?
```

### Available tools

```json
[
  {
    "description": "Calculate quarterly dividend per share for a company given total dividend payout and outstanding shares",
    "name": "finance.calculate_quarterly_dividend_per_share",
    "parameters": {
      "optional": [],
      "properties": {
        "outstanding_shares": {
          "description": "Total number of outstanding shares",
          "type": "integer"
        },
        "total_payout": {
          "description": "The total amount of dividends paid out in USD",
          "type": "integer"
        }
      },
      "required": [
        "total_payout",
        "outstanding_shares"
      ],
      "type": "dict"
    }
  }
]
```

## Item 340 -- `un1:207ceb1581c7672960a65b62909df0773caae5f0ecca1ee3086a54d06d295c5c`

### Question

```
Often called high energy particles, what gives life to them?
```

### Available tools

```json
[
  {
    "description": "Locate local nurseries based on location and plant types availability.",
    "name": "local_nursery.find",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city or locality where the nursery needs to be located.",
          "type": "string"
        },
        "plant_types": {
          "description": "Type of plants the nursery should provide.",
          "items": {
            "enum": [
              "Annual",
              "Perennial",
              "Shrub",
              "Tree",
              "Herbs",
              "Fruits"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "plant_types"
      ],
      "type": "dict"
    }
  }
]
```

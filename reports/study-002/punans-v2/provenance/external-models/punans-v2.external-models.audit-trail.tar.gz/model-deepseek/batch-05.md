# Annotation batch 05 -- task punans-v2

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 81 -- `un2:a48c079bfdc8f57838946ab7ef8af543ab373476eff791fb1ea89284c6a331f7`

### Question

```
Who will be the governor of Missouri in 2056?
```

### Available tools

```json
[
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 82 -- `un2:ad2de1e671de0fce94a5a49dfa659466066fa24917501886936d2aabba492796`

### Question

```
Will there be a universal infrastructure recovery plan for all countries facing disaster in the next 30 years?
```

### Available tools

```json
[
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 83 -- `un2:961b278f1c82af9c638e056adc3276702c7d728814b3879ade287c33d93654fc`

### Question

```
Will human live in mars in next 25 years ?
```

### Available tools

```json
[
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  }
]
```

## Item 84 -- `un2:3efdb07429fb046846fcfe8272aa06170ad0609bb8216062c24576da87f2b7bd`

### Question

```
Will there be a breakthrough in AI-generated ghostwriting that outperforms human writers?
```

### Available tools

```json
[
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 85 -- `un2:75e5be6c09fe8dfa1ff8894b39c8530594c0066286ecffb36fccc6347ae424f5`

### Question

```
Which album will Fleetwood Mac release in April 2050?
```

### Available tools

```json
[
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  }
]
```

## Item 86 -- `un2:c11959a3b47a0e3ec538e1404b2a63bfd3efa9887d252bcea4e94bb38592b3fd`

### Question

```
Will women achieve equal representation in foreign service leadership positions within the next decade?
```

### Available tools

```json
[
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 87 -- `un2:0bfe0b6d95446502a02ad34ac8626a2a53ce7f27a3b2f261456a3b7b2ca2bfd5`

### Question

```
Will there ever be an affordable solution to eliminate the cons of public transportation?
```

### Available tools

```json
[
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 88 -- `un2:91725ba1c0f356f63768ed1367135e97f89dae14000af5ad3cf22941773b3662`

### Question

```
Will there be a breakthrough technology to significantly enhance car steering precision in the next decade?
```

### Available tools

```json
[
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  }
]
```

## Item 89 -- `un2:2a790ac1fef81de5aaf70861fc97a7ccfdcd87a8e19b349c788d17c708afaf44`

### Question

```
Will affiliate networks become the dominant force in marketing by 2030?
```

### Available tools

```json
[
  {
    "description": "Perform sentiment analysis on a given piece of text.",
    "name": "sentiment_analysis",
    "parameters": {
      "properties": {
        "language": {
          "description": "The language in which the text is written.",
          "type": "string"
        },
        "text": {
          "description": "The text on which to perform sentiment analysis.",
          "type": "string"
        }
      },
      "required": [
        "text",
        "language"
      ],
      "type": "dict"
    }
  }
]
```

## Item 90 -- `un2:520bd6bacd7594514e282046cf6d80c61d229576b25d81c457a5b37dc555cf9a`

### Question

```
Can we fully regenerate damaged cartilage in joints through orthopedic treatments?
```

### Available tools

```json
[
  {
    "description": "Locate nearby parks based on specific criteria like tennis court availability.",
    "name": "parks.find_nearby",
    "parameters": {
      "properties": {
        "amenities": {
          "description": "Preferred amenities in park. Default is ['Running Track']",
          "items": {
            "enum": [
              "Tennis Court",
              "Picnic Area",
              "Playground",
              "Running Track"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. London, UK",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 91 -- `un2:7583b3994e00871c1f780c125c4ce6abb9094adbe046de6e26b4013a571b18c7`

### Question

```
Can living life exist after a singularity?
```

### Available tools

```json
[
  {
    "description": "Calculate the final speed of an object in free fall after a certain time, neglecting air resistance. The acceleration due to gravity is considered as -9.81 m/s^2",
    "name": "calculate_final_speed",
    "parameters": {
      "properties": {
        "gravity": {
          "description": "The acceleration due to gravity. Default is -9.81 m/s^2.",
          "type": "float"
        },
        "initial_speed": {
          "description": "The initial speed of the object in m/s. Default is 0 for an object at rest.",
          "type": "integer"
        },
        "time": {
          "description": "The time in seconds for which the object is in free fall.",
          "type": "integer"
        }
      },
      "required": [
        "time"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Shuffle a standard deck of 52 cards and draw a specified number of cards from the top.",
    "name": "cards.shuffle_and_draw",
    "parameters": {
      "properties": {
        "num_cards": {
          "description": "Number of cards to be drawn. The default is 1 if no value is provided.",
          "type": "integer"
        }
      },
      "required": [
        "num_cards"
      ],
      "type": "dict"
    }
  }
]
```

## Item 92 -- `un2:6d986e86214b0dbd63149f1bb100c533bfa78c50321a80b11e177763f3877849`

### Question

```
Do you think religion will ever stop existing?
```

### Available tools

```json
[
  {
    "description": "Predict the price of a house in a given area based on number of bedrooms, bathrooms and area.",
    "name": "predict_house_price",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area of the house in square feet.",
          "type": "integer"
        },
        "bathrooms": {
          "description": "The number of bathrooms in the house.",
          "type": "integer"
        },
        "bedrooms": {
          "description": "The number of bedrooms in the house.",
          "type": "integer"
        },
        "location": {
          "description": "The location of the house in the format of city name.",
          "type": "string"
        }
      },
      "required": [
        "bedrooms",
        "bathrooms",
        "area",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the return on investment for a given stock based on its purchase price, sale price, and any dividends received.",
    "name": "calculate_return_on_investment",
    "parameters": {
      "properties": {
        "dividend": {
          "default": 0,
          "description": "Any dividends received from the stock.",
          "type": "integer"
        },
        "purchase_price": {
          "description": "The price the stock was bought at.",
          "type": "integer"
        },
        "sale_price": {
          "description": "The price the stock was sold at.",
          "type": "integer"
        }
      },
      "required": [
        "purchase_price",
        "sale_price"
      ],
      "type": "dict"
    }
  }
]
```

## Item 93 -- `un2:cb727a463d0c52b100ea0970a17dc45c6166b0b576bda47a9a9ab9a0939c2e87`

### Question

```
Will there ever be a vehicle that seamlessly combines the best features of both convertibles and coupes?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a circle given its radius.",
    "name": "geometry.calculate_area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "unit": {
          "description": "The measurement unit of the radius (optional parameter, default is 'units').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Create a histogram based on provided data.",
    "name": "create_histogram",
    "parameters": {
      "properties": {
        "bins": {
          "description": "The number of equal-width bins in the range. Default is 10.",
          "type": "integer"
        },
        "data": {
          "description": "The data for which histogram needs to be plotted.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "data",
        "bins"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the electric field produced by a charge at a certain distance.",
    "name": "calculate_electric_field",
    "parameters": {
      "properties": {
        "charge": {
          "description": "Charge in coulombs producing the electric field.",
          "type": "integer"
        },
        "distance": {
          "description": "Distance from the charge in meters where the field is being measured.",
          "type": "integer"
        },
        "permitivity": {
          "description": "Permitivity of the space where field is being calculated, default is 8.854e-12.",
          "type": "float"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 94 -- `un2:8e9cd169a114e0ae41341b0a935900d86e0de8b4109594a95fa2cc7810b66b27`

### Question

```
Can blockchain technology effectively combat illegal logging and ensure sustainable forestry practices?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 95 -- `un2:c3090444c7e68c8019e70544a5996ca42149dcefb9e71e7ccac2164d4320297a`

### Question

```
Will a genealogy podcast reveal a previously unknown ancestral connection between two prominent families?
```

### Available tools

```json
[
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  }
]
```

## Item 96 -- `un2:0063f0998d85fe80e4b1d7c713217a48898f0b785113faa5822af6f95064bf66`

### Question

```
Will a breakthrough technology revolutionize car handling in the coming years?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the circumference of a circle with a given radius.",
    "name": "calculate_circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle in the unit given.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measurement for the radius. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 97 -- `un2:efeabf04caba53c9e3fb804db725fac3ab35d789504501dcaf5b7910045aad9e`

### Question

```
Will Electronic Design Automation eventually eliminate the need for human engineers in electronics development?
```

### Available tools

```json
[
  {
    "description": "Calculate the compounded interest for a given principal, interest rate, and period.",
    "name": "calculate_compounded_interest",
    "parameters": {
      "properties": {
        "compounding_frequency": {
          "description": "The frequency of compounding per year. Defaults to 'Annually'.",
          "enum": [
            "Annually",
            "Semiannually",
            "Quarterly",
            "Monthly",
            "Daily"
          ],
          "type": "string"
        },
        "interest_rate": {
          "description": "The annual interest rate.",
          "type": "float"
        },
        "period": {
          "description": "The period in years.",
          "type": "integer"
        },
        "principal": {
          "description": "The initial principal.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "interest_rate",
        "period"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the final balance of a mutual fund investment based on the total initial investment, annual yield rate and the time period.",
    "name": "calculate_mutual_fund_balance",
    "parameters": {
      "properties": {
        "annual_yield": {
          "description": "The annual yield rate of the fund.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The initial total amount invested in the fund.",
          "type": "integer"
        },
        "years": {
          "description": "The period of time for the fund to mature.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_yield",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 98 -- `un2:02ac46f23d58d7189e5ce2b6e79a5f787c1a6101dc00597c82bf0a0162d2c8af`

### Question

```
Will nanofibers outperform traditional materials in all industries within the next 50 years?
```

### Available tools

```json
[
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby concerts based on specific criteria like genre.",
    "name": "concert.find_nearby",
    "parameters": {
      "properties": {
        "genre": {
          "description": "Genre of music to be played at the concert.",
          "type": "string"
        },
        "location": {
          "description": "The city and state, e.g. Seattle, WA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Identify a bird species based on certain characteristics.",
    "name": "identify_bird",
    "parameters": {
      "properties": {
        "color": {
          "description": "Color of the bird.",
          "type": "string"
        },
        "habitat": {
          "description": "Habitat of the bird.",
          "type": "string"
        },
        "size": {
          "description": "Size of the bird. Default is 'small'",
          "enum": [
            "small",
            "medium",
            "large"
          ],
          "type": "string"
        }
      },
      "required": [
        "color",
        "habitat"
      ],
      "type": "dict"
    }
  }
]
```

## Item 99 -- `un2:38727fb762f494250b07efaab7f1a734266347d132a614e475cf3a2a01675161`

### Question

```
Who killed Alexander the Great?
```

### Available tools

```json
[
  {
    "description": "Calculate the change in entropy for a mass of a specific substance under set initial and final conditions.",
    "name": "entropy_change.calculate",
    "parameters": {
      "properties": {
        "final_temperature": {
          "description": "The final temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "initial_temperature": {
          "description": "The initial temperature of the substance in degree Celsius.",
          "type": "integer"
        },
        "mass": {
          "description": "The mass of the substance in kg.",
          "type": "integer"
        },
        "pressure": {
          "default": 1,
          "description": "The pressure the substance is under in atmospheres.",
          "type": "integer"
        },
        "substance": {
          "description": "The substance for which the change in entropy is calculated.",
          "type": "string"
        }
      },
      "required": [
        "substance",
        "mass",
        "initial_temperature",
        "final_temperature"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 100 -- `un2:8da7a35e52edc30ad9f3cc66f9ff8871d5c7e31f56929c2b59fecef631ad008a`

### Question

```
When all people in the world will have own car ?
```

### Available tools

```json
[
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

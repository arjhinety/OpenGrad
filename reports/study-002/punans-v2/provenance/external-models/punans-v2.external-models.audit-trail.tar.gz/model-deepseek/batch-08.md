# Annotation batch 08 -- task punans-v2

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 141 -- `un2:21a08a7c3cbaf735b6f897e3aa1760d9ef795e41b258c5c28b9a01d4252e4763`

### Question

```
Do near-death experiences accurately represent what heaven and hell are like?
```

### Available tools

```json
[
  {
    "description": "Locate a flute for sale based on specific requirements.",
    "name": "find_flute",
    "parameters": {
      "properties": {
        "brand": {
          "description": "The brand of the flute. Example, 'Yamaha'",
          "type": "string"
        },
        "specs": {
          "description": "The specifications of the flute desired.",
          "items": {
            "enum": [
              "open hole",
              "C foot",
              "silver headjoint"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "brand",
        "specs"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Finds the type of a genetic mutation based on its SNP (Single Nucleotide Polymorphism) ID.",
    "name": "mutation_type.find",
    "parameters": {
      "properties": {
        "snp_id": {
          "description": "The ID of the Single Nucleotide Polymorphism (SNP) mutation.",
          "type": "string"
        },
        "species": {
          "description": "Species in which the SNP occurs, default is 'Homo sapiens' (Humans).",
          "type": "string"
        }
      },
      "required": [
        "snp_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the greatest common divisor of two numbers",
    "name": "math.gcd",
    "parameters": {
      "properties": {
        "num1": {
          "description": "The first number.",
          "type": "integer"
        },
        "num2": {
          "description": "The second number.",
          "type": "integer"
        }
      },
      "required": [
        "num1",
        "num2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 142 -- `un2:f073ca8135d3425105487df553589cfa607daaaeb0b94fcd31e06c646c4cbc7b`

### Question

```
Will there be a significant change in the taxation of IRAs in the next 20 years?
```

### Available tools

```json
[
  {
    "description": "Find upcoming events of a specific genre in a given location.",
    "name": "event_finder.find_upcoming",
    "parameters": {
      "properties": {
        "days_ahead": {
          "default": 7,
          "description": "The number of days from now to include in the search.",
          "type": "integer"
        },
        "genre": {
          "description": "The genre of events.",
          "type": "string"
        },
        "location": {
          "description": "The city and state where the search will take place, e.g. New York, NY.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "genre"
      ],
      "type": "dict"
    }
  }
]
```

## Item 143 -- `un2:bad753182f3d9a78a8369a3ecd2502fcdb03f59a08ded39f12be9c88388e74e7`

### Question

```
Will there be a breakthrough technology to completely prevent sun damage to cars in the future?
```

### Available tools

```json
[
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  }
]
```

## Item 144 -- `un2:916caac7fe9734c175ed10f346f35ddef9aee669ffd0d945d971e6341abdef74`

### Question

```
Will there be a revolutionary layover activity to maximize travelers' experiences in the future?
```

### Available tools

```json
[
  {
    "description": "Generates a random number from a normal distribution given the mean and standard deviation.",
    "name": "random.normalvariate",
    "parameters": {
      "properties": {
        "mu": {
          "description": "Mean of the normal distribution.",
          "type": "integer"
        },
        "sigma": {
          "description": "Standard deviation of the normal distribution.",
          "type": "integer"
        }
      },
      "required": [
        "mu",
        "sigma"
      ],
      "type": "dict"
    }
  }
]
```

## Item 145 -- `un2:a18238f3ba35bf6ffae4bf0c8d7193f970e04a806d22ee82eda300ec87db8cf4`

### Question

```
Can a single treatment effectively address all common pet skin problems?
```

### Available tools

```json
[
  {
    "description": "Calculate the probability of an event.",
    "name": "calculate_probability",
    "parameters": {
      "properties": {
        "favorable_outcomes": {
          "description": "Number of outcomes considered as 'successful'.",
          "type": "integer"
        },
        "round_to": {
          "default": 2,
          "description": "Number of decimal places to round the result to.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "Total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "favorable_outcomes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  }
]
```

## Item 146 -- `un2:83813b05a9843fa8be8915e4ce3a9d3130577f5470f758b818d58150c74faf16`

### Question

```
Will a new type of ouzo be developed in the future that surpasses its historical predecessors?
```

### Available tools

```json
[
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 147 -- `un2:08ad0f81072685bd3326edd6cdddfc2003c464ca0d15c5ded52a1a37bb69167b`

### Question

```
Can effective event planning and management significantly boost innovation in the energy industry?
```

### Available tools

```json
[
  {
    "description": "Calculate the third major chord in a given key.",
    "name": "get_third_chord",
    "parameters": {
      "properties": {
        "key": {
          "description": "The key of the scale.",
          "type": "string"
        },
        "type": {
          "description": "Type of the scale, either major or minor. Default is 'major'.",
          "type": "string"
        }
      },
      "required": [
        "key"
      ],
      "type": "dict"
    }
  }
]
```

## Item 148 -- `un2:a3f34d477dc1f30f5975ef85699544384361443ea004eb8abdf468ae11eb4547`

### Question

```
What are the specific challenges agricultural extension officers will encounter in the future?
```

### Available tools

```json
[
  {
    "description": "Calculate quarterly dividend per share for a company given total dividend payout and outstanding shares",
    "name": "finance.calculate_quarterly_dividend_per_share",
    "parameters": {
      "optional": [],
      "properties": {
        "outstanding_shares": {
          "description": "Total number of outstanding shares",
          "type": "integer"
        },
        "total_payout": {
          "description": "The total amount of dividends paid out in USD",
          "type": "integer"
        }
      },
      "required": [
        "total_payout",
        "outstanding_shares"
      ],
      "type": "dict"
    }
  },
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  }
]
```

## Item 149 -- `un2:b033bbb392ad51c5dfd0558e7666efa65f66d8b8bf49a731f4c4077798bd13d0`

### Question

```
What factors trigger unique erosion anomalies?
```

### Available tools

```json
[
  {
    "description": "Estimate the travel time for a specific route with optional stops.",
    "name": "route.estimate_time",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "start_location": {
          "description": "The starting point for the journey. It should be format as city name such as Boston.",
          "type": "string"
        },
        "stops": {
          "description": "Additional cities or points of interest to stop at during the journey. Default is an empty list.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "start_location",
        "end_location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 150 -- `un2:d85accc91068faaba59ca8c47cbc7b91b0f126f6b924353f9aa6a5cc4c49a5e4`

### Question

```
Will a new agricultural fiber crop surpass the production of cotton in the next 50 years?
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 151 -- `un2:da56025f72ee1e9282327119be2f2ee07caaabf24bc808831e53cada87b073c0`

### Question

```
Will e-learning and online courses significantly improve the skills of mental health professionals in the future?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a curve for a specified function between two x values.",
    "name": "integrate",
    "parameters": {
      "properties": {
        "end_x": {
          "description": "The ending x-value to integrate over.",
          "type": "integer"
        },
        "function": {
          "description": "The function to integrate, represented as a string. For example, 'x^3'",
          "type": "string"
        },
        "method": {
          "description": "The method of numerical integration to use. Choices are 'trapezoid' or 'simpson'. Default is 'trapezoid'.",
          "type": "string"
        },
        "start_x": {
          "description": "The starting x-value to integrate over.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "start_x",
        "end_x"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a triangle with the formula area = 0.5 * base * height.",
    "name": "calc_area_triangle",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the triangle in meters.",
          "type": "integer"
        },
        "height": {
          "description": "The perpendicular height of the triangle from the base to the opposite vertex in meters.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the time taken for light to travel from a celestial body to another.",
    "name": "light_travel_time",
    "parameters": {
      "properties": {
        "distance_in_light_years": {
          "description": "The distance between the two celestial bodies in light years.",
          "type": "integer"
        },
        "speed_of_light": {
          "description": "The speed of light in vacuum, in m/s. Default value is 299792458 m/s.",
          "type": "integer"
        }
      },
      "required": [
        "distance_in_light_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 152 -- `un2:07abb61b13975c86a4898db71052be066861faad4ed54414ed89d8b6fc6aeaf2`

### Question

```
Can ancestral environmental factors influence our genealogy and family history?
```

### Available tools

```json
[
  {
    "description": "Compute the derivative of a function at a specific value.",
    "name": "calculus.derivative",
    "parameters": {
      "properties": {
        "function": {
          "description": "The function to calculate the derivative of.",
          "type": "string"
        },
        "function_variable": {
          "description": "The variable present in the function, for instance x or y, etc. Default is 'x'.",
          "type": "string"
        },
        "value": {
          "description": "The value where the derivative needs to be calculated at.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "value"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the price of a house in a given area based on number of bedrooms, bathrooms and area.",
    "name": "predict_house_price",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area of the house in square feet.",
          "type": "integer"
        },
        "bathrooms": {
          "description": "The number of bathrooms in the house.",
          "type": "integer"
        },
        "bedrooms": {
          "description": "The number of bedrooms in the house.",
          "type": "integer"
        },
        "location": {
          "description": "The location of the house in the format of city name.",
          "type": "string"
        }
      },
      "required": [
        "bedrooms",
        "bathrooms",
        "area",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  }
]
```

## Item 153 -- `un2:4f6da2c59f2836f670d73a059bfca3b7b2b1fb1cfd30ea69eb820cce1fa7b97c`

### Question

```
Will there be a breakthrough technique for achieving a flawless natural-looking highlight in the near future?
```

### Available tools

```json
[
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  }
]
```

## Item 154 -- `un2:3ec6880159a8aae79e4733dd9a1a199b87e4971a727af613a2ba6ec0ceaf508b`

### Question

```
Will a groundbreaking material for nanogenerators be discovered in the next decade?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 155 -- `un2:681997f1203502d48b43db2ecbf29e857a2ecba116c320bce5adf479edf0d7cd`

### Question

```
Are there mermaids in the universe?
```

### Available tools

```json
[
  {
    "description": "Calculate the amount of paint required to paint a given area. Account for coverage efficiency of the paint and exclusions (like windows).",
    "name": "paint_requirement.calculate",
    "parameters": {
      "properties": {
        "area": {
          "description": "The area to be painted.",
          "properties": {
            "height": {
              "description": "The height of the area to be painted in feet.",
              "type": "integer"
            },
            "width": {
              "description": "The width of the area to be painted in feet.",
              "type": "integer"
            }
          },
          "type": "dict"
        },
        "exclusion": {
          "description": "Area not to be painted. Default to not use any exclusion if not specified.",
          "properties": {
            "area": {
              "description": "The area of the exclusion in square feet.",
              "type": "integer"
            },
            "type": {
              "description": "The type of the exclusion e.g window, door etc.",
              "type": "string"
            }
          },
          "type": "dict"
        },
        "paint_coverage": {
          "default": 350,
          "description": "Coverage area per gallon of the paint in square feet.",
          "type": "integer"
        }
      },
      "required": [
        "area",
        "paint_coverage"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the probability of an event.",
    "name": "calculate_probability",
    "parameters": {
      "properties": {
        "favorable_outcomes": {
          "description": "Number of outcomes considered as 'successful'.",
          "type": "integer"
        },
        "round_to": {
          "default": 2,
          "description": "Number of decimal places to round the result to.",
          "type": "integer"
        },
        "total_outcomes": {
          "description": "Total number of possible outcomes.",
          "type": "integer"
        }
      },
      "required": [
        "total_outcomes",
        "favorable_outcomes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 156 -- `un2:78e605b5640b0e412b8ef1ebe6d32c5688b672d3c4d543656aaf2c69e64c4606`

### Question

```
Does a yet undiscovered force or phenomenon play a role in the formation of the solar system?
```

### Available tools

```json
[
  {
    "description": "Find recipes based on dietary restrictions, meal type, and preferred ingredients.",
    "name": "find_recipes",
    "parameters": {
      "properties": {
        "diet": {
          "description": "The dietary restrictions, e.g., 'vegan', 'gluten-free'.",
          "type": "string"
        },
        "ingredients": {
          "description": "The preferred ingredients. If left blank, it will default to return general recipes.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "meal_type": {
          "description": "The type of meal, e.g., 'dinner', 'breakfast'.",
          "type": "string"
        }
      },
      "required": [
        "diet",
        "meal_type"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predict the evolutionary rate for a specific species for a given timeframe.",
    "name": "prediction.evolution",
    "parameters": {
      "properties": {
        "model": {
          "description": "The model used to make the prediction, options: 'Darwin', 'Lamarck', default is 'Darwin'.",
          "type": "string"
        },
        "species": {
          "description": "The species that the evolution rate will be predicted for.",
          "type": "string"
        },
        "years": {
          "description": "Number of years for the prediction.",
          "type": "integer"
        }
      },
      "required": [
        "species",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 157 -- `un2:5af380defab603c83061d28f506ab5722d61a22a68c422886dc6b3c55f039264`

### Question

```
Will there be an intervention for social media addiction in the future?
```

### Available tools

```json
[
  {
    "description": "Calculate the Body Mass Index (BMI) given a person's weight and height.",
    "name": "calculate_BMI",
    "parameters": {
      "properties": {
        "height_m": {
          "description": "The height of the person in meters.",
          "type": "float"
        },
        "weight_kg": {
          "description": "The weight of the person in kilograms.",
          "type": "integer"
        }
      },
      "required": [
        "weight_kg",
        "height_m"
      ],
      "type": "dict"
    }
  }
]
```

## Item 158 -- `un2:beb312ec1f5acbb01f2119a239f87391d96d31578a274c4e0d436b92e8fd6052`

### Question

```
Will a new method of raising capital for start-ups surpass traditional methods in the next decade?
```

### Available tools

```json
[
  {
    "description": "Find the most followed Twitter user related to certain topics.",
    "name": "social_media_analytics.most_followed",
    "parameters": {
      "properties": {
        "region": {
          "description": "Region of interest for twitter search. Default is 'all'.",
          "type": "string"
        },
        "sub_topics": {
          "description": "Sub-topics related to main topic. Default is empty.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "topic": {
          "description": "The main topic of interest.",
          "type": "string"
        }
      },
      "required": [
        "topic"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the final balance of a mutual fund investment based on the total initial investment, annual yield rate and the time period.",
    "name": "calculate_mutual_fund_balance",
    "parameters": {
      "properties": {
        "annual_yield": {
          "description": "The annual yield rate of the fund.",
          "type": "float"
        },
        "investment_amount": {
          "description": "The initial total amount invested in the fund.",
          "type": "integer"
        },
        "years": {
          "description": "The period of time for the fund to mature.",
          "type": "integer"
        }
      },
      "required": [
        "investment_amount",
        "annual_yield",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 159 -- `un2:a350c2d1f7b7c7a907b3c5709b85810e03a885595b11606dba35e6eecae59f11`

### Question

```
Who will president Biden run against in 2056?
```

### Available tools

```json
[
  {
    "description": "Locate nearby public libraries based on specific criteria like English fiction availability and Wi-Fi.",
    "name": "public_library.find_nearby",
    "parameters": {
      "properties": {
        "facilities": {
          "description": "Facilities and sections in public library.",
          "items": {
            "enum": [
              "Wi-Fi",
              "Reading Room",
              "Fiction",
              "Children Section",
              "Cafe"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Boston, MA",
          "type": "string"
        }
      },
      "required": [
        "location",
        "facilities"
      ],
      "type": "dict"
    }
  }
]
```

## Item 160 -- `un2:d153993cd9f5bb37abd6a5fd53dfa3d423f27ad1b77c29adecc67227fa957b22`

### Question

```
How will humanity adapt to living on other planets and in space for extended periods of time?
```

### Available tools

```json
[
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  }
]
```

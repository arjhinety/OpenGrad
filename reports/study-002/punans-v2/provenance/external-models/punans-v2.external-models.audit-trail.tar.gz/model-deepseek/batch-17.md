# Annotation batch 17 -- task punans-v2

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 321 -- `un2:61331bd8eaca04e440f4a6c0ed92de7a276527d24dc3944b5a6e87cd5cecd8d9`

### Question

```
Will scientists have a full and complete understanding of the role of dopamine in addiction by the year 2040?
```

### Available tools

```json
[
  {
    "description": "Modify an existing painting's attributes such as size, medium, and color.",
    "name": "modify_painting",
    "parameters": {
      "properties": {
        "dominant_color": {
          "description": "The dominant color of the painting. Default to 'black'.",
          "type": "string"
        },
        "medium": {
          "description": "The medium of the painting, such as oil, acrylic, etc.",
          "type": "string"
        },
        "size": {
          "description": "The size of the painting in inches, width by height.",
          "type": "string"
        }
      },
      "required": [
        "size",
        "medium"
      ],
      "type": "dict"
    }
  }
]
```

## Item 322 -- `un2:a911bf39893c1e10602e3ae491f961c1715b8c28ef38c2cb908123c1cd180467`

### Question

```
Does a universal mining regulation exist for all countries to follow?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generate a random DNA sequence with a specific length and nucleotide preference.",
    "name": "generate_DNA_sequence",
    "parameters": {
      "properties": {
        "length": {
          "description": "The length of the DNA sequence to be generated.",
          "type": "integer"
        },
        "preferences": {
          "description": "Preferred nucleotides to include more frequently in the DNA sequence.",
          "items": {
            "enum": [
              "A",
              "T",
              "C",
              "G"
            ],
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "length",
        "preferences"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 323 -- `un2:3ee32cd6b90ec67959e994274aeb2b35b350df722d5d00d0806ca45155f8d8cc`

### Question

```
Will the integration of big data in retail lead to an entirely automated shopping experience?
```

### Available tools

```json
[
  {
    "description": "Calculate the power of one number raised to another.",
    "name": "math.power",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base number.",
          "type": "integer"
        },
        "exponent": {
          "description": "The exponent.",
          "type": "integer"
        },
        "mod": {
          "description": "The modulus. Default is 1. Calculates pow(base, exponent) % mod when provided.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "exponent"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate total price for given items and their quantities at Walmart.",
    "name": "walmart.check_price",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to be priced.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "quantities": {
          "description": "Quantity of each item corresponding to the items list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "store_location": {
          "description": "The store location for specific pricing (optional). Default to all if not specified.",
          "type": "string"
        }
      },
      "required": [
        "items",
        "quantities"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the energy required or released during a phase change using mass, the phase transition temperature and the specific latent heat.",
    "name": "thermo.calculate_energy",
    "parameters": {
      "properties": {
        "mass": {
          "description": "Mass of the substance in grams.",
          "type": "integer"
        },
        "phase_transition": {
          "description": "Phase transition. Can be 'melting', 'freezing', 'vaporization', 'condensation'.",
          "type": "string"
        },
        "substance": {
          "description": "The substance which is undergoing phase change, default is 'water'",
          "type": "string"
        }
      },
      "required": [
        "mass",
        "phase_transition"
      ],
      "type": "dict"
    }
  }
]
```

## Item 324 -- `un2:477a01a38f4e16e7ae8d91cebdc156ef5ade4f0efa7813a355af9e89aeb467b9`

### Question

```
Will co-parenting relationships improve or worsen after a divorce in the next decade?
```

### Available tools

```json
[
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  }
]
```

## Item 325 -- `un2:94fbd532166bdb0c84086a1aa0ddca6f85052f8d08c4b391b9ad2f4195ac1c7a`

### Question

```
What will be the dominant renewable energy source used in shipping in the year 2050?
```

### Available tools

```json
[
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 326 -- `un2:ddebf1ea8c70f05cfc14ddf261bed61f773877b7c8d4f429b4ce974c30ff54fb`

### Question

```
is there other life in the universe?
```

### Available tools

```json
[
  {
    "description": "Generates a customized law contract given involved parties, contract type and location.",
    "name": "generate_law_contract",
    "parameters": {
      "properties": {
        "contract_type": {
          "description": "Type of the contract.",
          "type": "string"
        },
        "location": {
          "description": "Location where the contract will be in effect.",
          "type": "string"
        },
        "parties": {
          "description": "Parties involved in the contract.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "parties",
        "contract_type",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the future value of an investment in a specific stock based on the invested amount, expected annual return and number of years.",
    "name": "portfolio_future_value",
    "parameters": {
      "properties": {
        "expected_annual_return": {
          "description": "The expected annual return on investment as a decimal. E.g. 5% = 0.05",
          "type": "float"
        },
        "invested_amount": {
          "description": "The invested amount in USD.",
          "type": "integer"
        },
        "stock": {
          "description": "The ticker symbol of the stock.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for which the investment is made.",
          "type": "integer"
        }
      },
      "required": [
        "stock",
        "invested_amount",
        "expected_annual_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 327 -- `un2:65118746c31ec1c6c9369498e98a7c39289285a650a39954b7fc8301a3e81749`

### Question

```
Will there be a groundbreaking discovery in dark matter interactions within the next decade?
```

### Available tools

```json
[
  {
    "description": "Calculate the cell density of a biological sample based on its optical density and the experiment dilution.",
    "name": "calculate_cell_density",
    "parameters": {
      "properties": {
        "calibration_factor": {
          "description": "The calibration factor to adjust the density, default value is 1e9 assuming cell density is in CFU/mL.",
          "type": "float"
        },
        "dilution": {
          "description": "The dilution factor applied during the experiment.",
          "type": "integer"
        },
        "optical_density": {
          "description": "The optical density of the sample, usually obtained from a spectrophotometer reading.",
          "type": "float"
        }
      },
      "required": [
        "optical_density",
        "dilution"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  }
]
```

## Item 328 -- `un2:4c3c61fea22f4ac53af407104f551cc40e9c9bb44fe4f4f67d731fef76af972d`

### Question

```
Will all people be equal economically after twenty years?
```

### Available tools

```json
[
  {
    "description": "Calculate compound interest for a certain time period.",
    "name": "compound_interest",
    "parameters": {
      "properties": {
        "annual_rate": {
          "description": "The interest rate for a year as a percentage.",
          "type": "float"
        },
        "compounding_freq": {
          "description": "The number of times that interest is compounded per unit period.",
          "enum": [
            "monthly",
            "quarterly",
            "annually"
          ],
          "type": "string"
        },
        "principal": {
          "description": "The initial amount of money that was invested or loaned out.",
          "type": "integer"
        },
        "time_in_years": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "annual_rate",
        "compounding_freq",
        "time_in_years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Sorts a given list in ascending or descending order.",
    "name": "array_sort",
    "parameters": {
      "properties": {
        "list": {
          "description": "The list of numbers to be sorted.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "order": {
          "description": "Order of sorting.",
          "enum": [
            "ascending",
            "descending"
          ],
          "type": "string"
        }
      },
      "required": [
        "list",
        "order"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the area of a right-angled triangle given the lengths of its base and height.",
    "name": "calculate_area",
    "parameters": {
      "properties": {
        "base": {
          "description": "The length of the base of the right-angled triangle.",
          "type": "integer"
        },
        "height": {
          "description": "The height of the right-angled triangle.",
          "type": "integer"
        },
        "unit": {
          "description": "The unit of measure used. Defaults to 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "base",
        "height"
      ],
      "type": "dict"
    }
  }
]
```

## Item 329 -- `un2:ae74b3553c066a758c60e7c3a4417cd1ac6eebd71905a05c34e43e522400d3ff`

### Question

```
When will Christianity cease to be a religion that is believed in by a large number of people?
```

### Available tools

```json
[
  {
    "description": "Calculate a company's return on equity based on its net income, shareholder's equity, and dividends paid.",
    "name": "calculate_return_on_equity",
    "parameters": {
      "properties": {
        "dividends_paid": {
          "description": "The total dividends paid by the company. Optional. If not given, default to 0.",
          "type": "integer"
        },
        "net_income": {
          "description": "The company's net income.",
          "type": "integer"
        },
        "shareholder_equity": {
          "description": "The company's total shareholder's equity.",
          "type": "integer"
        }
      },
      "required": [
        "net_income",
        "shareholder_equity"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 330 -- `un2:aa168d7344de3f858b105cb5401c8cc83ad8280c7055a7e001f0a49c5a71d578`

### Question

```
What team will win the World Series this year?
```

### Available tools

```json
[
  {
    "description": "Calculate the resonant frequency of an LC (inductor-capacitor) circuit.",
    "name": "calculate_resonant_frequency",
    "parameters": {
      "properties": {
        "capacitance": {
          "description": "The capacitance (C) in farads (F).",
          "type": "float"
        },
        "inductance": {
          "description": "The inductance (L) in henries (H).",
          "type": "float"
        },
        "round_off": {
          "description": "Rounding off the result to a certain decimal places, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "inductance",
        "capacitance"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Examine the social dynamics and interactions within a group based on the personality traits and group size.",
    "name": "group_dynamics.pattern",
    "parameters": {
      "properties": {
        "extroverts": {
          "description": "The number of extroverted members in the group.",
          "type": "integer"
        },
        "introverts": {
          "description": "The number of introverted members in the group.",
          "type": "integer"
        },
        "total": {
          "description": "The total group size.",
          "type": "integer"
        }
      },
      "required": [
        "total",
        "extroverts",
        "introverts"
      ],
      "type": "dict"
    }
  }
]
```

## Item 331 -- `un2:ca6fa1737c4db08c734b72e219c825314734a5fec35365ac5c0ec76bfbbe6c3b`

### Question

```
Are there undiscovered materials that can revolutionize fabric development?
```

### Available tools

```json
[
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch the recipe for a specific dish along with preparation steps.",
    "name": "get_recipe",
    "parameters": {
      "properties": {
        "diet_preference": {
          "default": "none",
          "description": "Preferred dietary consideration like vegan, vegetarian, gluten-free etc. Default is none.",
          "type": "string"
        },
        "dish_name": {
          "description": "Name of the dish whose recipe needs to be fetched.",
          "type": "string"
        }
      },
      "required": [
        "dish_name"
      ],
      "type": "dict"
    }
  }
]
```

## Item 332 -- `un2:0d87d2b95e5fa20125fba485f53c017c3d288caa4f0f7cda0c4047094a67a3bb`

### Question

```
Can effective leadership in logistics significantly impact global supply chain efficiency?
```

### Available tools

```json
[
  {
    "description": "Calculate the energy required or released during a phase change using mass, the phase transition temperature and the specific latent heat.",
    "name": "thermo.calculate_energy",
    "parameters": {
      "properties": {
        "mass": {
          "description": "Mass of the substance in grams.",
          "type": "integer"
        },
        "phase_transition": {
          "description": "Phase transition. Can be 'melting', 'freezing', 'vaporization', 'condensation'.",
          "type": "string"
        },
        "substance": {
          "description": "The substance which is undergoing phase change, default is 'water'",
          "type": "string"
        }
      },
      "required": [
        "mass",
        "phase_transition"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the shortest driving distance between two locations.",
    "name": "calculate_shortest_distance",
    "parameters": {
      "properties": {
        "end_location": {
          "description": "The destination location for the drive.",
          "type": "string"
        },
        "route_preference": {
          "description": "The preferred type of route.",
          "enum": [
            "Shortest",
            "Scenic"
          ],
          "type": "string"
        },
        "start_location": {
          "description": "The starting location for the drive.",
          "type": "string"
        }
      },
      "required": [
        "start_location",
        "end_location",
        "route_preference"
      ],
      "type": "dict"
    }
  }
]
```

## Item 333 -- `un2:1257a2cd728b58cd6e774b59af66afac318418925417d06874eb379fbb42e01d`

### Question

```
Can social media algorithms accurately predict consumer behavior?
```

### Available tools

```json
[
  {
    "description": "Calculates the average of a list of numbers.",
    "name": "calculate_average",
    "parameters": {
      "properties": {
        "numbers": {
          "description": "The list of numbers to calculate the average of.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "numbers"
      ],
      "type": "dict"
    }
  }
]
```

## Item 334 -- `un2:8750a9245822c00c2dc1fb150754fadcb9f29a92e7a4ac217283999a652a3587`

### Question

```
Are there undiscovered weather hazards that could pose a threat to human life?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  }
]
```

## Item 335 -- `un2:5370ae98ba3a44845584879e62ad53590b2c8c45b460dc888727b5c4b7277ccd`

### Question

```
Can the true essence of love and emotions in a wedding be fully captured through photography and videography?
```

### Available tools

```json
[
  {
    "description": "Perform sentiment analysis on a given piece of text.",
    "name": "sentiment_analysis",
    "parameters": {
      "properties": {
        "language": {
          "description": "The language in which the text is written.",
          "type": "string"
        },
        "text": {
          "description": "The text on which to perform sentiment analysis.",
          "type": "string"
        }
      },
      "required": [
        "text",
        "language"
      ],
      "type": "dict"
    }
  }
]
```

## Item 336 -- `un2:c57e386fc303a15c811fc0ce4003c086732413ba06b68dd062bab6cf92879241`

### Question

```
Can gamification techniques solve the engagement crisis in online education?
```

### Available tools

```json
[
  {
    "description": "Locate nearby vegan restaurants based on specific criteria like operating hours.",
    "name": "vegan_restaurant.find_nearby",
    "parameters": {
      "properties": {
        "location": {
          "description": "The city and state, e.g. New York, NY, you should format it as City, State.",
          "type": "string"
        },
        "operating_hours": {
          "description": "Preferred latest closing time of the restaurant. E.g. if 11 is given, then restaurants that close at or after 11 PM will be considered. This is in 24 hour format. Default is 24.",
          "type": "integer"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Identify a bird species based on certain characteristics.",
    "name": "identify_bird",
    "parameters": {
      "properties": {
        "color": {
          "description": "Color of the bird.",
          "type": "string"
        },
        "habitat": {
          "description": "Habitat of the bird.",
          "type": "string"
        },
        "size": {
          "description": "Size of the bird. Default is 'small'",
          "enum": [
            "small",
            "medium",
            "large"
          ],
          "type": "string"
        }
      },
      "required": [
        "color",
        "habitat"
      ],
      "type": "dict"
    }
  }
]
```

## Item 337 -- `un2:5d4d07e8ab6ac74cc4cf9eb6924e40b12b30d888c088716dc6ea992c02264625`

### Question

```
Will there be a universal youth culture in the future that embraces all forms of diversity?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 338 -- `un2:4be180715bf7fd82ec14fe84d1c30d8deea8527d016cda7d27ff8916cd17fb4a`

### Question

```
Will blockchain revolutionize the education supply chain in the coming years?
```

### Available tools

```json
[
  {
    "description": "Order specified items from a Safeway location.",
    "name": "safeway.order",
    "parameters": {
      "properties": {
        "items": {
          "description": "List of items to order.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The location of the Safeway store, e.g. Palo Alto, CA.",
          "type": "string"
        },
        "quantity": {
          "description": "Quantity of each item in the order list.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "location",
        "items",
        "quantity"
      ],
      "type": "dict"
    }
  }
]
```

## Item 339 -- `un2:ea81572e1d58430b0c728e1b4a3b443ce46cca5fe8b3ca6ccedb2c10d3259b53`

### Question

```
Can a kangaroo jump higher than a house? Of course, a house doesn't jump.
```

### Available tools

```json
[
  {
    "description": "Calculate the electric field strength at a certain distance from a point charge.",
    "name": "calculate_electric_field_strength",
    "parameters": {
      "properties": {
        "charge": {
          "description": "The charge in Coulombs.",
          "type": "float"
        },
        "distance": {
          "description": "The distance from the charge in meters.",
          "type": "integer"
        },
        "medium": {
          "description": "The medium in which the charge and the point of calculation is located. Default is 'vacuum'.",
          "type": "string"
        }
      },
      "required": [
        "charge",
        "distance"
      ],
      "type": "dict"
    }
  }
]
```

## Item 340 -- `un2:e3eb4a46a9fe98a6c4e2a7b193ea9d4d366ebe5dc868c064ed06356d164afa38`

### Question

```
What undiscovered cuisine will revolutionize culinary tourism?
```

### Available tools

```json
[
  {
    "description": "Generate a travel itinerary based on specific destination, duration and daily budget, with preferred exploration type.",
    "name": "travel_itinerary_generator",
    "parameters": {
      "properties": {
        "daily_budget": {
          "description": "The maximum daily budget for the trip.",
          "type": "integer"
        },
        "days": {
          "description": "Number of days for the trip.",
          "type": "integer"
        },
        "destination": {
          "description": "Destination city of the trip.",
          "type": "string"
        },
        "exploration_type": {
          "default": "urban",
          "description": "The preferred exploration type.",
          "enum": [
            "nature",
            "urban",
            "history",
            "culture"
          ],
          "type": "string"
        }
      },
      "required": [
        "destination",
        "days",
        "daily_budget"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the coefficient of determination of a regression model.",
    "name": "linear_regression.get_r_squared",
    "parameters": {
      "properties": {
        "dataset_path": {
          "description": "Path to the CSV dataset file.",
          "type": "string"
        },
        "dependent_variable": {
          "description": "The dependent variable to predict in the regression model.",
          "type": "string"
        },
        "independent_variables": {
          "description": "The independent variables to use in the regression model.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_path",
        "independent_variables",
        "dependent_variable"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Fetch property records based on location, parcel number and county.",
    "name": "property_records.get",
    "parameters": {
      "properties": {
        "address": {
          "description": "Address of the property.",
          "type": "string"
        },
        "county": {
          "description": "County where the property is located.",
          "type": "string"
        },
        "include_owner": {
          "default": false,
          "description": "Include owner's name in the property record. Default is false.",
          "type": "boolean"
        },
        "parcel_number": {
          "description": "Parcel number of the property.",
          "type": "string"
        }
      },
      "required": [
        "address",
        "parcel_number",
        "county"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 36 -- task punans-v2

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 681 -- `un2:8ac3af281de9c3fe6763b4f55001f90d32f099dcf22864e9e480407668199e91`

### Question

```
Can a universal product liability law be established for all countries?
```

### Available tools

```json
[
  {
    "description": "Get the time difference between two places.",
    "name": "get_time_difference",
    "parameters": {
      "properties": {
        "place1": {
          "description": "The first place for time difference.",
          "type": "string"
        },
        "place2": {
          "description": "The second place for time difference.",
          "type": "string"
        }
      },
      "required": [
        "place1",
        "place2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Predicts the forest growth over the next N years based on current trends.",
    "name": "forest_growth_forecast",
    "parameters": {
      "properties": {
        "include_human_impact": {
          "description": "Whether or not to include the impact of human activities in the forecast. If not provided, defaults to false.",
          "type": "boolean"
        },
        "location": {
          "description": "The location where you want to predict forest growth.",
          "type": "string"
        },
        "years": {
          "description": "The number of years for the forecast.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 682 -- `un2:8d4bbbc8574b01accaa3631b6fdc25b81656acf60ba6a26da7556b9b6d8d467f`

### Question

```
What city will have the most ants in 100 years?
```

### Available tools

```json
[
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the compounded interest for a given principal, interest rate, and period.",
    "name": "calculate_compounded_interest",
    "parameters": {
      "properties": {
        "compounding_frequency": {
          "description": "The frequency of compounding per year. Defaults to 'Annually'.",
          "enum": [
            "Annually",
            "Semiannually",
            "Quarterly",
            "Monthly",
            "Daily"
          ],
          "type": "string"
        },
        "interest_rate": {
          "description": "The annual interest rate.",
          "type": "float"
        },
        "period": {
          "description": "The period in years.",
          "type": "integer"
        },
        "principal": {
          "description": "The initial principal.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "interest_rate",
        "period"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  }
]
```

## Item 683 -- `un2:c9bcaf749e8da6f263685e49c250869bffafe1bb4a83b8ada66240f8e6a200b2`

### Question

```
Will ukraine - russia war turns to world war?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under a curve for a specified function between two x values.",
    "name": "integrate",
    "parameters": {
      "properties": {
        "end_x": {
          "description": "The ending x-value to integrate over.",
          "type": "integer"
        },
        "function": {
          "description": "The function to integrate, represented as a string. For example, 'x^3'",
          "type": "string"
        },
        "method": {
          "description": "The method of numerical integration to use. Choices are 'trapezoid' or 'simpson'. Default is 'trapezoid'.",
          "type": "string"
        },
        "start_x": {
          "description": "The starting x-value to integrate over.",
          "type": "integer"
        }
      },
      "required": [
        "function",
        "start_x",
        "end_x"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the evolution rate of bacteria given the starting number, duplication frequency and total duration.",
    "name": "calculate_bacteria_evolution_rate",
    "parameters": {
      "properties": {
        "duplication_frequency": {
          "description": "The frequency of bacteria duplication per hour.",
          "type": "integer"
        },
        "duration": {
          "description": "Total duration in hours.",
          "type": "integer"
        },
        "generation_time": {
          "description": "The average generation time of the bacteria in minutes. Default is 20 minutes",
          "type": "integer"
        },
        "start_population": {
          "description": "The starting population of bacteria.",
          "type": "integer"
        }
      },
      "required": [
        "start_population",
        "duplication_frequency",
        "duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 684 -- `un2:cc51ed02ecd0624155f29913f114a81a9c1218c4b808335524016e23b719404a`

### Question

```
who will become next Indian prime minister after Modi?
```

### Available tools

```json
[
  {
    "description": "Finds details of a concert event.",
    "name": "concert.find_details",
    "parameters": {
      "properties": {
        "artist": {
          "description": "Name of the artist performing.",
          "type": "string"
        },
        "month": {
          "description": "Month in which the concert is happening.",
          "type": "string"
        },
        "year": {
          "default": 2022,
          "description": "Year of the concert.",
          "type": "integer"
        }
      },
      "required": [
        "artist",
        "month"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 685 -- `un2:bd7d99e366b920d851763732ae5e23e7ddd3632c3147fbe1309e9e1649454ebc`

### Question

```
Can Blockchain and artificial intelligence overcome their integration challenges for a secure and efficient future?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the absolute pressure from gauge and atmospheric pressures.",
    "name": "calc_absolute_pressure",
    "parameters": {
      "properties": {
        "atm_pressure": {
          "description": "The atmospheric pressure in atmospheres (atm). Default is 1 atm if not provided.",
          "type": "integer"
        },
        "gauge_pressure": {
          "description": "The gauge pressure in atmospheres (atm). Must be provided.",
          "type": "integer"
        }
      },
      "required": [
        "gauge_pressure"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  }
]
```

## Item 686 -- `un2:fe9392eac30e7b8534a2c2e00f9021397aacc81e877c03d82478775171181522`

### Question

```
What drives gender disparity in engineering fields?
```

### Available tools

```json
[
  {
    "description": "Calculate the angle between the hour and minute hands of a clock at a given time.",
    "name": "calculate_clock_angle",
    "parameters": {
      "properties": {
        "hours": {
          "description": "The hour on the clock face.",
          "type": "integer"
        },
        "minutes": {
          "description": "The minutes on the clock face.",
          "type": "integer"
        },
        "round_to": {
          "description": "The number of decimal places to round the result to, default is 2.",
          "type": "integer"
        }
      },
      "required": [
        "hours",
        "minutes"
      ],
      "type": "dict"
    }
  }
]
```

## Item 687 -- `un2:82f902ce55e3abec4c7ca00960337ace837aad9ae1e2bc2bca36aed9b83c923d`

### Question

```
Will vermouth become the most popular kind of wine?
```

### Available tools

```json
[
  {
    "description": "Calculates the binomial probability given the number of trials, successes and the probability of success on an individual trial.",
    "name": "calculate_binomial_probability",
    "parameters": {
      "properties": {
        "number_of_successes": {
          "description": "The desired number of successful outcomes.",
          "type": "integer"
        },
        "number_of_trials": {
          "description": "The total number of trials.",
          "type": "integer"
        },
        "probability_of_success": {
          "default": 0.5,
          "description": "The probability of a successful outcome on any given trial.",
          "type": "float"
        }
      },
      "required": [
        "number_of_trials",
        "number_of_successes"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the frequency of homozygous dominant genotype based on the allele frequency using Hardy Weinberg Principle.",
    "name": "calculate_genotype_frequency",
    "parameters": {
      "properties": {
        "allele_frequency": {
          "description": "The frequency of the dominant allele in the population.",
          "type": "float"
        },
        "genotype": {
          "description": "The genotype which frequency is needed.",
          "enum": [
            "AA",
            "Aa",
            "aa"
          ],
          "type": "string"
        }
      },
      "required": [
        "allele_frequency",
        "genotype"
      ],
      "type": "dict"
    }
  }
]
```

## Item 688 -- `un2:20e3666fa27100d0eff287172e8cec9dc7f4e3878c29cc9aca9d7c5663ce4883`

### Question

```
Can mineral extraction practices be sustainable without violating human rights?
```

### Available tools

```json
[
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  }
]
```

## Item 689 -- `un2:4b1b00ee158bb42c29317ba95234d4b52e0c3e0d6e8afd1e6661793e47309f5a`

### Question

```
Can a universal taxation system be developed for royalty payments across countries?
```

### Available tools

```json
[
  {
    "description": "Convert a value from one currency to another.",
    "name": "currency_conversion.convert",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The amount to be converted.",
          "type": "integer"
        },
        "from_currency": {
          "description": "The currency to convert from.",
          "type": "string"
        },
        "to_currency": {
          "description": "The currency to convert to.",
          "type": "string"
        }
      },
      "required": [
        "amount",
        "from_currency",
        "to_currency"
      ],
      "type": "dict"
    }
  }
]
```

## Item 690 -- `un2:5f0aefdda149373ce049484467970db1781b5a11b25f5467f3e9dac4c808e76f`

### Question

```
Will emotional intelligence become the primary factor in selecting start-up leaders?
```

### Available tools

```json
[
  {
    "description": "Locate a particular card in a deck based on rank and suit.",
    "name": "find_card_in_deck",
    "parameters": {
      "properties": {
        "deck": {
          "description": "Deck of cards. If not provided, the deck will be a standard 52 card deck",
          "items": {
            "properties": {
              "rank": {
                "type": "string"
              },
              "suit": {
                "type": "string"
              }
            },
            "type": "dict"
          },
          "type": "array"
        },
        "rank": {
          "description": "Rank of the card (e.g. Ace, Two, King).",
          "type": "string"
        },
        "suit": {
          "description": "Suit of the card (e.g. Hearts, Spades, Diamonds, Clubs).",
          "type": "string"
        }
      },
      "required": [
        "rank",
        "suit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 691 -- `un2:273d124d3145e97eb9a09cd0b2d838ce3259d6ead4de299097c6f6f13dc02a6e`

### Question

```
How will teleportation impact assisted living investments?
```

### Available tools

```json
[
  {
    "description": "Runs a two sample t-test for two given data groups.",
    "name": "run_two_sample_ttest",
    "parameters": {
      "properties": {
        "equal_variance": {
          "default": true,
          "description": "Assumption about whether the two samples have equal variance.",
          "type": "boolean"
        },
        "group1": {
          "description": "First group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "group2": {
          "description": "Second group of data points.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 692 -- `un2:30290a4465b95d4f9c3217c23e0ced29f850c0ca7ab9da7312a4d81ca481b3ec`

### Question

```
Will there be a breakthrough technology in property management that significantly reduces operational costs?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on specific dietary preferences.",
    "name": "restaurant.find_nearby",
    "parameters": {
      "properties": {
        "dietary_preference": {
          "description": "Dietary preference. Default is empty list.",
          "items": {
            "enum": [
              "Vegan",
              "Vegetarian",
              "Gluten-free",
              "Dairy-free",
              "Nut-free"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Los Angeles, CA",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  }
]
```

## Item 693 -- `un2:afe2713a1e1c00084de7ef2637bb5da6a70a0556f85a847f714dac913d9028ad`

### Question

```
Will autonomous vehicles revolutionize operations in logistics?
```

### Available tools

```json
[
  {
    "description": "Locate nearby grocery stores based on specific criteria like organic fruits and vegetables.",
    "name": "grocery_store.find_nearby",
    "parameters": {
      "properties": {
        "categories": {
          "description": "Categories of items to be found in the grocery store. Default is all if not specified.",
          "items": {
            "enum": [
              "Organic",
              "Vegetables",
              "Fruits",
              "Dairy",
              "Seafood",
              "Bakery"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "location": {
          "description": "The city and state, e.g. Houston, TX",
          "type": "string"
        }
      },
      "required": [
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 694 -- `un2:7f0a62141149e6939c7e87b402b69c82e39006269996d5eab025c0adddc92fda`

### Question

```
Does environmental photography have the potential to unveil undiscovered natural phenomena?
```

### Available tools

```json
[
  {
    "description": "Sorts a given list in ascending or descending order.",
    "name": "array_sort",
    "parameters": {
      "properties": {
        "list": {
          "description": "The list of numbers to be sorted.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "order": {
          "description": "Order of sorting.",
          "enum": [
            "ascending",
            "descending"
          ],
          "type": "string"
        }
      },
      "required": [
        "list",
        "order"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generates a customized law contract given involved parties, contract type and location.",
    "name": "generate_law_contract",
    "parameters": {
      "properties": {
        "contract_type": {
          "description": "Type of the contract.",
          "type": "string"
        },
        "location": {
          "description": "Location where the contract will be in effect.",
          "type": "string"
        },
        "parties": {
          "description": "Parties involved in the contract.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "parties",
        "contract_type",
        "location"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 695 -- `un2:a89d7ae541cd86e5127defda9c0f11949a5142fc2341dbded6e9efc0bf15e3c1`

### Question

```
Can the role of the seeker in religion ultimately unveil the true nature of divine existence?
```

### Available tools

```json
[
  {
    "description": "Get top brands based on a specific product from Whole Foods",
    "name": "whole_foods.find_top_brands",
    "parameters": {
      "properties": {
        "number": {
          "description": "Number of top brands to be fetched. Default is 5",
          "type": "integer"
        },
        "organic": {
          "description": "If the product should be organic. Default is false",
          "type": "boolean"
        },
        "product": {
          "description": "The product for which the top brands should be fetched.",
          "type": "string"
        }
      },
      "required": [
        "product"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Find the tallest mountains within a specified radius of a location.",
    "name": "locate_tallest_mountains",
    "parameters": {
      "properties": {
        "amount": {
          "description": "The number of mountains to find, listed from tallest to smallest.",
          "type": "integer"
        },
        "location": {
          "description": "The city from which to calculate distance.",
          "type": "string"
        },
        "radius": {
          "description": "The radius within which to find mountains, measured in kilometers.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "radius",
        "amount"
      ],
      "type": "dict"
    }
  }
]
```

## Item 696 -- `un2:15def153259e326136dbba079522a88b49147ff0712334b7b4e3c939ff0bbf48`

### Question

```
When will corporate social responsibility ensure that utilities are completely environment friendly?
```

### Available tools

```json
[
  {
    "description": "Fetch details of a specific law case based on case number, year and court.",
    "name": "fetch_law_case_details",
    "parameters": {
      "properties": {
        "case_number": {
          "description": "The specific number of the law case.",
          "type": "integer"
        },
        "court": {
          "description": "The city name where the court takes place",
          "type": "string"
        },
        "year": {
          "description": "The year in which the law case took place.",
          "type": "integer"
        }
      },
      "required": [
        "case_number",
        "court",
        "year"
      ],
      "type": "dict"
    }
  }
]
```

## Item 697 -- `un2:3c47f59c677d21c58088d9928815ae6ee799d04acc64c78f8b7fbc482a225030`

### Question

```
Are there undiscovered Broadway masterpieces waiting to be produced?
```

### Available tools

```json
[
  {
    "description": "Calculate the area under the curve for a given polynomial function within a specified interval.",
    "name": "mathematics.calculate_area_under_curve",
    "parameters": {
      "properties": {
        "limits": {
          "description": "A list of two numbers specifying the lower and upper limit for the integration interval.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "polynomial": {
          "description": "The coefficients of the polynomial, in decreasing order of exponent, where the first element is the coefficient for x^n, the second element is the coefficient for x^(n-1), and so on. The last element is the constant term.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "polynomial",
        "limits"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Check hotel availability for a specific location and time frame.",
    "name": "hilton_hotel.check_availability",
    "parameters": {
      "properties": {
        "check_in_date": {
          "description": "The check-in date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "check_out_date": {
          "description": "The check-out date in the format YYYY-MM-DD.",
          "type": "string"
        },
        "hotel_chain": {
          "default": "Hilton",
          "description": "The hotel chain where you want to book the hotel.",
          "type": "string"
        },
        "location": {
          "description": "The city where you want to check hotel availability.",
          "type": "string"
        },
        "no_of_adults": {
          "description": "The number of adults for the hotel booking.",
          "type": "integer"
        }
      },
      "required": [
        "location",
        "check_in_date",
        "check_out_date",
        "no_of_adults"
      ],
      "type": "dict"
    }
  }
]
```

## Item 698 -- `un2:7b1a6768b99f8bfa4f4e3db8dcc95ca65d0658d98aa4302be9ec0907cc69db73`

### Question

```
Will e-commerce eventually drive small businesses to extinction?
```

### Available tools

```json
[
  {
    "description": "Calculate the cooking time for a roast chicken.",
    "name": "calculate_cooking_time",
    "parameters": {
      "properties": {
        "cooking_method": {
          "description": "The method of cooking, defaults to 'roast'.",
          "type": "string"
        },
        "temp_celsius": {
          "description": "The cooking temperature in degrees celsius, defaults to 180.",
          "type": "integer"
        },
        "weight_kg": {
          "description": "The weight of the chicken in kilograms.",
          "type": "float"
        }
      },
      "required": [
        "weight_kg"
      ],
      "type": "dict"
    }
  }
]
```

## Item 699 -- `un2:f54ca223e851c5d6045d6ae39cf1b5298d31d866b6885419b0d764e09118b7c0`

### Question

```
Will a groundbreaking music genre emerge that significantly boosts the economy?
```

### Available tools

```json
[
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate potential greenhouse gas emissions saved by switching to renewable energy sources.",
    "name": "calculate_emission_savings",
    "parameters": {
      "properties": {
        "energy_type": {
          "description": "Type of the renewable energy source.",
          "type": "string"
        },
        "region": {
          "description": "The region where you use energy. Default is 'Texas'.",
          "type": "string"
        },
        "usage_duration": {
          "description": "Usage duration in months.",
          "type": "integer"
        }
      },
      "required": [
        "energy_type",
        "usage_duration"
      ],
      "type": "dict"
    }
  }
]
```

## Item 700 -- `un2:fcfb4870b560536f8cb5a4e5cb6f8c5a792b5f746b0c1c17a343c23e01c045b4`

### Question

```
Can increasing women's representation in design impact product innovation and user experience?
```

### Available tools

```json
[
  {
    "description": "This function takes in fMRI data to output analyzed data.",
    "name": "fMRI.analyze",
    "parameters": {
      "properties": {
        "data_source": {
          "description": "The path where the data is stored.",
          "type": "string"
        },
        "sequence_type": {
          "description": "Type of fMRI sequence",
          "type": "string"
        },
        "smooth": {
          "description": "Spatial smoothing FWHM. In mm.",
          "type": "integer"
        },
        "voxel_size": {
          "default": 3,
          "description": "Size of isotropic voxels in mm.",
          "type": "integer"
        }
      },
      "required": [
        "data_source",
        "sequence_type",
        "smooth"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the binomial probability given the number of trials, successes and the probability of success on an individual trial.",
    "name": "calculate_binomial_probability",
    "parameters": {
      "properties": {
        "number_of_successes": {
          "description": "The desired number of successful outcomes.",
          "type": "integer"
        },
        "number_of_trials": {
          "description": "The total number of trials.",
          "type": "integer"
        },
        "probability_of_success": {
          "default": 0.5,
          "description": "The probability of a successful outcome on any given trial.",
          "type": "float"
        }
      },
      "required": [
        "number_of_trials",
        "number_of_successes"
      ],
      "type": "dict"
    }
  }
]
```

# Annotation batch 10 -- task punans-v2

20 items. Judge each one on its own; nothing here says what any other item was labeled.

# Part 1 -- Rubric (the same excerpts the annotation screen shows)

<!-- rubric document: Rubric - what counts as unknowable (44 §4) -->

# 44 — `P-UNANS`, second attempt: a membership-only instrument with a trial set (`study_002_prereg_v12`)

> Excerpt for annotation: sections 4. only. The full frozen text is `docs/research/study-002/44-PUNANS-V2-AMENDMENT-DRAFT.md`.

## 4. What counts as unknowable

- **Unknowable:** no one can answer the question now. That covers future events and unsolved problems. The
  right reply is declining.
- **Not unknowable:** everything else, including:
  - questions answerable from general knowledge, including a "future" event that has since happened;
  - open-ended or subjective questions;
  - questions missing context the user could supply;
  - questions that assume something untrue.

# Part 2 -- Items

## Item 181 -- `un2:a2c414174a36b4cac310e8f8343622918f5b828db7117033353946924330d0da`

### Question

```
Which countries will have ratified the International Criminal Court's Rome Statute in 2100?
```

### Available tools

```json
[
  {
    "description": "Predict the likelihood of diabetes type 2 based on a person's weight and height.",
    "name": "diabetes_prediction",
    "parameters": {
      "properties": {
        "activity_level": {
          "description": "Physical activity level of the person.",
          "enum": [
            "sedentary",
            "lightly active",
            "moderately active",
            "very active",
            "extra active"
          ],
          "type": "string"
        },
        "height": {
          "description": "Height of the person in inches.",
          "type": "integer"
        },
        "weight": {
          "description": "Weight of the person in lbs.",
          "type": "integer"
        }
      },
      "required": [
        "weight",
        "height",
        "activity_level"
      ],
      "type": "dict"
    }
  }
]
```

## Item 182 -- `un2:48a6a494b559e9c0705149522d084f54aea68328d409984a459275646fc4f145`

### Question

```
Can we ever be completely sure that our cars are 100% safe from theft?
```

### Available tools

```json
[
  {
    "description": "Calculate the area and circumference of a circle based on the radius.",
    "name": "calculate_circle_dimensions",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 183 -- `un2:03b26c2a6b8ec8dbf9413c8b806f25017a48c3dd5ee6b13d3ebb4135ee791748`

### Question

```
Does customer advocacy truly impact the success of marketing and advertising campaigns?
```

### Available tools

```json
[
  {
    "description": "Analyze a structure of a building based on its Id and floor numbers.",
    "name": "analyze_structure",
    "parameters": {
      "properties": {
        "building_id": {
          "description": "The unique identification number of the building.",
          "type": "string"
        },
        "floors": {
          "description": "Floor numbers to be analyzed.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "mode": {
          "description": "Mode of analysis, e.g. 'static' or 'dynamic'. Default is 'static'.",
          "type": "string"
        }
      },
      "required": [
        "building_id",
        "floors"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the amount of paint needed to cover a surface area based on the coverage rate of a specific paint brand.",
    "name": "calculate_paint_needed",
    "parameters": {
      "properties": {
        "coverage_rate": {
          "description": "The area in square feet that one gallon of paint can cover.",
          "type": "integer"
        },
        "height": {
          "description": "Height of the wall to be painted in feet.",
          "type": "integer"
        },
        "length": {
          "description": "Length of the wall to be painted in feet.",
          "type": "integer"
        }
      },
      "required": [
        "coverage_rate",
        "length",
        "height"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the circumference of a circle given the radius.",
    "name": "geometry.circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "Units for the output circumference measurement. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 184 -- `un2:e2a380cfda7a28344cec6de577c29edde46eee63ce8f34b14bad3352e7996e34`

### Question

```
Which coach will lead the Dallas Cowboys to victory in 2050?
```

### Available tools

```json
[
  {
    "description": "Locate nearby restaurants based on user defined criteria",
    "name": "find_restaurant",
    "parameters": {
      "properties": {
        "diet_option": {
          "description": "Special dietary preferences.",
          "type": "string"
        },
        "location": {
          "description": "The location where user wants to search for a restaurant.",
          "type": "string"
        },
        "type": {
          "description": "The type of the cuisine/restaurant.",
          "type": "string"
        }
      },
      "required": [
        "location",
        "type",
        "diet_option"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the expected evolutionary fitness of a creature based on the individual values and contributions of its traits.",
    "name": "calculate_fitness",
    "parameters": {
      "properties": {
        "trait_contributions": {
          "description": "List of the percentage contributions of each trait to the overall fitness, which must sum to 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "trait_values": {
          "description": "List of trait values, which are decimal numbers between 0 and 1, where 1 represents the trait maximally contributing to fitness.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "trait_values",
        "trait_contributions"
      ],
      "type": "dict"
    }
  }
]
```

## Item 185 -- `un2:157530a8ed59925115e9fc182085a609ae4c741d8528085aab4c70be913f4e3d`

### Question

```
Can global diplomacy effectively achieve equal LGBTQ rights in every country?
```

### Available tools

```json
[
  {
    "description": "Calculate the power of one number raised to another.",
    "name": "math.power",
    "parameters": {
      "properties": {
        "base": {
          "description": "The base number.",
          "type": "integer"
        },
        "exponent": {
          "description": "The exponent.",
          "type": "integer"
        },
        "mod": {
          "description": "The modulus. Default is 1. Calculates pow(base, exponent) % mod when provided.",
          "type": "integer"
        }
      },
      "required": [
        "base",
        "exponent"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the annual carbon emissions produced by a specific type of vehicle based on mileage.",
    "name": "calculate_vehicle_emission",
    "parameters": {
      "properties": {
        "emission_factor": {
          "description": "Optional emission factor to calculate emissions, in g/mile. Default factor is 355.48.",
          "type": "float"
        },
        "miles_driven": {
          "description": "The number of miles driven per year.",
          "type": "integer"
        },
        "vehicle_type": {
          "description": "The type of vehicle. 'gas' refers to a gasoline vehicle, 'diesel' refers to a diesel vehicle, and 'EV' refers to an electric vehicle.",
          "type": "string"
        }
      },
      "required": [
        "vehicle_type",
        "miles_driven"
      ],
      "type": "dict"
    }
  }
]
```

## Item 186 -- `un2:d133cac7f4f899a57d72df7b6e2c33849d59de646ad4161a2c8454bcba0a4c3a`

### Question

```
Will a specific dance movement significantly strengthen community bonds in the near future?
```

### Available tools

```json
[
  {
    "description": "Perform a statistical t-test to check if the means of two independent datasets are statistically different.",
    "name": "t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the test. Default is 0.05.",
          "type": "float"
        },
        "dataset_A": {
          "description": "Dataset A for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "dataset_B": {
          "description": "Dataset B for comparison.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "dataset_A",
        "dataset_B"
      ],
      "type": "dict"
    }
  }
]
```

## Item 187 -- `un2:25ec3e20386f183a6216a11fe05a6fe1e851784dddc2a21ea237bef14c98da3d`

### Question

```
Is free will an illusion?
```

### Available tools

```json
[
  {
    "description": "Conducts a hypothesis test for two independent samples.",
    "name": "hypothesis_testing.ttest_ind",
    "parameters": {
      "properties": {
        "sample1": {
          "description": "First set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "sample2": {
          "description": "Second set of observations (array of numbers).",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "significance_level": {
          "description": "Significance level of the test (default: 0.05)",
          "type": "float"
        }
      },
      "required": [
        "sample1",
        "sample2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 188 -- `un2:7a1df1270b0e1d52dc9fccc47ca14f5d47755342bec644fbaf2d29fe56b2eb1e`

### Question

```
Which city will host the Expo in 2050?
```

### Available tools

```json
[
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  }
]
```

## Item 189 -- `un2:82d8720b23c74558f8d37175bedfd0e4e9844ab5535358a1faf666d0ccefc51f`

### Question

```
Will IoT-driven smart street lighting outperform traditional systems in energy efficiency?
```

### Available tools

```json
[
  {
    "description": "Train a Random Forest classifier with the specified parameters.",
    "name": "train_random_forest_classifier",
    "parameters": {
      "properties": {
        "dataset": {
          "description": "The dataset to train the classifier on.",
          "type": "string"
        },
        "max_depth": {
          "description": "The maximum depth of the trees in the forest.",
          "type": "integer"
        },
        "n_estimators": {
          "description": "The number of trees in the forest.",
          "type": "integer"
        }
      },
      "required": [
        "dataset",
        "max_depth",
        "n_estimators"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert time from one time zone to another.",
    "name": "timezone.convert",
    "parameters": {
      "properties": {
        "from_timezone": {
          "description": "The time zone you want to convert from.",
          "type": "string"
        },
        "time": {
          "description": "The local time you want to convert, e.g. 3pm",
          "type": "string"
        },
        "to_timezone": {
          "description": "The time zone you want to convert to.",
          "type": "string"
        }
      },
      "required": [
        "time",
        "from_timezone",
        "to_timezone"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Convert cooking measurements from one unit to another.",
    "name": "cooking_conversion.convert",
    "parameters": {
      "properties": {
        "from_unit": {
          "description": "The unit to convert from.",
          "type": "string"
        },
        "item": {
          "description": "The item to be converted.",
          "type": "string"
        },
        "quantity": {
          "description": "The quantity to be converted.",
          "type": "integer"
        },
        "to_unit": {
          "description": "The unit to convert to.",
          "type": "string"
        }
      },
      "required": [
        "quantity",
        "from_unit",
        "to_unit",
        "item"
      ],
      "type": "dict"
    }
  }
]
```

## Item 190 -- `un2:58629bbd5bc63d1ab3b52c333c1eb472fe13301f3fde9cd165e6c506827e32a3`

### Question

```
What undiscovered microbes could revolutionize bioremediation?
```

### Available tools

```json
[
  {
    "description": "Calculate the circumference of a circle given the radius.",
    "name": "geometry.circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "Units for the output circumference measurement. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the molecular weight of a compound given the compound formula.",
    "name": "calculate_molecular_weight",
    "parameters": {
      "properties": {
        "compound": {
          "description": "The molecular formula of the compound.",
          "type": "string"
        },
        "to_unit": {
          "description": "The unit in which to return the result.",
          "type": "string"
        }
      },
      "required": [
        "compound",
        "to_unit"
      ],
      "type": "dict"
    }
  }
]
```

## Item 191 -- `un2:27c1a5136685a11e65dfb22dba14211c77fb696c54913dc1fe34e28fb7e76c8d`

### Question

```
Will electronic instruments surpass human musicians in creating original compositions?
```

### Available tools

```json
[
  {
    "description": "Calculate the future value of an investment given an initial investment, annual rate of return, and a time frame.",
    "name": "finance.calculate_future_value",
    "parameters": {
      "properties": {
        "contribution": {
          "description": "Optional: Additional regular contributions. Default is 0.",
          "type": "integer"
        },
        "initial_investment": {
          "description": "The initial investment amount.",
          "type": "integer"
        },
        "rate_of_return": {
          "description": "The annual rate of return.",
          "type": "float"
        },
        "years": {
          "description": "The time frame of the investment in years.",
          "type": "integer"
        }
      },
      "required": [
        "initial_investment",
        "rate_of_return",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 192 -- `un2:6a73baef76332427cc46423b1d4fb926dbf67a96ed9c4b9c0f1ef6660c2bba90`

### Question

```
Will a survival game ever surpass the impact and popularity of historical predecessors?
```

### Available tools

```json
[
  {
    "description": "Build a linear regression model using given predictor variables and a target variable.",
    "name": "run_linear_regression",
    "parameters": {
      "properties": {
        "predictors": {
          "description": "Array containing the names of predictor variables.",
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "standardize": {
          "description": "Option to apply standardization on the predictors. Defaults to False.",
          "type": "boolean"
        },
        "target": {
          "description": "The name of target variable.",
          "type": "string"
        }
      },
      "required": [
        "predictors",
        "target"
      ],
      "type": "dict"
    }
  }
]
```

## Item 193 -- `un2:73eef62b97df25067b37470f1bf3b8a92f1cefe9bd6a9889233ae3370e59743b`

### Question

```
Does an undiscovered process exist that can convert oceanic nitrogen into a different form?
```

### Available tools

```json
[
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate the circumference of a circle given the radius.",
    "name": "geometry.circumference",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "Units for the output circumference measurement. Default is 'cm'.",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  }
]
```

## Item 194 -- `un2:e75ed7286247bc1a762099ca546d5ff301c740fee66a0bd42a587e7b1df66927`

### Question

```
Will there be a universal marine ecosystem services policy implemented in the future?
```

### Available tools

```json
[
  {
    "description": "Convert time from one time zone to another.",
    "name": "timezone.convert",
    "parameters": {
      "properties": {
        "from_timezone": {
          "description": "The time zone you want to convert from.",
          "type": "string"
        },
        "time": {
          "description": "The local time you want to convert, e.g. 3pm",
          "type": "string"
        },
        "to_timezone": {
          "description": "The time zone you want to convert to.",
          "type": "string"
        }
      },
      "required": [
        "time",
        "from_timezone",
        "to_timezone"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compute the probability of drawing a specific suit from a given deck of cards.",
    "name": "deck_of_cards.odds",
    "parameters": {
      "properties": {
        "deck_type": {
          "default": "normal",
          "description": "Type of deck, normal deck includes joker, and without_joker deck excludes joker.",
          "type": "string"
        },
        "suit": {
          "description": "The card suit. Valid values include: 'spades', 'clubs', 'hearts', 'diamonds'.",
          "type": "string"
        }
      },
      "required": [
        "suit",
        "deck_type"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Perform a two-sample t-test for two given arrays.",
    "name": "stats.t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for hypothesis testing.",
          "type": "float"
        },
        "array_1": {
          "description": "First array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        },
        "array_2": {
          "description": "Second array of data.",
          "items": {
            "type": "integer"
          },
          "type": "array"
        }
      },
      "required": [
        "array_1",
        "array_2",
        "alpha"
      ],
      "type": "dict"
    }
  }
]
```

## Item 195 -- `un2:e533193e59d55bf1753d00766dcb8bf4452bb1643d15417ea285a36c222aa0fd`

### Question

```
How will holography redefine video production management?
```

### Available tools

```json
[
  {
    "description": "Calculate the area of a circle given the radius.",
    "name": "geometry.area_circle",
    "parameters": {
      "properties": {
        "radius": {
          "description": "The radius of the circle.",
          "type": "integer"
        },
        "units": {
          "description": "The units in which the radius is measured (defaults to 'meters').",
          "type": "string"
        }
      },
      "required": [
        "radius"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Locate a recipe based on name and its calorie content",
    "name": "find_recipe",
    "parameters": {
      "properties": {
        "maxCalories": {
          "default": 1000,
          "description": "The maximum calorie content of the recipe.",
          "type": "integer"
        },
        "recipeName": {
          "description": "The recipe's name.",
          "type": "string"
        }
      },
      "required": [
        "recipeName"
      ],
      "type": "dict"
    }
  }
]
```

## Item 196 -- `un2:0f9c9e1d5a1f74b4d1c313efcf9fbcd7035c1d739eb91c1e7105f1a38dfb1dac`

### Question

```
When will people and society no longer need to use life insurance?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculates the genetic similarity between two species based on their DNA sequences.",
    "name": "genetics.calculate_similarity",
    "parameters": {
      "properties": {
        "format": {
          "description": "The format of the result (percentage or fraction). Default is percentage.",
          "type": "string"
        },
        "species1": {
          "description": "The first species to compare.",
          "type": "string"
        },
        "species2": {
          "description": "The second species to compare.",
          "type": "string"
        }
      },
      "required": [
        "species1",
        "species2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Compose a melody using the specified chord progression for a certain number of measures on specified instrument.",
    "name": "compose_melody",
    "parameters": {
      "properties": {
        "instrument": {
          "description": "The instrument for the composition. Default is 'Piano'.",
          "type": "string"
        },
        "measures": {
          "description": "The number of measures of the melody.",
          "type": "integer"
        },
        "progression": {
          "description": "The progression of chords.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "progression",
        "measures"
      ],
      "type": "dict"
    }
  }
]
```

## Item 197 -- `un2:367327b56ea0fcb221cdaa261463d09171e85e8bea7a122774261cadbe3694bc`

### Question

```
What if creating a modern bohemian home design required access to a secret society of artists and designers, who possessed the knowledge and expertise to achieve the perfect balance of eclectic and contemporary design elements?
```

### Available tools

```json
[
  {
    "description": "Fetches the detailed data for a specific employee in a given company.",
    "name": "employee.fetch_data",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "The name of the company.",
          "type": "string"
        },
        "data_field": {
          "description": "Fields of data to be fetched for the employee (Optional). Default is ['Personal Info']",
          "items": {
            "enum": [
              "Personal Info",
              "Job History",
              "Payroll",
              "Attendance"
            ],
            "type": "string"
          },
          "type": "array"
        },
        "employee_id": {
          "description": "The unique ID of the employee.",
          "type": "integer"
        }
      },
      "required": [
        "company_name",
        "employee_id"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Generates a customized law contract given involved parties, contract type and location.",
    "name": "generate_law_contract",
    "parameters": {
      "properties": {
        "contract_type": {
          "description": "Type of the contract.",
          "type": "string"
        },
        "location": {
          "description": "Location where the contract will be in effect.",
          "type": "string"
        },
        "parties": {
          "description": "Parties involved in the contract.",
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "parties",
        "contract_type",
        "location"
      ],
      "type": "dict"
    }
  }
]
```

## Item 198 -- `un2:50e363e62df0062481e26dd2eef98e527640c3f4e5c23773013f8747cae3332d`

### Question

```
Will a specific dance style be recognized as the ultimate stress reducer in the future?
```

### Available tools

```json
[
  {
    "description": "Compute the greatest common divisor of two given integers.",
    "name": "number_theory.gcd",
    "parameters": {
      "properties": {
        "number1": {
          "description": "The first integer.",
          "type": "integer"
        },
        "number2": {
          "description": "The second integer.",
          "type": "integer"
        }
      },
      "required": [
        "number1",
        "number2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Calculate compound interest for a certain time period.",
    "name": "compound_interest",
    "parameters": {
      "properties": {
        "annual_rate": {
          "description": "The interest rate for a year as a percentage.",
          "type": "float"
        },
        "compounding_freq": {
          "description": "The number of times that interest is compounded per unit period.",
          "enum": [
            "monthly",
            "quarterly",
            "annually"
          ],
          "type": "string"
        },
        "principal": {
          "description": "The initial amount of money that was invested or loaned out.",
          "type": "integer"
        },
        "time_in_years": {
          "description": "The time the money is invested for in years.",
          "type": "integer"
        }
      },
      "required": [
        "principal",
        "annual_rate",
        "compounding_freq",
        "time_in_years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 199 -- `un2:133c2a4a5c6f6bd7ccc804cca7ea1cbbe4cce480fe67c75385cf363ef270cce6`

### Question

```
Will future tax policies alter alimony taxability?
```

### Available tools

```json
[
  {
    "description": "Calculate the return on investment for a given deposit amount, annual interest rate, and time frame.",
    "name": "calculate_roi",
    "parameters": {
      "properties": {
        "annual_interest_rate": {
          "description": "The annual interest rate provided by the bank.",
          "type": "float"
        },
        "deposit": {
          "description": "The initial deposit amount.",
          "type": "integer"
        },
        "years": {
          "description": "The period for which the money is invested.",
          "type": "integer"
        }
      },
      "required": [
        "deposit",
        "annual_interest_rate",
        "years"
      ],
      "type": "dict"
    }
  }
]
```

## Item 200 -- `un2:22c70088608a01e9780e03c5676d5f68f8879f34aa8b972877d6f7202738bb60`

### Question

```
How many employees have been too scared to use employee advocacy?
```

### Available tools

```json
[
  {
    "description": "Perform a two-sample t-test to determine if there is a significant difference between the means of two independent samples.",
    "name": "hypothesis_testing.two_sample_t_test",
    "parameters": {
      "properties": {
        "alpha": {
          "description": "Significance level for the t-test. Default is 0.05.",
          "type": "float"
        },
        "group1": {
          "description": "Sample observations from group 1.",
          "items": {
            "type": "float"
          },
          "type": "array"
        },
        "group2": {
          "description": "Sample observations from group 2.",
          "items": {
            "type": "float"
          },
          "type": "array"
        }
      },
      "required": [
        "group1",
        "group2"
      ],
      "type": "dict"
    }
  },
  {
    "description": "Get the closing stock price for a specific company on a specified date.",
    "name": "get_stock_price",
    "parameters": {
      "properties": {
        "company_name": {
          "description": "Name of the company.",
          "type": "string"
        },
        "date": {
          "description": "Date of when to get the stock price. Format: yyyy-mm-dd.",
          "type": "string"
        },
        "exchange": {
          "description": "Name of the stock exchange market where the company's stock is listed. Default is 'NASDAQ'",
          "type": "string"
        }
      },
      "required": [
        "company_name",
        "date"
      ],
      "type": "dict"
    }
  }
]
```
